/* CONT_VERSION_ID("@(#)CONT_ID %fv: skeleton.c-1.1.1 % %dc: Mon Sep 15 10:42:33 1997 % (#)@") */
//---------------------------------------------------------------------------
// SKELETON
//
// Skeleton 3GL module for use with UNIFACE Six for Windows. This sample
// also highlights peculiarities in using the Windows API from a UNIFACE
// Six DLL.
//
// Copyright (c) Uniface 1994. All rights reserved.
//
// You have a royalty-free right to use, modify, reproduce and distribute
// this sample code (and/or any modified version) in any way you find useful,
// provided that you agree that Uniface has no warranty obligations or
// liability for any sample code which has been modified.
//
//-seq--chg#--date----who--description---------------------------------------
//   0  6042  940620  hvv  created
//   1  8027  950719  tw   use new XEXPORT definition
//   2 10249  950824  tw   port to NT
//   3 15220  970915  pbr  updated comment about shared variables
//---------------------------------------------------------------------------

#include <windows.h>
#include <windowsx.h>
#include <umsw3gl.h>

//---------------------------------------------------------------------------
// GLOBALS
//---------------------------------------------------------------------------

    // ================================================================== //
    // Any global variables are automatically private for each instance,  //
    // unless explicitly declared "far". Thus you do not normally have to //
    // worry about the fact that the DLL may be used by multiple client   //
    // applications at once. If you have a large chunk of read-only data  //
    // however, you may declare it "far" and share it between instances.  //
    //                                                                    //
    // (Note: this is valid only for 16-bit DLL's.                        //
    // 32-bit DLL instances each have their own data segment, so as a     //
    // consequence sharing of data between instances is not possible)     //
    // ================================================================== //

static char szClass[] = "SkeletonClass";
static HWND hwndSkeleton;
static HBITMAP hbmSkeleton;

//---------------------------------------------------------------------------
// OnPaint - Message handler for WM_PAINT
//---------------------------------------------------------------------------

static void OnPaint(HWND hwnd)
{
    PAINTSTRUCT ps;
    HDC         hdcWindow, hdcSkeleton;
    HBITMAP     hbmSave;
    BITMAP      bm;

    // -- Get size of bitmap
    GetObject(hbmSkeleton, sizeof(bm), &bm);

    // -- Paint bitmap
    hdcWindow = BeginPaint(hwnd, &ps);
    hdcSkeleton = CreateCompatibleDC(hdcWindow);
    hbmSave = SelectObject(hdcSkeleton, hbmSkeleton);
    BitBlt(hdcWindow, 0, 0, bm.bmWidth, bm.bmHeight,
           hdcSkeleton, 0, 0, SRCCOPY);
    SelectObject(hdcSkeleton, hbmSave);
    DeleteDC(hdcSkeleton);
    EndPaint(hwnd, &ps);
}

//---------------------------------------------------------------------------
// OnTimer - Message handler for WM_TIMER
//---------------------------------------------------------------------------

static void OnTimer(HWND hwnd, UINT id)
{
    RECT r;
    HDC  hdc;

    // -- Get size of client area
    GetClientRect(hwnd, &r);

    // -- Invert it
    hdc = GetDC(hwnd);
    InvertRect(hdc, &r);
    ReleaseDC(hwnd, hdc);
}

//---------------------------------------------------------------------------
// SkeletonWndProc - Window procedure for skeleton window
//---------------------------------------------------------------------------

    // ================================================================== //
    // Window procedures and any other functions called by Windows (e.g.  //
    // timer procs, enumeration procs, hook procs) should be declared     //
    // XCALLBACK. There is no need to export these functions.             //
    // ================================================================== //

long XCALLBACK SkeletonWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{

    // ================================================================== //
    // The first thing to do in a window procedure is to call ULOADDS.    //
    // This function ensures that global variables and static data can    //
    // be addressed.                                                      //
    // ================================================================== //

    ULOADDS();

    switch (uMsg)
    {
    HANDLE_MSG(hwnd, WM_PAINT, OnPaint);
    HANDLE_MSG(hwnd, WM_TIMER, OnTimer);
    }

    // -- Default handling
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

//---------------------------------------------------------------------------
// uSkeleton - Create or destroy skeleton window
//
// The purpose of this function is to scare the enduser. Whoooooo!
//
// in:   $50       0 - window off
//                 1 - window on
// out:  $status
//---------------------------------------------------------------------------

    // ================================================================== //
    // Functions that must be called from 4GL using the perform statement //
    // should be declared XEXPORT( <return-type> ). This ensures the      //
    // correct calling sequence and automatically exports the function    //
    // from the DLL.                                                      //
    // ================================================================== //

XEXPORT(long) USKELETON(void) // @pr1, @pr2
{
    int    iOn;
    DWORD  dwStyle = WS_POPUP | WS_POPUP | WS_CAPTION;
    RECT   r;
    BITMAP bm;

    iOn = (int)UGETREG(50);

    if (iOn)
    {
        // -- Fail if already created
        if (hwndSkeleton) return FAILURE;

        // -- Compute required size of window and center it
        GetObject(hbmSkeleton, sizeof(bm), &bm);
        SetRect(&r, 0, 0, bm.bmWidth, bm.bmHeight);
        OffsetRect(&r, (GetSystemMetrics(SM_CXSCREEN) - bm.bmWidth)  / 2,
                       (GetSystemMetrics(SM_CYSCREEN) - bm.bmHeight) / 2);
        AdjustWindowRect(&r, dwStyle, FALSE);

        // -- Create skeleton window
        hwndSkeleton = CreateWindow(szClass,          // Class name
                                    "Whooooooo",      // Title
                                    dwStyle,          // Style
                                    r.left, r.top,    // Position
                                    r.right-r.left,   // Width
                                    r.bottom-r.top,   // Height
                                    UGETHWND(),       // Parent window
                                    NULL,             // Menu
                                    UGETHINST(),      // Instance handle
                                    NULL);            // Parameters
        if (!hwndSkeleton) return FAILURE;

        // -- Show the window and breath "life" into it
        ShowWindow(hwndSkeleton, SW_SHOW);
        SetTimer(hwndSkeleton, 1, 100, NULL);
    }
    else
    {
        // -- Fail if skeleton doesn't exist
        if (!hwndSkeleton) return FAILURE;

        // -- Stop timer and destroy window
        KillTimer(hwndSkeleton, 1);
        DestroyWindow(hwndSkeleton);
        hwndSkeleton = NULL;
    }

    return SUCCESS;
}

//---------------------------------------------------------------------------
// InitSkeleton - Register window class
//---------------------------------------------------------------------------

static short InitSkeleton(void)
{
    WNDCLASS cls;

    // ================================================================== //
    // Registering the class will benignly fail when another instance has //
    // already registered it. Here we check for this condition and return //
    // SUCCESS if the class already exists.                               //
    // ================================================================== //

    if (!GetClassInfo(UGETHINST(), szClass, &cls))
    {
        // ================================================================== //
        // Note that there is no need to use UMAKEPROCINST on the window      //
        // procedure pointer. Instead you call ULOADDS in the window proc.    //
        // ================================================================== //

        cls.style         = CS_BYTEALIGNCLIENT;
        cls.lpfnWndProc   = SkeletonWndProc;
        cls.cbClsExtra    = 0;
        cls.cbWndExtra    = 0;
        cls.hInstance     = UGETHINST();
        cls.hIcon         = NULL;
        cls.hCursor       = NULL;
        cls.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
        cls.lpszMenuName  = NULL;
        cls.lpszClassName = szClass;

        if (!RegisterClass(&cls)) return FAILURE;
    }

    // -- Load the bitmap from the DLL resources
    hbmSkeleton = LoadBitmap(ULIBINST(), "Skeleton");

    return SUCCESS;
}

//---------------------------------------------------------------------------
// ExitSkeleton - Return system resources to Windows
//---------------------------------------------------------------------------

static short ExitSkeleton(void)
{
    // ================================================================== //
    // Do not unregister the class, as other instances may still be using //
    // it. Windows will clean it up when the last instance exits.         //
    // ================================================================== //

    // -- Delete the bitmap
    DeleteObject(hbmSkeleton);

    return SUCCESS;
}

//---------------------------------------------------------------------------
// UDLLEVENT - Handle DLL load/unload events.
//
// in:  wEvent     Event code:
//                   UEVT_INITDLL      The DLL is loaded by Windows
//                   UEVT_INITCLIENT   A Uniface app connects to the DLL
//                   UEVT_INITGUI      Interactive mode starts
//                   UEVT_EXITGUI      Interactive mode ends
//                   UEVT_EXITCLIENT   A Uniface app disconnects from the DLL
//                   UEVT_EXITDLL      The DLL is unloaded by Windows
//
// ret:            SUCCESS   Accept the load or connect attempt
//                 FAILURE   Reject the load or connect attempt
//                 Ignored for other events
//---------------------------------------------------------------------------

short X3GL UDLLEVENT(short sEvent)
{
   switch (sEvent)
   {
   case UEVT_INITDLL:
      // -- When this event occurs, there is no client yet. The data segment
      // -- is the master datasegment; any changes made to global variables
      // -- will be reflected in all datasegments for all clients to come.
      // -- Returning a positive value from this event allows you to set the
      // -- size of the thunk table to some other size than the default (31).
      // -- You would want to do this if you have many 4GL callable functions
      // -- in your 3GL module.
      break;

   case UEVT_INITCLIENT:
      // -- Here we are about to accept a new client. Could allocate some
      // -- dynamic memory to hold the client's static data, if we needed any.
      // -- It is not generally safe to call Uniface service functions at
      // -- this point; Uniface may not yet be through its initialization.
      break;

   case UEVT_INITGUI:
      // -- This event indicates the start of an interactive session. It
      // -- will also occur if the DLL is loaded while an interactive
      // -- session has already started. It is safe to call service functions
      // -- here.

      return InitSkeleton();
      break;

   case UEVT_EXITGUI:
      // -- End of an interactive session. A good place to return Windows
      // -- resources to the system.

      return ExitSkeleton();
      break;

   case UEVT_EXITCLIENT:
      // -- Any memory, files, etc allocated for the disconnecting client
      // -- should be released here.
      break;

   case UEVT_EXITDLL:
      // -- The DLL is about to be unloaded. Shared resources should be
      // -- released at this point.
      break;
   }
   return SUCCESS;
}

// END SKELETON.C
