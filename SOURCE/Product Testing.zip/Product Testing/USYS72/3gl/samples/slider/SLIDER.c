/* CONT_VERSION_ID("@(#)CONT_ID %fv: % %dc: % (#)@") */
//---------------------------------------------------------------------------
// SLIDER
//
// This sample illustrates a simple OWI widget, in this case a slider
// (scrollbar) representing and controlling a numerical value.
//
// Copyright (c) Uniface 1994. All rights reserved.
//
// You have a royalty-free right to use, modify, reproduce and distribute
// this sample code (and/or any modified version) in any way you find useful,
// provided that you agree that Uniface has no warranty obligations or
// liability for any sample code which has been modified.
//
//-seq--chg#--date----who--description---------------------------------------
//   0  6042  940508  hvv  created
//   1  6042  940626  hvv  add keyboard interface
//   2  6524  940913  hvv  include files
//   3  8027  950719  tw   use new XEXPORT definition
//   4 10249  950824  tw   port to Win32 (and win16)
//---------------------------------------------------------------------------

#include <windows.h>
#include <windowsx.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <owimsw.h>
#include <owi.h>
#include <umsw3gl.h>

// -- widget instance data

typedef struct _slider
{
    HWND        hwnd;                   // Our window handle
    WMLINK      wmlink;                 // Our ticket to services
    COLORREF    clrBack;                // Background color
    HBRUSH      hbrBack;                // Background brush for WM_CTLCOLOR
    BOOL        bForceFit;              // Force widget into painted area
    BOOL        bNoLabel;               // We cannot update our label
    UFLOAT      fValue;                 // Current value
    UFLOAT      fMin;                   // Valid range of value
    UFLOAT      fMax;                   // Valid range of value
    UFLOAT      fUnit;                  // Scaling to integer
    UFLOAT      fLineInc;               // Small increment
    UFLOAT      fPageInc;               // Large increment
} ASLIDER, NEAR *PSLIDER;

// -- global variables

static char szClass[] = "ScrollBar";    // Window class name
static ATOM atomSlider;                 // Atom for window property
static WNDPROC pfnScrollBarProc;        // Superclass proc

// -- convenience macros
#ifndef WM_CTLCOLORSCROLLBAR
#define WM_CTLCOLORSCROLLBAR WM_CTLCOLOR // @pr4
#endif

//@pr4 use win16/32 compatible version of LOINT and HIINT
#define LOINT(a) ((int)(short)LOWORD(a)) // Extract bits 0-15 as signed short
#define HIINT(a) ((int)(short)HIWORD(a)) // Extract bits 16-31 as signed short

//-----------------------------------------------------------------------------
// Update display - Value has changed, update display accordingly
//-----------------------------------------------------------------------------

static void UpdateDisplay(PSLIDER ps, UFLOAT f)
{
    // -- limit value
    if (f < ps->fMin) f = ps->fMin;
    else if (f > ps->fMax) f = ps->fMax;

    // -- update associated label
    if (!ps->bNoLabel)
    {
        char szValue[32];
        sprintf(szValue, "%g", f);
        if (olPut(ps->wmlink, szValue) < 0) ps->bNoLabel = TRUE;
    }

    // -- update scrollbar if we can
    if (ps->fUnit != 0.0)
    {
        // -- mirror value if scrollbar is vertical
        if (GetWindowLong(ps->hwnd, GWL_STYLE) & SBS_VERT) f = ps->fMax - f;
        else f = f - ps->fMin;
        SetScrollPos(ps->hwnd, SB_CTL, (int)(f / ps->fUnit + 0.5), TRUE);
    }
}

//-----------------------------------------------------------------------------
// OnCtlColor - WM_CTLCOLOR Handler
//-----------------------------------------------------------------------------

static HBRUSH OnCtlColor(PSLIDER ps, HDC hdc, HWND hwndChild, int type)
{
    // -- setup appropriate colors in our DC
    SetBkColor(hdc, ps->clrBack);
    return ps->hbrBack;
}

//-----------------------------------------------------------------------------
// OnHScroll - WM_HSCROLL Handler
//-----------------------------------------------------------------------------

static void OnHScroll(PSLIDER ps, HWND hwndCtl, UINT uCode, int iPos)
{
    UFLOAT f = ps->fValue;

    switch (uCode)
    {
    case SB_BOTTOM:     f = ps->fMax; break;
    case SB_TOP:        f = ps->fMin; break;
    case SB_LINEDOWN:   f += ps->fLineInc; break;
    case SB_LINEUP:     f -= ps->fLineInc; break;
    case SB_PAGEDOWN:   f += ps->fPageInc; break;
    case SB_PAGEUP:     f -= ps->fPageInc; break;
    case SB_THUMBPOSITION:
    case SB_THUMBTRACK: f = ps->fMin + iPos * ps->fUnit; break;
    }

    // -- limit
    if (f < ps->fMin) f = ps->fMin;
    else if (f > ps->fMax) f = ps->fMax;

    // -- update
    UpdateDisplay(ps, f);
    if (f != ps->fValue && uCode != SB_THUMBTRACK)
    {
        ps->fValue = f;
        oNotify(ps->wmlink, ONTF_VALUECHANGE, 1);
    }
}

//-----------------------------------------------------------------------------
// OnVScroll - WM_VSCROLL Handler
//-----------------------------------------------------------------------------

static void OnVScroll(PSLIDER ps, HWND hwndCtl, UINT uCode, int iPos)
{
    UFLOAT f = ps->fValue;

    switch (uCode)
    {
    case SB_BOTTOM:     f = ps->fMin; break;
    case SB_TOP:        f = ps->fMax; break;
    case SB_LINEDOWN:   f -= ps->fLineInc; break;
    case SB_LINEUP:     f += ps->fLineInc; break;
    case SB_PAGEDOWN:   f -= ps->fPageInc; break;
    case SB_PAGEUP:     f += ps->fPageInc; break;
    case SB_THUMBPOSITION:
    case SB_THUMBTRACK: f = ps->fMax - iPos * ps->fUnit; break;
    }

    // -- limit
    if (f < ps->fMin) f = ps->fMin;
    else if (f > ps->fMax) f = ps->fMax;

    // -- update
    UpdateDisplay(ps, f);
    if (f != ps->fValue && uCode != SB_THUMBTRACK)
    {
        ps->fValue = f;
        oNotify(ps->wmlink, ONTF_VALUECHANGE, 1);
    }
}

//-----------------------------------------------------------------------------
// OnNCDestroy - WM_NCDESTROY Handler
//-----------------------------------------------------------------------------

static void OnNCDestroy(PSLIDER ps)
{
    DeleteObject(ps->hbrBack);
    RemoveProp(ps->hwnd, (LPCSTR)atomSlider);
    LocalFree(ps);
}

//-----------------------------------------------------------------------------
// IsSliderKey - Process selected keystrokes                         // @pr1
//-----------------------------------------------------------------------------

static WPARAM IsSliderKey(PSLIDER ps, WPARAM wKey)
{
    UINT uMsg;
    WPARAM *pTable;
    static WPARAM aVert[] = { VK_END,   SB_TOP,      // End   => Max
                              VK_HOME,  SB_BOTTOM,   // Home  => Min
                              VK_PRIOR, SB_PAGEUP,   // PgUp  => +LargeInc
                              VK_NEXT,  SB_PAGEDOWN, // PgDn  => -LargeInc
                              VK_UP,    SB_LINEUP,   // Up    => +SmallInc
                              VK_DOWN,  SB_LINEDOWN, // Down  => -SmallInc
                              0 };
    static WPARAM aHorz[] = { VK_END,   SB_BOTTOM,   // End   => Max
                              VK_HOME,  SB_TOP,      // Home  => Min
                              VK_PRIOR, SB_PAGEDOWN, // PgUp  => +LargeInc
                              VK_NEXT,  SB_PAGEUP,   // PgDn  => -LargeInc
                              VK_RIGHT, SB_LINEDOWN, // Right => +SmallInc
                              VK_LEFT,  SB_LINEUP,   // Left  => -SmallInc
                              0 };

    // -- initialize message type and lookup table
    if (GetWindowLong(ps->hwnd, GWL_STYLE) & SBS_VERT)
    {
        uMsg = WM_VSCROLL;
        pTable = aVert;
    }
    else
    {
        uMsg = WM_HSCROLL;
        pTable = aHorz;
    }

    // -- see if key means anything to us
    for (; *pTable && *pTable != wKey; pTable+=2) NULL;

    // -- send ourselves a scroll message if key is meaningful
    if (*pTable) PostMessage(ps->hwnd, uMsg, *(pTable+1), 0);
    return *pTable;
}

//-----------------------------------------------------------------------------
// SliderWndProc - Window Procedure
//-----------------------------------------------------------------------------

long CALLBACK SliderWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    PSLIDER ps;

    // -- make DGROUP addressable
    ULOADDS();

    // -- get instance data pointer
    ps = (PSLIDER)GetProp(hwnd, (LPCSTR)atomSlider);

    switch (uMsg)
    {
    HANDLE_MSG(ps, WM_CTLCOLORSCROLLBAR, OnCtlColor); //@pr4
    HANDLE_MSG(ps, WM_HSCROLL,           OnHScroll);
    HANDLE_MSG(ps, WM_VSCROLL,           OnVScroll);
    HANDLE_MSG(ps, WM_NCDESTROY,         OnNCDestroy);

    case WM_KEYDOWN:                                                 // @pr1 starts
        // -- if this is the Gold key or if we're in a Gold or Compose
        // -- sequence, do not process the message further.
        if (owiKeyFilter(ps->wmlink, hwnd, uMsg, wParam, lParam)) return 0;

        // -- if this key is interesting to us process it
        if (IsSliderKey(ps, wParam)) return 0;

        // -- else leave it to default processing
        break;                                                       // @pr1 ends
    }

    return owiDefWndProc(ps->wmlink, hwnd, uMsg, wParam, lParam, pfnScrollBarProc);
}

//-----------------------------------------------------------------------------
// SetAttribute - Change one attribute
//-----------------------------------------------------------------------------

static long SetAttribute(PSLIDER ps, int id, long v)
{
    COLORREF clr;
    int cx, cy;

    switch (id)
    {
    case OATT_ORIGIN:
        // -- move
        SetWindowPos(ps->hwnd, NULL, LOINT(v), HIINT(v), 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOZORDER);
        return SUCCESS;

    case OATT_SIZE:
        // -- resize
        cx = LOINT(v);
        cy = HIINT(v);
        if (!ps->bForceFit)
        {
            if (GetWindowLong(ps->hwnd, GWL_STYLE) & SBS_VERT) cx = GetSystemMetrics(SM_CXVSCROLL);
            else cy = GetSystemMetrics(SM_CYHSCROLL);
        }
        SetWindowPos(ps->hwnd, NULL, 0, 0, cx, cy, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOZORDER);
        return SUCCESS;

    case OATT_BACKGND:
        // -- set background color
        if (v < 0) clr = GetSysColor(COLOR_SCROLLBAR);
        else clr = (COLORREF)v;
        if (clr == ps->clrBack) return SUCCESS; // no change
        ps->clrBack = clr;
        // -- update the brush, then repaint
        if (ps->hbrBack) DeleteObject(ps->hbrBack);
        ps->hbrBack = CreateSolidBrush(ps->clrBack);
        InvalidateRect(ps->hwnd, NULL, FALSE);
        return SUCCESS;

    case OATT_ENABLED:
        // -- enable/disable ourselves
        EnableWindow(ps->hwnd, (BOOL)v && ps->fUnit != 0.0);
        return SUCCESS;

    case OATT_VISIBLE:
        // -- hide/show ourselves
        ShowWindow(ps->hwnd, v ? SW_SHOW : SW_HIDE);
        return SUCCESS;

    default:
        // -- unrecognized attribute
        return FAILURE;
    }
}

//-----------------------------------------------------------------------------
// SetAttr - Change attributes of a widget instance
//-----------------------------------------------------------------------------

static long SetAttr(struct owisetattr* pos)
{
    PSLIDER ps = (PSLIDER)(long)pos->hWidget;
    int  i;
    long lVal, lErr;

    // -- process all attributes
    for (lErr=i=0; i<pos->nAttr; i++)
    {
        lVal = SetAttribute(ps, pos->pAttr[i].id, pos->pAttr[i].d.i);
        if (lVal == FAILURE)
        {
            pos->pAttr[i].id = 0;
            lErr++;
        }
    }

    return lErr;
}

//-----------------------------------------------------------------------------
// GetAttribute - Get one attribute
//-----------------------------------------------------------------------------

static long GetAttribute(PSLIDER ps, int id)
{
    RECT r;

    switch (id)
    {
    case OATT_ORIGIN:
        // -- get position
        GetWindowRect(ps->hwnd, &r);
        MapWindowRect(NULL, GetParent(ps->hwnd), &r);
        return MAKELONG(r.left, r.top);

    case OATT_SIZE:
        // -- get size
        GetWindowRect(ps->hwnd, &r);
        return MAKELONG(r.right - r.left, r.bottom - r.top);

    case OATT_BACKGND:
        // -- get background color
        return (long)ps->clrBack;

    case OATT_ENABLED:
        // -- get enabled state
        return IsWindowEnabled(ps->hwnd);

    case OATT_VISIBLE:
        // -- get visible state
        return IsWindowVisible(ps->hwnd);

    default:
        // -- unrecognized attribute
        return FAILURE;
    }
}

//-----------------------------------------------------------------------------
// GetAttr - Get attributes of a widget instance
//-----------------------------------------------------------------------------

static long GetAttr(struct owigetattr* pog)
{
    PSLIDER ps = (PSLIDER)(long)pog->hWidget;
    int  i;
    long lVal, lErr;

    // -- process all attributes
    for (lErr=i=0; i<pog->nAttr; i++)
    {
        lVal = GetAttribute(ps, pog->pAttr[i].id);
        if (lVal == FAILURE)
        {
            pog->pAttr[i].id = 0;
            lErr++;
        }
        else pog->pAttr[i].d.i = lVal;
    }

    return (long)lErr;
}

//-----------------------------------------------------------------------------
// GetCapability - Get a capability of the Slider class
//-----------------------------------------------------------------------------

static long GetCapability(int id)
{
    switch (id)
    {
    case OCAP_GFPICON:
        // -- get GFP Bitmap
        return (long)(UINT)LoadBitmap(ULIBINST(), "SliderBmp");

//  Enable this code after "slider.frm" has been written
//
//  case OCAP_GFPFORM:
//      // -- get widget properties form name
//      return (long)"slider";

    case OCAP_SHOWFOCUS:
        // -- can we show we have focus
        return TRUE;

    default:
        // -- unrecognized attribute
        return FAILURE;
    }
}

//-----------------------------------------------------------------------------
// GetCaps - Get capabilities of the Slider class
//-----------------------------------------------------------------------------

static long GetCaps(struct owigetcaps* pog)
{
    int  i;
    long lVal, lErr;

    // -- process all capabilities
    for (lErr=i=0; i<pog->nAttr; i++)
    {
        lVal = GetCapability(pog->pAttr[i].id);
        if (lVal == FAILURE)
        {
            pog->pAttr[i].id = 0;
            lErr++;
        }
        else pog->pAttr[i].d.i = lVal;
    }

    return (long)lErr;
}

//-----------------------------------------------------------------------------
// NewData - Data has changed, update state and display
//-----------------------------------------------------------------------------

static long NewData(PSLIDER ps)
{
    if (!odGet(ps->wmlink, &ps->fValue, 1, OTYP_FLOAT))
    {
        // -- arbitrarily use minimum to represent NULL
        ps->fValue = ps->fMin;
    }

    // -- display new value
    UpdateDisplay(ps, ps->fValue);

    return SUCCESS;
}

//-----------------------------------------------------------------------------
// PutData - Move current value back to Uniface
//-----------------------------------------------------------------------------

static long PutData(PSLIDER ps)
{
    odPut(ps->wmlink, &ps->fValue, 1, OTYP_FLOAT);
    return SUCCESS;
}

//-----------------------------------------------------------------------------
// NewProps - Update properties
//-----------------------------------------------------------------------------

static long NewProps(PSLIDER ps)
{
    char szProp[32];
    UFLOAT fUnits;

    // -- minimum value
    ocpString(ps->wmlink, "min", szProp, sizeof(szProp));
    ps->fMin = atof(szProp);

    // -- maximum value
    ocpString(ps->wmlink, "max", szProp, sizeof(szProp));
    if (!*szProp) ps->fMax = 100.0;     // -- default to 100
    else ps->fMax = atof(szProp);

    // -- disable if range is empty
    EnableWindow(ps->hwnd, ps->fMax > ps->fMin);

    // -- unit increment
    ocpString(ps->wmlink, "resolution", szProp, sizeof(szProp));
    ps->fUnit = fabs(atof(szProp));
    if (ps->fUnit == 0.0) fUnits = 10000.0;
    else fUnits = (ps->fMax - ps->fMin) / ps->fUnit;
    if (fUnits == 0.0) ps->fUnit = 0.0;
    else ps->fUnit = (ps->fMax - ps->fMin) / fUnits;
    SetScrollRange(ps->hwnd, SB_CTL, 0, (int)(fUnits+0.5), FALSE);

    // -- small increment for clicking an arrow button
    ocpString(ps->wmlink, "smallinc", szProp, sizeof(szProp));
    ps->fLineInc = fabs(atof(szProp));
    if (ps->fLineInc == 0.0) ps->fLineInc = ps->fUnit;

    // -- large increment for clicking on elevator
    ocpString(ps->wmlink, "largeinc", szProp, sizeof(szProp));
    ps->fPageInc = fabs(atof(szProp));
    if (ps->fPageInc == 0.0) ps->fPageInc = ps->fLineInc * 10.0;

    // -- this may require a screen update
    UpdateDisplay(ps, ps->fValue);

    return SUCCESS;
}

//-----------------------------------------------------------------------------
// TakeFocus - Grab the Windows input focus
//-----------------------------------------------------------------------------

static long TakeFocus(PSLIDER ps)
{
    // -- set Windows input focus to us
    SetFocus(ps->hwnd);
    return SUCCESS;
}

//-----------------------------------------------------------------------------
// Command - Process a command from Uniface
//-----------------------------------------------------------------------------

static long Command(struct owicommand* poc)
{
    PSLIDER ps = (PSLIDER)(long)poc->hWidget;

    switch (poc->id)
    {
    case OCMD_NEWDATA:      return NewData(ps);
    case OCMD_PUTDATA:      return PutData(ps);
    case OCMD_NEWPROPS:     return NewProps(ps);
    case OCMD_TAKEFOCUS:    return TakeFocus(ps);
    default:                return FAILURE;
    }
}

//-----------------------------------------------------------------------------
// Create - Create a Slider instance
//-----------------------------------------------------------------------------

static long Create(struct owicreate *poc)
{
    PSLIDER ps;
    LONG lStyle;
    char szProp[32];
    int i;

    // -- allocate our instance data structure
    ps = (PSLIDER)LocalAlloc(LPTR, sizeof(ASLIDER));
    ps->wmlink = poc->wmlink;

    // -- compute window styles
    lStyle = WS_CHILD | WS_CLIPSIBLINGS;
    ocpString(poc->wmlink, "orientation", szProp, sizeof(szProp));
    if (!_strnicmp("vertical", szProp, strlen(szProp))) lStyle |= SBS_VERT;
    else lStyle |= SBS_HORZ;
    ps->bForceFit = ocpBool(poc->wmlink, "forcefit", FALSE);

    // -- create the window (invisibly)
    ps->hwnd = CreateWindow(szClass,
                             "",
                             lStyle,
                             0, 0,
                             0, 0,
                             (HWND)poc->hParent,
                             NULL,
                             UGETHINST(),
                             (void *)ps);

    // -- handle failure
    if (!ps->hwnd)
    {
        LocalFree(ps);
        poc->hWidget = 0;
        return FAILURE;
    }

    // -- attach instance data as window property
    SetProp(ps->hwnd, (LPCSTR)atomSlider, ps);

    // -- subclass the control
    pfnScrollBarProc = (WNDPROC)SetWindowLong(ps->hwnd, GWL_WNDPROC, (LONG)SliderWndProc);

    // -- process initial attributes and properties
    for (i=0; i<poc->nAttr; i++) SetAttribute(ps, poc->pAttr[i].id, poc->pAttr[i].d.i);
    NewProps(ps);

    // -- all done
    poc->hWidget = (HWIDGET)ps;
    return SUCCESS;
}

//-----------------------------------------------------------------------------
// Destroy - Destroy a Slider instance
//-----------------------------------------------------------------------------

static long Destroy(struct owidestroy *pod)
{
    PSLIDER ps = (PSLIDER)(long)pod->hWidget;

    DestroyWindow(ps->hwnd);            // Window will clean up in WM_NCDESTROY
    return SUCCESS;
}

//-----------------------------------------------------------------------------
// Open - Open the widget class for a client process
//-----------------------------------------------------------------------------

static long Open(struct owiopen *poo)
{
    // -- register an atom for the window property
    atomSlider = GlobalAddAtom("Slider");

    // -- we don't use hClient in Windows
    poo->hClient = 0;
    return SUCCESS;
}

//-----------------------------------------------------------------------------
// Close - Close the widget class for a client process
//-----------------------------------------------------------------------------

static long Close(struct owiclose *poc)
{
    // -- delete resources
    GlobalDeleteAtom(atomSlider);
    return SUCCESS;
}

//-----------------------------------------------------------------------------
// SLIDER - Widget Entrypoint
//-----------------------------------------------------------------------------

XEXPORT(long) SLIDER(union owirequest *o) // @pr3
{
    switch (o->request)
    {
    case OREQ_OPEN:     return Open(&o->open);
    case OREQ_CLOSE:    return Close(&o->close);
    case OREQ_CREATE:   return Create(&o->create);
    case OREQ_DESTROY:  return Destroy(&o->destroy);
    case OREQ_SETATTR:  return SetAttr(&o->setattr);
    case OREQ_GETATTR:  return GetAttr(&o->getattr);
    case OREQ_GETCAPS:  return GetCaps(&o->getcaps);
    case OREQ_COMMAND:  return Command(&o->command);
    default:            return FAILURE;
    }
}

// END SLIDER.C
