/* CONT_VERSION_ID("@(#)CONT_ID %fv: % %dc: % (#)@") */ 
//---------------------------------------------------------------------------
// ASYNC
//
// Sample illustrating the recognition of events and the firing of the
// <ASYNC> trigger. Note that the MMEDIA sample has another example with
// basically the same structure, but specifically for MCI events.
//
// Copyright (c) Uniface 1994. All rights reserved.
//
// You have a royalty-free right to use, modify, reproduce and distribute
// this sample code (and/or any modified version) in any way you find useful,
// provided that you agree that Uniface has no warranty obligations or
// liability for any sample code which has been modified.
//
//-seq--chg#--date----who--description---------------------------------------
//   0  6042  940620  hvv  created
//---------------------------------------------------------------------------

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <umsw3gl.h>

#define TIMER_ID   1                   // Timer id (arbitrary)
#define TIMER_SEC  60                  // Timer interval in sec

//---------------------------------------------------------------------------
// GLOBALS
//---------------------------------------------------------------------------

static HWND hwndNotify;                // Hidden window to sniff events

//---------------------------------------------------------------------------
// NotifyWndProc - Window procedure for notifications
//---------------------------------------------------------------------------

long XCALLBACK NotifyWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    char szMessage[40], *pszAsync = NULL;

    // -- Important: Establish private DGROUP addressability in callbacks!
    ULOADDS();

    switch (uMsg)
    {
    // -- System notifications

    case WM_COMPACTING:
        pszAsync = "SYS:Memory is low";
        break;
    case WM_FONTCHANGE:
        pszAsync = "SYS:The font pool has been updated";
        break;
    case WM_PALETTECHANGED:
        pszAsync = "SYS:The video color palette has changed";
        break;
    case WM_POWER:
        if (wParam == PWR_SUSPENDREQUEST) pszAsync = "SYS:The system is about to be suspended";
        else pszAsync = "SYS:The system has just resumed";
        break;
    case WM_SYSCOLORCHANGE:
        pszAsync = "SYS:System colors have changed";
        break;
    case WM_WININICHANGE:
        pszAsync = "SYS:The WIN.INI settings have changed";
        break;

    // -- Clock notifications

    case WM_TIMECHANGE:
        pszAsync = "CLK:Date and/or time have been adjusted";
        break;
    case WM_TIMER:
        sprintf(szMessage, "CLK:%d seconds have elapsed", TIMER_SEC);
        pszAsync = szMessage;
        break;
    }

    // -- Fire the ASYNC trigger if the event is interesting enough
    if (pszAsync) UPUTAMES(pszAsync, strlen(pszAsync));

    // -- Regardless of the message, we leave the handling to Windows
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

//---------------------------------------------------------------------------
// InstallNotificationHandler - Create the hidden toplevel notification window
//---------------------------------------------------------------------------

static int InstallNotificationHandler(void)
{
    WNDCLASS cls;

    // -- Register the window class
    cls.style         = 0;
    cls.lpfnWndProc   = (WNDPROC)UMAKEPROCINST((UPROC)NotifyWndProc);
    cls.cbClsExtra    = 0;
    cls.cbWndExtra    = 0;
    cls.hInstance     = UGETHINST();
    cls.hIcon         = NULL;
    cls.hCursor       = NULL;
    cls.hbrBackground = NULL;
    cls.lpszMenuName  = NULL;
    cls.lpszClassName = "AsyncNotify";

    if (!RegisterClass(&cls)) return FAILURE;

    // -- Class registration ok; Create the window
    hwndNotify = CreateWindow("AsyncNotify",      // Class
                              NULL,               // Name
                              WS_POPUPWINDOW,     // Style
                              0, 0,               // Pos
                              0, 0,               // Size
                              NULL,               // Parent
                              NULL,               // Menu
                              UGETHINST(),        // Module
                              NULL);              // Params
    if (!hwndNotify) return FAILURE;

    // -- Install a timer that ticks every so often
    if (!SetTimer(hwndNotify, TIMER_ID, TIMER_SEC * 1000u, NULL))
    {
        DestroyWindow(hwndNotify);
        hwndNotify = NULL;
        return FAILURE;
    }

    return SUCCESS;
}

//---------------------------------------------------------------------------
// RemoveNotificationHandler - Destroy the notification window
//---------------------------------------------------------------------------

static void RemoveNotificationHandler(void)
{
    if (hwndNotify)
    {
        KillTimer(hwndNotify, TIMER_ID);
        DestroyWindow(hwndNotify);
    }
}

//---------------------------------------------------------------------------
// UDLLEVENT - Handle DLL load/unload events.
//
// in:  wEvent     Event code:
//                   UEVT_INITDLL      The DLL is loaded by Windows
//                   UEVT_INITCLIENT   A Uniface app connects to the DLL
//                   UEVT_INITGUI      Interactive mode starts
//                   UEVT_EXITGUI      Interactive mode ends
//                   UEVT_EXITCLIENT   A Uniface app disconnects from the DLL
//                   UEVT_EXITDLL      The DLL is unloaded by Windows
//
// ret:            SUCCESS   Accept the load or connect attempt
//                 FAILURE   Reject the load or connect attempt
//                 Ignored for other events
//---------------------------------------------------------------------------

short X3GL UDLLEVENT(short sEvent)
{
   switch (sEvent)
   {
   case UEVT_INITGUI:
      // -- Start of interactive session - start sniffing events
      return InstallNotificationHandler();

   case UEVT_EXITGUI:
      // -- End of interactive session - destroy sniffer window
      RemoveNotificationHandler();
      break;
   }
   return SUCCESS;
}

// END ASYNC.C
