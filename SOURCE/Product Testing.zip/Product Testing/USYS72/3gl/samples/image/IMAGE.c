/* CONT_VERSION_ID("@(#)CONT_ID %fv: % %dc: % (#)@") */
//---------------------------------------------------------------------------
// IMAGE
//
// Sample illustrating a user defined image type (I0).
// The same result can be achieved by writing a graphics filter to the
// Aldus standard (development kit available from Aldus).
//
// Copyright (c) Uniface 1994. All rights reserved.
//
// You have a royalty-free right to use, modify, reproduce and distribute
// this sample code (and/or any modified version) in any way you find useful,
// provided that you agree that Uniface has no warranty obligations or
// liability for any sample code which has been modified.
//
//-seq--chg#--date----who--description---------------------------------------
//   0  6042  940620  hvv  created
//   1  8027  950719  tw   use new XEXPORT definition
//   2 10249  950824  tw   port to NT
//---------------------------------------------------------------------------

#include <windows.h>
#include <string.h>
#include <stdlib.h>
#include <umsw3gl.h>

//---------------------------------------------------------------------------
// uImage0 - Sample implementation of image datatype "I0".
//
// in:  pImage     Pointer to contents of image field
//      hImage     Global memory handle to contents of image field
//      cx         Width of target image field
//      cy         Height of target image field
// ret:            Bitmap handle in lower 16 bits
//
// This sample function accepts input in a "#resourcename" format and
// returns the bitmap with that name from the DLL resource table. The
// resourcename may optionally be followed by any number of ",iconname,x,y"
// triplets; the icons will be drawn on the bitmap. E.g.:
//
//      "#PLAN,IL,87,66,BLK,193,124"
//
// Loads bitmap resource PLAN and draws on it the icons IL centered at
// (87,66) and BLK at (193,124).
//
// Other implementations could:
//   1- Accept input in the "@filename" format, read the file and convert
//      it to a Device Dependent Bitmap,
//   2- Convert the input into a DDB directly, e.g. by interpreting
//      it as pixels or a series of drawing commands.
//
//---------------------------------------------------------------------------

XEXPORT(long) UIMAGE0(USTRING *pImage, HANDLE hImage, int cx, int cy) // @pr1, @pr2
{
   HBITMAP hbm, hbmSave;
   HDC     hdcScr, hdcMem;
   HICON   hIcon;
   LPSTR   pToken;
   int     iX, iY;

   // -- Check for initial # sign
   if (!pImage || *pImage != '#') return (long)NULL; //@pr2

   // -- Extract name of bitmap and attempt to load it
   if (!(pToken = strtok(pImage+1, ", "))) return (long)NULL; //@pr2
   hbm = LoadBitmap(ULIBINST(), pToken);
   if (!hbm) return (long)NULL; //@pr2

   // -- Setup a DC to write on the bitmap
   hdcScr = GetDC(NULL);
   hdcMem = CreateCompatibleDC(hdcScr);
   ReleaseDC(NULL, hdcScr);
   if (!hdcMem) return (long)NULL; //@pr2
   hbmSave = SelectObject(hdcMem, hbm);

   // -- Loop to extract Icon,X,Y triples
   while (pToken = strtok(NULL, ", "))
   {
      hIcon = LoadIcon(ULIBINST(), pToken);
      if (pToken = strtok(NULL, ", ")) iX = atoi(pToken);
      if (pToken = strtok(NULL, ", ")) iY = atoi(pToken);

      // -- Draw the icon on the bitmap, then delete it. The icon is
      // -- assumed to be 32x32 pixels and centered.
      DrawIcon(hdcMem, iX-16, iY-16, hIcon);
      DestroyIcon(hIcon);
   }

   // -- Clean up
   SelectObject(hdcMem, hbmSave);
   DeleteDC(hdcMem);

   // -- Return DDB handle in bits 0 thru 15
   return MAKELONG(hbm, 0);
}

// END IMAGE.C
