/* CONT_VERSION_ID("@(#)CONT_ID %fv: % %dc: % (#)@") */
//---------------------------------------------------------------------------
// MMEDIA
//
// This sample defines two "performable" functions, uPlaySound and uMci,
// that provide an easy to use interface to the multimedia support built
// into Windows 3.1.
//
// Copyright (c) Uniface 1994. All rights reserved.
//
// You have a royalty-free right to use, modify, reproduce and distribute
// this sample code (and/or any modified version) in any way you find useful,
// provided that you agree that Uniface has no warranty obligations or
// liability for any sample code which has been modified.
//
//---------------------------------------------------------------------------

#include <windows.h>
#include <mmsystem.h>
#include <string.h>
#include <umsw3gl.h>

//---------------------------------------------------------------------------
// CONSTANTS
//---------------------------------------------------------------------------

#define REG_PARAM1    50               // $50 used for input parameter
#define REG_RESULT   101               // $result used to return results

#define MS    128                      // Max number of chars in strings
#define MB    2048                     // "Big" buffer size

//---------------------------------------------------------------------------
// GLOBALS
//---------------------------------------------------------------------------

static HWND hwndNotify;                // Hidden window to catch MCI events

//---------------------------------------------------------------------------
// NotifyWndProc - Window procedure for notifications
//---------------------------------------------------------------------------

long XCALLBACK NotifyWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    char *pszAsync = NULL;

    // -- Important: Establish private DGROUP addressability in callbacks!
    ULOADDS();

    switch (uMsg)
    {
    // -- MCI notifications
    case MM_MCINOTIFY:
       switch (wParam)
       {
       case MCI_NOTIFY_SUCCESSFUL:
          pszAsync = "MCI:SUCCESS";
          break;
       case MCI_NOTIFY_SUPERSEDED:
          pszAsync = "MCI:SUPERSEDED";
          break;
       case MCI_NOTIFY_ABORTED:
          pszAsync = "MCI:ABORTED";
          break;
       case MCI_NOTIFY_FAILURE:
          pszAsync = "MCI:FAILURE";
          break;
       }
    }

    // -- Fire the ASYNC trigger if the event is interesting enough
    if (pszAsync) UPUTAMES(pszAsync, (short)strlen(pszAsync));

    // -- Regardless of the message, we leave the handling to Windows
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

//---------------------------------------------------------------------------
// InstallNotificationHandler - Create the hidden toplevel notification window
//---------------------------------------------------------------------------

static short InstallNotificationHandler(void)
{
    WNDCLASS cls;

    // -- Register the window class
    cls.style         = 0;
    cls.lpfnWndProc   = (WNDPROC)UMAKEPROCINST((UPROC)NotifyWndProc);
    cls.cbClsExtra    = 0;
    cls.cbWndExtra    = 0;
    cls.hInstance     = UGETHINST();
    cls.hIcon         = NULL;
    cls.hCursor       = NULL;
    cls.hbrBackground = NULL;
    cls.lpszMenuName  = NULL;
    cls.lpszClassName = "MciNotify";

    if (!RegisterClass(&cls)) return FAILURE;

    // -- Class registration ok; Create the window
    hwndNotify = CreateWindow("MciNotify",        // Class
                              NULL,               // Name
                              WS_POPUPWINDOW,     // Style
                              0, 0,               // Pos
                              0, 0,               // Size
                              NULL,               // Parent
                              NULL,               // Menu
                              UGETHINST(),        // Module
                              NULL);              // Params
    if (!hwndNotify) return FAILURE;

    return SUCCESS;
}

//---------------------------------------------------------------------------
// RemoveNotificationHandler - Destroy the notification window
//---------------------------------------------------------------------------

static short RemoveNotificationHandler(void)
{
    if (hwndNotify) DestroyWindow(hwndNotify);
    return SUCCESS;
}

//---------------------------------------------------------------------------
// uPlaySound - Plays a .WAV file if a wave device (e.g. SoundBlaster or PC
//              speaker driver) is installed in the system.
//
// in:  $50      name of .WAV file to play, optionally followed by one of the
//               following option flags:
//                 /async      does not wait for completion of playback
//                 /nodefault  does not play default sound if file not found
//                 /loop       plays sound continuously (requires /async)
//                 /nostop     does not wait for previous sound to end
// out: $status  0 for success, -1 for failure
//---------------------------------------------------------------------------

XEXPORT(long) UPLAYSOUND(void)
{
   char szWav[MS], *pszWav, *pszOpt;
   WORD wFlags;

   /* Get the filename and optional options */
   UGETREGS(REG_PARAM1, szWav, MS-1);

   /* Parse filename */
   pszWav = strtok(szWav, "/");
   if (!pszWav) return FAILURE;
   if (!*pszWav) pszWav = NULL;

   /* Parse options, if any */
   wFlags = SND_SYNC;
   while (pszOpt = strtok(NULL, "/"))
   {
      if (!_strcmpi(pszOpt, "ASYNC")) wFlags |= SND_ASYNC;
      else if (!_strcmpi(pszOpt, "NODEFAULT")) wFlags |= SND_NODEFAULT;
      else if (!_strcmpi(pszOpt, "LOOP")) wFlags |= SND_LOOP;
      else if (!_strcmpi(pszOpt, "NOSTOP")) wFlags |= SND_NOSTOP;
   }

   /* Try to play */
   if (sndPlaySound(pszWav, wFlags)) return SUCCESS;
   else return FAILURE;
}

//---------------------------------------------------------------------------
// uMci - Executes one or more MCI commands. Asynchronous MCI notifications
//        will be delivered to the <ASYNC> trigger.
//
//
// in:  $50      MCI command string(s), separated with newlines. Refer to
//               the Windows MCI Command Reference for syntax.
// out: $result  Result string and/or error message(s)
//      $status  0 for success, -1 for failure
//---------------------------------------------------------------------------

XEXPORT(long) UMCI(void)
{
   DWORD  dwResult;
   long   lResult = SUCCESS;
   char   szCmd[MB], *pszCmd, szTmp[MB], szRes[MB];

   // -- Get the command string(s) and initialize the output buffer
   UGETREGS(REG_PARAM1, szCmd, MB-1);
   szRes[0] = '\0';

   // -- Parse first command string
   pszCmd = strtok(szCmd, "\r");
   while (pszCmd && lResult == SUCCESS)
   {
      // -- Attempt to execute the command
      dwResult = mciSendString(pszCmd, szTmp, MB, hwndNotify);

      if (dwResult)
      {
         // -- An error occurred. Add error message to the output and fail
         mciGetErrorString(dwResult, szTmp, MB);
         lResult = FAILURE;
      }

      // -- Add result string, if any, to the cumulative result buffer.
      if (szTmp[0])
      {
         if (szRes[0]) strcat(szRes, "\r");
         strcat(szRes, szTmp);
      }

      // -- Parse next command string
      pszCmd = strtok(NULL, "\r");
   }

   UPUTREGS(REG_RESULT, szRes);
   return lResult;
}

//---------------------------------------------------------------------------
// UDLLEVENT - Handle DLL load/unload events.
//
// in:  wEvent     Event code:
//                   UEVT_INITDLL      The DLL is loaded by Windows
//                   UEVT_INITCLIENT   A Uniface app connects to the DLL
//                   UEVT_INITGUI      Interactive mode starts
//                   UEVT_EXITGUI      Interactive mode ends
//                   UEVT_EXITCLIENT   A Uniface app disconnects from the DLL
//                   UEVT_EXITDLL      The DLL is unloaded by Windows
//
// ret:            SUCCESS   Accept the load or connect attempt
//                 FAILURE   Reject the load or connect attempt
//                 Ignored for other events
//---------------------------------------------------------------------------

short X3GL UDLLEVENT(short sEvent)
{
   switch (sEvent)
   {
   case UEVT_INITGUI:
      // -- Start of interactive session - start sniffing events
      return InstallNotificationHandler();

   case UEVT_EXITGUI:
      // -- End of interactive session - destroy sniffer window
      return RemoveNotificationHandler();
      break;
   }
   return SUCCESS;
}

// END MMEDIA.C
