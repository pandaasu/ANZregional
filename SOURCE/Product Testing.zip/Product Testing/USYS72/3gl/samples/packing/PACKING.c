/* CONT_VERSION_ID("@(#)CONT_ID %fv: % %dc: % (#)@") */
//---------------------------------------------------------------------------
// PACKING
//
// This sample illustrates how to implement userdefined packing codes in the
// Windows environment.
//
// Copyright (c) Uniface 1994. All rights reserved.
//
// You have a royalty-free right to use, modify, reproduce and distribute
// this sample code (and/or any modified version) in any way you find useful,
// provided that you agree that Uniface has no warranty obligations or
// liability for any sample code which has been modified.
//
//-seq--chg#--date----who--description---------------------------------------
//   0  6042  940620  hvv  created
//   1  8491  950510  hvv  fixed to conform to CHG#5595
//   2 10249  950824  tw   ported to NT
//   3 14484  970205  wbe  add uctrl in ZPACKZ()
//---------------------------------------------------------------------------

#include <string.h>
#include <stdlib.h>
#include <umsw3gl.h>

//---------------------------------------------------------------------------
// uPackY - User defined numeric data packing
//
// in:  uctrl      Control block pointer
//      cFunc      Function code, see below
//      iPack      Packing code Yn.m encoded as (n + 100 * m)
//      pSrc       Source pointer (only valid for R and W)
//      pDst       Destination pointer (only valid for R and W)
//
// return:
//      int        Data length (L, R and W) or data type (T)
//
// functions:
//      L          Return (fixed) length of packed data
//      T          Return type of packed data: S=string, B=binary/raw
//      R          Convert DBMS data at pSrc to TRX data at pDst,
//                   return destination length or 0 for NULL
//      W          Convert TRX data at pSrc to DBMS data at pDst,
//                   return destination length
//---------------------------------------------------------------------------

XEXPORT(int) UPACKY(UCTRL uctrl, int cFunc, int iPack, UARRAY *pSrc, UARRAY *pDst)  //@pr2
{
    int i, iScale;
    long n;

    iScale = iPack / 100;

    switch (iPack % 100)
    {
    case 1: // -- Y1.n packing is n bytes space-padded TRX
        if (!iScale) iScale = 4;
        switch (cFunc)
        {
        case 'L':
            return iScale;

        case 'T':
            // -- Request string storage because output is ASCII
            return 'S';

        case 'R':
            // -- Copy up to iScale bytes and a null terminator
            for (i = 0; i < iScale && *pSrc; *pDst++ = *pSrc++, i++) NULL;
            *pDst = 0;
            return i;                  // returns 0..iScale

        case 'W':
            // -- Copy up to iScale bytes
            for (i = 0; i < iScale && *pSrc; *pDst++ = *pSrc++, i++) NULL;

            // -- Pad with space characters
            for (; i < iScale; *pDst++ =  ' ', i++) NULL;
            return i;                  // always returns iScale
        }
        break;

    case 2: // -- Y2.n packing is n bytes little endian
        if (!iScale) iScale = 4;
        if (iScale > sizeof(long)) iScale = sizeof(long);
        switch (cFunc)
        {
        case 'L':
            return iScale;

        case 'T':
            // -- Request raw storage
            return 'B';

        case 'R':
            // -- Read iScale bytes in signed little endian format
            for (n = 0, i = 0; i < sizeof(long); i++)
            {
                n >>= 8;
                if (i < iScale)
                {
                    n &= (1L << (8*sizeof(long)-8)) - 1;
                    n |= ((long)*pSrc++) << (8*sizeof(long)-8);
                }
            }

            // -- Convert binary to decimal string
            _ltoa(n, pDst, 10);
            return strlen(pDst);

        case 'W':
            // -- Convert decimal string to binary
            n = atol(pSrc);

            // -- Store iScale bytes in little endian
            for (i = 0; i < iScale; i++)
            {
                *pDst++ = (unsigned char)(n & 0xff);
                n >>= 8;
            }
            return i;                  // always returns iScale
        }
        break;
    }

    // -- Return 0 for unsupported packing codes and unsupported functions
    return 0;
}

//---------------------------------------------------------------------------
// uPackZ - User defined date/time data packing.
//
// in:  uctrl      Control block pointer
//      cFunc      Function code, see below
//      iPack      Packing code Zn encoded as (n)
//      pSrc       Source pointer (only valid for R and W)
//      pDst       Destination pointer (only valid for R and W)
//
// return:
//      int        Data length (L, R and W) or data type (T)
//
// functions:
//      L          Return (max) length of packed data
//      T          Return type of packed data: S=string, B=binary/raw
//      R          Convert DBMS data at pSrc to TRX data at pDst,
//                   return destination length or 0 for NULL
//      W          Convert TRX data at pSrc to DBMS data at pDst,
//                   return destination length
//---------------------------------------------------------------------------

XEXPORT(int) UPACKZ(UCTRL uctrl, short cFunc, short iPack, UARRAY *pSrc, UARRAY *pDst)   //@pr2, @pr3
{
    unsigned n;

    switch (iPack)
    {
    case 1: // -- Z1 packing is 2 bytes binary date (1970-2069)
        switch (cFunc)
        {
        case 'L':
            return 2;

        case 'T':
            // -- Request raw storage
            return 'B';

        case 'R':
            // -- Read 2 bytes in unsigned little endian format
            n = 256 * (int)pSrc[1] + pSrc[0];

            // -- Decode into century, year, month, day
            pDst[3] = (n % 31) + 1 + ' ';
            n = n / 31;
            pDst[2] = (n % 12) + 1 + ' ';
            n = n / 12 + 1970;
            pDst[1] = (n % 100) + ' ';
            n = n / 100;
            pDst[0] = n + ' ';

            // -- No time
            pDst[4] = pDst[5] = pDst[6] = pDst[7] = ' ';

            // -- Terminate
            pDst[8] = 0;
            return 8;

        case 'W':
            // -- Pack date
            n = pSrc[0] - ' ';
            n = n * 100;
            n = n + pSrc[1] - ' ';
            n = (n - 1970) * 12;
            n = n + pSrc[2] - ' ' - 1;
            n = n * 31;
            n = n + pSrc[3] - ' ' - 1;

            // -- Store as 2 bytes, little endian
            pDst[0] = n % 256;
            pDst[1] = n / 256;
            return 2;
        }
        break;

    case 2: // -- Z2 packing is 2 bytes binary time (resolution 2 secs)
        switch (cFunc)
        {
        case 'L':
            return 2;

        case 'T':
            // -- Request raw storage
            return 'B';

        case 'R':
            // -- Read 2 bytes in unsigned little endian format
            n = 256 * (int)pSrc[1] + pSrc[0];

            // -- Decode into hours, minutes, seconds
            pDst[6] = (n % 30) * 2 + ' ';
            n = n / 30;
            pDst[5] = (n % 60) + ' ';
            n = n / 60;
            if (!n) n = 24;
            pDst[4] = n + ' ';

            // -- No ticks, no date
            pDst[0] = pDst[1] = pDst[2] = pDst[3] = pDst[7] = ' ';

            // -- Terminate
            pDst[8] = 0;
            return 8;

        case 'W':
            // -- Pack time
            n = pSrc[4] - ' ';
            if (n == 24) n = 0;
            n = n * 60;
            n = n + pSrc[5] - ' ';
            n = n * 30;
            n = n + (pSrc[4] - ' ') / 2;

            // -- Store as 2 bytes, little endian
            pDst[0] = n % 256;
            pDst[1] = n / 256;
            return 2;
        }
        break;
    }

    // Return 0 for unsupported packing codes and unsupported functions
    return 0;
}

// END PACKING.C
