/* CONT_VERSION_ID("@(#)CONT_ID %fv: environ.c-2 % %dc: Mon Mar 16 14:58:01 1998 % (#)@") */
//---------------------------------------------------------------------------
// ENVIRON
//
// This DLL provides some trivial but useful "perform" functions that access
// the UNIFACE system environment, notably the profile and the transcript.
//
// Copyright (c) Uniface 1994. All rights reserved.
//
// You have a royalty-free right to use, modify, reproduce and distribute
// this sample code (and/or any modified version) in any way you find useful,
// provided that you agree that Uniface has no warranty obligations or
// liability for any sample code which has been modified.
//
//---------------------------------------------------------------------------

#include <windows.h>
#include <stdio.h>
#include <umsw3gl.h>

//---------------------------------------------------------------------------
// CONSTANTS
//---------------------------------------------------------------------------

#define REG0  50                       // Register numbers for communication
#define REG1  REG0 + 1
#define REG2  REG0 + 2

#define MS    128                      // Max number of chars in strings

//---------------------------------------------------------------------------
// uTranscript - Writes a string to the transcript window.
//
// in: $50   String to write
//---------------------------------------------------------------------------

XEXPORT(long)   UTRANSCRIPT(void)
{
    char szMsg[MS];

    UGETREGS(REG0, szMsg, MS-1);
    UPRINTF("4GL> %s\n", szMsg);

    return SUCCESS;
}

//---------------------------------------------------------------------------
// uReadProfile - Reads a string from the .ini file
//
// in:  $50   Section
//      $51   Keyword
// out: $52   String value read from .ini
//---------------------------------------------------------------------------

XEXPORT(long) UREADPROFILE(void)
{
    char szSection[MS];
    char szKeyword[MS];
    char szValue[MS];

    UGETREGS(REG0, szSection, MS-1);
    UGETREGS(REG1, szKeyword, MS-1);
    GetPrivateProfileString(szSection, szKeyword, "", szValue, MS, UGETPROFILE());
    UPUTREGS(REG2, szValue);

    return SUCCESS;
}

//---------------------------------------------------------------------------
// uWriteProfile - Writes a string to the .ini file
//
// in:  $50   Section
//      $51   Keyword
//      $52   String value to write
//---------------------------------------------------------------------------

XEXPORT(long) UWRITEPROFILE(void)
{
    char szSection[MS];
    char szKeyword[MS];
    char szValue[MS];

    UGETREGS(REG0, szSection, MS-1);
    UGETREGS(REG1, szKeyword, MS-1);
    UGETREGS(REG2, szValue, MS-1);
    WritePrivateProfileString(szSection, szKeyword, szValue, UGETPROFILE());

    return SUCCESS;
}

// END ENVIRON.C
