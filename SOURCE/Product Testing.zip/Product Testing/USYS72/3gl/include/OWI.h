/* @(#)CONT_ID %fv: owi.h-6 % %dc: Mon May 11 16:19:13 1998 % (#)@ */
/***************************************************************************\
* Open Widget Interface public definitions                                  *
*                                                                           *
* file     OWI.H                                                            *
* version  1.44                                                             *
*-pr--bug---ddmmyy----who------summary--------------------------------------*
* 1  14185  120996    JdK      Added the OATT_NEWPARENT.                    *
* 2  16227  020497    PBK      Changed UDATE to UNIDATE(conflicted with SDK)*
* 3  17641  150597    PBR      Added ONTF_NOTEBOOKVALUECHANGED              *
* 4  17552  040697    PBR      Added OLAY_DIRECTION                         *
* 5  19870  220498    wbe      Implement IsWidgetKey                        *
\***************************************************************************/

#ifndef OWI_H
#define OWI_H


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "utypes.h"

/***************************************************************************/
/* DEPENDENCIES                                                            */
/***************************************************************************/

/* The following types must be defined prior to including this file:       */

/* WMLINK     typedef struct _widinst *WMLINK;                             */
/* UCOLOR     platform dependent color (usually RGB encoded)               */
/* HPARENT    platform dependent (parent) window handle                    */
/* HWIDGET    platform dependent OWI widget handle (usually void*)         */
/* HCLIENT    platform dependent client process id (optional)              */
/* HANCHOR    platform dependent global context handle (optional)          */

/***************************************************************************/
/* CONSTANTS                                                               */
/***************************************************************************/

/* Data type IDs */

#define OTYP_STR                 1     /* null terminated string (conceptual format) */
#define OTYP_NUMBER              2     /* signed long integer */
#define OTYP_FLOAT               3     /* floating point */
#define OTYP_DATE                4     /* date (days since jan 1, 1970) */
#define OTYP_TIME                5     /* time (fractional days) */
#define OTYP_DATIM               6     /* date-time */
#define OTYP_RAW                 7     /* binary */
#define OTYP_BOOL                8     /* boolean */
#define OTYP_LDATE               9     /* linear date */
#define OTYP_LTIME               10    /* linear time */
#define OTYP_LDATIM              11    /* linear date-time */
#define OTYP_IMAGE               12    /* image (@filename, ^glyph or #blob) */
#define OTYP_NULL                13    /* null value */

/* Data option (must be or-ed in with a proper OTYP_*) */

#define OTYP_NATIVE              32    /* (all types) usm handle to data in native format */

/* Attribute IDs */
                                       /* TYPE       UNIT      SUMMARY */
#define OATT_ORIGIN              1     /* 2 shorts   pixels    upper left corner */
#define OATT_SIZE                2     /* 2 shorts   pixels    total widget size */
#define OATT_FOREGND             3     /* color      RGB       foreground color */
#define OATT_BACKGND             4     /* color      RGB       background color */
#define OATT_READONLY            5     /* long       Boolean   value is not editable */
#define OATT_NOECHO              6     /* long       Boolean   no input echo (password) */
#define OATT_RTL                 7     /* long       Boolean   right-to-left text - NOT USED */
#define OATT_ENABLED             8     /* long       Boolean   widget is enabled for input */
#define OATT_VISIBLE             9     /* long       Boolean   widget is visible */
#define OATT_FONT                10    /* string     name      font to use for widget - NOT USED */
#define OATT_DATATYPE            11    /* long       OTYP_*    datatype of field */
#define OATT_XPARENT             12    /* color      RGB       transparent color */
#define OATT_STATE               13    /* long       any       widget state info */
#define OATT_PROTOTYPE           14    /* long       Boolean   prototype mode */
#define OATT_FILLRECT            15    /* long       Boolean   Widget fills complete area as defined in gfp */
#define OATT_NEWPARENT           16    /* long       HWND      Windowhandle of the new parent */

#define OATT_LABEL               1000  /* label specific attributes start here */
#define OATT_GFP                 2000  /* form painter specific attributes start here */
#define OATT_PLATFORM            3000  /* platform specific attributes start here */
#define OATT_PRINT               3500  /* print attributes start here */
#define OATT_USER                4000  /* user defined attributes start here */

#define OATT_LABELFONT           1001  /* string     name      font to use for label - NOT USED */
#define OATT_LORIGIN             1002  /* 2 shorts   pixels    origin of label */
#define OATT_LSIZE               1003  /* 2 shorts   pixels    size of label */
#define OATT_LHALIGN             1004  /* long       (*)       horizontal alignment */
#define OATT_LVALIGN             1005  /* long       (*)       vertical alignment */
#define OATT_LFOREGND            1006  /* color      RGB       foreground color */
#define OATT_LBACKGND            1007  /* color      RGB       background color */
#define OATT_LXPARENT            1008  /* color      RGB       transparent color */
#define OATT_LHILITE             1009  /* long       Boolean   highlight label (focus) */

#define OATT_GFPMODE          OATT_GFP /* long       Boolean   Widget created by Graphical Form Painter */

#define OATT_PRINTMODE           OATT_PRINT        /* long  Boolean   Widget created by print driver */
#define OATT_PRINTDEPTH         (OATT_PRINT + 1)   /* long  pixels    Height required to print complete widget */
#define OATT_PRINTMINDEPTH      (OATT_PRINT + 2)   /* long  pixels    Mimimal height the widget can print */

/* Attribute values */

#define OATT_LHALIGN_LEFT        0     /* left aligned */
#define OATT_LHALIGN_CENTER      1     /* centered */
#define OATT_LHALIGN_RIGHT       2     /* right aligned */

#define OATT_LVALIGN_TOP         0     /* top aligned */
#define OATT_LVALIGN_CENTER      1     /* centered */
#define OATT_LVALIGN_BOTTOM      2     /* bottom aligned */

/* Capability IDs */
                                       /* TYPE       UNIT      SUMMARY */
#define OCAP_FOCUS               1     /* long       Boolean   widget can accept focus */
#define OCAP_SHOWFOCUS           2     /* long       Boolean   widget can show it has focus */
#define OCAP_MINSIZE             3     /* 2 shorts   pixels    minimum widget size */
#define OCAP_MAXSIZE             4     /* 2 shorts   pixels    maximum widget size */
#define OCAP_DEFSIZE             5     /* 2 shorts   pixels    default widget size */

#define OCAP_LABELPOS            1001  /* long       (*)       supported relative label positions */

#define OCAP_GFPICON             2001  /* long                 bitmap for form painter */
#define OCAP_GFPFORM             2002  /* string     name      form to use for widget properties */
#define OCAP_GFPALLOW            2003  /* long       Boolean   allow widget to be painted */

#define OCAP_LABEL               1000  /* label specific capabilities start here */
#define OCAP_GFP                 2000  /* form painter specific capabilities start here */
#define OCAP_PLATFORM            3000  /* platform specific capabilities start here */
#define OCAP_PRINT               3500  /* print capabilities start here */
#define OCAP_USER                4000  /* user defined capabilities start here */

/* Capability values */

#define OCAP_LABELPOS_TOP        1     /* labels directly above widget supported */
#define OCAP_LABELPOS_BOTTOM     2     /* labels directly below widget supported */
#define OCAP_LABELPOS_LEFT       4     /* labels directly to the left of widget supported */
#define OCAP_LABELPOS_RIGHT      8     /* labels directly to the right of widget supported */
#define OCAP_LABELPOS_ELSEWHERE  16    /* labels not adjacent to widget supported */
#define OCAP_LABELPOS_ANYWHERE   31    /* all labels supported */

/* Widget requests */

#define OREQ_OPEN                1     /* open class */
#define OREQ_CLOSE               2     /* close class */
#define OREQ_CREATE              3     /* create instance */
#define OREQ_DESTROY             4     /* destroy instance */
#define OREQ_SETATTR             5     /* set instance attributes */
#define OREQ_GETATTR             6     /* get instance attributes */
#define OREQ_COMMAND             7     /* command to instance */
#define OREQ_GETCAPS             8     /* get capabilities */
#define OREQ_PRINT               9     /* print (part of) the widget */

#define OREQ_LABEL               1000  /* label specific requests start here */
#define OREQ_GFP                 2000  /* form painter specific requests start here */
#define OREQ_PLATFORM            3000  /* platform specific requests start here */
#define OREQ_USER                4000  /* user defined requests start here */

/* Widget commands */

#define OCMD_NEWDATA             1     /* new data was put, update presentation */
#define OCMD_NEWVALREP           2     /* new valrep was set, update presentation */
#define OCMD_PUTDATA             3     /* put modified data back */
#define OCMD_TAKEFOCUS           4     /* widget to grab physical input focus */
#define OCMD_LOSEFOCUS           5     /* widget loses logical input focus */
#define OCMD_SETUPCHANGE         6     /* some setup parameters have changed */
#define OCMD_FUNCTION            7     /* execute Uniface function */
#define OCMD_SMODACK             8     /* start Mod succeeded */
#define OCMD_NEWPROPS            9     /* new properties were set */
#define OCMD_GETFOCUS            10    /* widget receives logical input focus */
#define OCMD_LABELCLICKED        11    /* associated label received click */
#define OCMD_SHOWACCESSKEY       12    /* form scope access key enabled */
#define OCMD_HIDEACCESSKEY       13    /* form scope access key hidden */
#define OCMD_DOACCESSKEY         14    /* access key was pressed */
#define OCMD_ISWIDGETKEY         15    /* Handle keyboard input */          //@pr5

#define OCMD_NEWLABEL            1001  /* label changed */

#define OCMD_LABEL               1000  /* label specific commands start here */
#define OCMD_GFP                 2000  /* form painter specific commands start here */
#define OCMD_PLATFORM            3000  /* platform specific commands start here */
#define OCMD_USER                4000  /* user defined commands start here */

/* Notifications (oNotify) */

#define ONTF_REQUESTFOCUS        1     /* user attempts to set focus to the widget */
#define ONTF_STARTMOD            2     /* the value of the widget is about to change */
#define ONTF_VALUECHANGE         3     /* the value of the widget has changed */
#define ONTF_KEY                 4     /* a keystroke was received by the widget */
#define ONTF_FUNCTION            5     /* queue a function for execution by the client */
#define ONTF_NOTEBOOKVALUECHANGED 6    /* notebook value has changed: page to be updated */

#define ONTF_LREQUESTFOCUS       1001  /* user attempts to set focus to the label */

#define ONTF_LABEL               1000  /* label specific notifications start here */
#define ONTF_GFP                 2000  /* form painter specific notifications start here */
#define ONTF_PLATFORM            3000  /* platform specific notifications start here */
#define ONTF_USER                4000  /* user defined notifications start here */

/* Queries (oQuery) */

#define OMET_XCELL               1     /* width of a character cell in pixels */
#define OMET_YCELL               2     /* height of a character cell in pixels */
#define OMET_BASELINE            8     /* distance from top of charactercell to baseline */
#define OMET_XCHAR               3     /* width of a font character in pixels */
#define OMET_YCHAR               4     /* height of a font character in pixels */
#define OMET_ASCENT              5     /* number of character pixels above baseline */
#define OMET_FOREGND             6     /* foreground color from color/video index */
#define OMET_BACKGND             7     /* background color from color/video index */

#define OLAY_ALIGNMENT           101   /* layout alignment */
#define OLAY_DIRECTION           102   /* direction LTR=0 or RTL=1 @pr4*/
#define OLAY_DIRECTION_RTL       0x0001/* @pr4*/

#define OSYN_SPECIAL             201   /* syntax special (SS) */
#define OSYN_MINLENGTH           202   /* syntax min length (LEN) */
#define OSYN_MAXLENGTH           203   /* syntax max length (LEN) */
#define OSYN_UPPERCASE           204   /* syntax uppercase (UPC) */
#define OSYN_LOWERCASE           205   /* syntax lowercase (LOW) */
#define OSYN_ONELINE             206   /* syntax one line (NCR) */
#define OSYN_MINREP              207   /* syntax minimum subfields (REP) */
#define OSYN_MAXREP              208   /* syntax maximum subfields (REP) */
#define OSYN_IMAGETYPE           209   /* image subtype (0, '@', '#' or '^') */

#define OQRY_BUSY                301   /* is app busy? */
#define OQRY_FOCUS               302   /* does widget have focus? */
#define OQRY_FONTMASK            303   /* mask to clear invalid font bits */
#define OQRY_DBCS_FONT           304   /* first DBCS font */
#define OQRY_DBCS_BASE           305   /* first DBCS character */
#define OQRY_DBCS_CSET           306   /* DBCS characterset id */
#define OQRY_RTL                 307   /* is the default widget style right-to-left? (note :will become obsolete in 7.2) */

#define OQRY_LABEL               1000  /* label specific queries start here */
#define OQRY_GFP                 2000  /* form painter specific queries start here */
#define OQRY_PLATFORM            3000  /* platform specific queries start here */
#define OQRY_USER                4000  /* user defined queries start here */

/* String conversion options (oStrConv) */

#define OCNV_INT2EXT             1     /* convert from internal to external format */
#define OCNV_EXT2INT             2     /* convert from external to internal format */
#define OCNV_XSRECOG             4     /* recognize access key mnemonics (%) in input */
#define OCNV_XSXLATE             8     /* translate access key mnemonics to output */
#define OCNV_PROFILE             16    /* recognize/generate profile characters */
#define OCNV_FULLSET             32    /* do not strip styles and nonrepresentable characters */
#define OCNV_XSESCAPE            64    /* escape access key mnemonics & escapes in output */

/* Compatible old style oStrConv options */

#define OCNV_MNEMOUT             OCNV_XSRECOG
#define OCNV_MNEMIN              OCNV_XSXLATE      /* implies OCNV_RECOG and OCNV_XSESCAPE */

/* Character styles (oChrConv) */

#define OFNT_UNDERLINE           1     /* character is underlined */
#define OFNT_ITALIC              2     /* character is italic */
#define OFNT_BOLD                4     /* character is bold */
#define OFNT_STRIKEOUT           8     /* character is struck out - NOT USED */

#define OFNT_PRINTER             16    /* create a font for the printer not for the screen */

/* Attach options (oAttach) */

#define OATTACH_T                1     /* attach top of widget to top of form */
#define OATTACH_L                2     /* attach left */
#define OATTACH_B                4     /* attach bottom */
#define OATTACH_R                8     /* attach right */

/* Message options (oMessage) */

#define OMSG_NOBEEP              1     /* silent message */
#define OMSG_HINT                2     /* do not log message */
#define OMSG_INFO                4     /* confirmed message with Info icon */
#define OMSG_WARNING             8     /* confirmed message with Warning icon */
#define OMSG_ERROR               16    /* confirmed message with Error icon */

/* Access key scopes (oxsAddKey,oxsRemoveKey) */

#define OXSK_FIELD               1     /* field scope access key */
#define OXSK_FORM                2     /* form scope access key */

/* Object types (oGetLink) */

#define OOBJ_FIELD               0     /* field widget */
#define OOBJ_LABEL               1     /* label widget */

/* Uniface functions */

#define FN(a,b)                  ((a>128) ? (b+127*256) : (b-256))

#define OKEY_RETSEQ              FN(127, 3)
#define OKEY_RETRIEVE            FN(127, 5)
#define OKEY_ERASE               FN(127, 8)
#define OKEY_ACCEPT              FN(127, 9)
#define OKEY_QUIT                FN(127, 10)
#define OKEY_STORE               FN(127, 11)
#define OKEY_CLEAR               FN(127, 12)
#define OKEY_CURSOR_UP           FN(127, 16)
#define OKEY_CURSOR_DOWN         FN(127, 17)
#define OKEY_CURSOR_LEFT         FN(127, 18)
#define OKEY_CURSOR_RIGHT        FN(127, 19)
#define OKEY_TOP_OF_FORM         FN(127, 20)
#define OKEY_BOTTOM_OF_FORM      FN(127, 21)
#define OKEY_HOME                FN(127, 22)
#define OKEY_BOTTOM              FN(127, 23)
#define OKEY_CURSOR_FAST_UP      FN(127, 25)
#define OKEY_CURSOR_FAST_DOWN    FN(127, 26)
#define OKEY_CURSOR_FAST_LEFT    FN(127, 27)
#define OKEY_CURSOR_FAST_RIGHT   FN(127, 28)
#define OKEY_FIRST_OCC           FN(127, 37)
#define OKEY_LAST_OCC            FN(127, 38)
#define OKEY_NEXT_OCC            FN(127, 39)
#define OKEY_PREV_OCC            FN(127, 40)
#define OKEY_INS_OCC             FN(127, 43)
#define OKEY_ADD_OCC             FN(127, 44)
#define OKEY_REM_OCC             FN(127, 45)
#define OKEY_NEXT_FIELD          FN(127, 46)
#define OKEY_PREV_FIELD          FN(127, 47)
#define OKEY_PREV_GROUP          FN(127, 48)
#define OKEY_NEXT_GROUP          FN(127, 49)
#define OKEY_REFRESH             FN(127, 67)
#define OKEY_EDIT_TFO            FN(127, 71)
#define OKEY_KEY_HELP            FN(127, 72)
#define OKEY_VIEW                FN(127, 73)
#define OKEY_FDETAIL             FN(127, 76)
#define OKEY_ATTRIBUTE           FN(127, 78)
#define OKEY_RULER               FN(127, 81)
#define OKEY_PULLDOWN            FN(127, 86)
#define OKEY_PROFILE             FN(127, 87)
#define OKEY_COMPOSE             FN(127, 88)
#define OKEY_FRAME               FN(127, 89)
#define OKEY_HELP                FN(127, 92)
#define OKEY_MESSAGE             FN(127, 93)
#define OKEY_DETAIL              FN(127, 94)
#define OKEY_ZOOM                FN(127, 95)
#define OKEY_QUICK_ZOOM          FN(127, 96)
#define OKEY_SQL                 FN(127, 97)
#define OKEY_PRINT               FN(127, 98)
#define OKEY_PRINT_ATTS          FN(127, 99)
#define OKEY_SWITCH              FN(127, 100)
#define OKEY_MENU                FN(127, 101)
#define OKEY_LAST_TEXT           FN(127, 128)
#define OKEY_FIRST_TEXT          FN(127, 129)
#define OKEY_NEXT_LINE           FN(127, 136)
#define OKEY_PREV_LINE           FN(127, 137)
#define OKEY_NEXT_WORD           FN(127, 140)
#define OKEY_PREV_WORD           FN(127, 141)
#define OKEY_NEXT_CHAR           FN(127, 142)
#define OKEY_PREV_CHAR           FN(127, 143)
#define OKEY_INSOVR              FN(127, 146)
#define OKEY_BOLD                FN(127, 147)
#define OKEY_ITALIC              FN(127, 148)
#define OKEY_UNDERLINE           FN(127, 149)
#define OKEY_FIND_TEXT           FN(127, 150)
#define OKEY_FONT                FN(127, 151)
#define OKEY_FFIND               FN(127, 154)
#define OKEY_BFIND               FN(127, 155)
#define OKEY_SAVE_FILE           FN(127, 158)
#define OKEY_MOVE                FN(127, 160)
#define OKEY_PREV_TEXT           FN(127, 162)
#define OKEY_NEXT_TEXT           FN(127, 163)
#define OKEY_MOV_FILE            FN(127, 165)
#define OKEY_REM_FIELD           FN(127, 166)
#define OKEY_REM_LINE            FN(127, 167)
#define OKEY_REM_WORD            FN(127, 169)
#define OKEY_REM_CHAR            FN(127, 172)
#define OKEY_RUB_CHAR            FN(127, 173)
#define OKEY_REM_SEL_CHAR        FN(127, 174)
#define OKEY_RUB_SEL_CHAR        FN(127, 175)
#define OKEY_INS_TEXT            FN(127, 177)
#define OKEY_SAVE                FN(127, 179)
#define OKEY_INS_FILE            FN(127, 180)
#define OKEY_INS_FIELD           FN(127, 181)
#define OKEY_INS_LINE            FN(127, 182)
#define OKEY_INS_WORD            FN(127, 183)
#define OKEY_INS_CHAR            FN(127, 184)
#define OKEY_BEGIN_LINE          FN(127, 188)
#define OKEY_END_LINE            FN(127, 189)
#define OKEY_QSELECT             FN(127, 190)
#define OKEY_QUNDO_SELECT        FN(127, 191)
#define OKEY_REM_FILE            FN(127, 192)
#define OKEY_SELECT              FN(127, 193)
#define OKEY_REM_SELECT          FN(127, 194)
#define OKEY_INS_SELECT          FN(127, 195)
#define OKEY_UNDO_SELECT         FN(127, 196)
#define OKEY_PAGE_UP             FN(127, 197)
#define OKEY_PAGE_DOWN           FN(127, 198)

/***************************************************************************/
/* DATA TYPES                                                              */
/***************************************************************************/

/* Uniface data types */

/* Attributes and capabilities */

typedef union _owiattv                 /* attribute value variant */
{
   long    i;                          /* as long int */
   short   s[2];                       /* as two shorts */
   char   *psz;                        /* as string */
   UCOLOR  clr;                        /* as color (RGB) */
} OWIATTV, *POWIATTV;

typedef struct _owiattr                /* attribute list entry */
{
   int      id;                        /* attribute ID */
   OWIATTV  d;                         /* attribute value */
} OWIATTR, *POWIATTR;

/* ValRep */

typedef union _value                   /* data value variant */
{
   UBOOL   b;                          /* as boolean */
   UNUMBER n;                          /* as long int */
   UFLOAT  f;                          /* as floating pt */
   UNIDATE d;                          /* as date */
   USTR   *ps;                         /* as string */
   UNATIVE u;                          /* as usm handle */
} VALUE, *POVALUE;

typedef struct _valrep                 /* ValRep entry */
{
   int    iIndex;                      /* entry # */
   int    iType;                       /* variant type of lo, hi */
   VALUE  lo;                          /* low end of range */
   VALUE  hi;                          /* high end of range */
   char  *pszRep;                      /* representation */
} VR, *PVR;

/* Character */

typedef struct _ochr                   /* translated character */
{
   int  iStyle;                        /* character style (OFNT_*) */
   int  iCharSet;                      /* external characterset number */
   USTR sz[16];                        /* up to 15 characters */
} OCHR, *POCHR;

/* Request parameters */

struct owiopen
{
   int     request;                    /* OREQ_OPEN */
   WMLINK  wmlink;                     /* in: dummy link */
   HANCHOR hAnchor;                    /* in: global context handle */
   HCLIENT hClient;                    /* out: client handle */
};

struct owiclose
{
   int     request;                    /* OREQ_CLOSE */
   HCLIENT hClient;                    /* in: client handle */
};

struct owicreate
{
   int      request;                   /* OREQ_CREATE */
   HCLIENT  hClient;                   /* in: client handle */
   WMLINK   wmlink;                    /* in: handle to WM driver widget instance */
   HPARENT  hParent;                   /* in: parent window handle */
   int      nAttr;                     /* in: number of attributes */
   POWIATTR pAttr;                     /* in: attributes */
   HWIDGET  hWidget;                   /* out: widget handle */
};

struct owidestroy
{
   int      request;                   /* OREQ_DESTROY */
   HWIDGET  hWidget;                   /* in: widget handle */
};

struct owisetattr
{
   int      request;                   /* OREQ_SETATTR */
   HWIDGET  hWidget;                   /* in: widget handle */
   int      nAttr;                     /* in: number of attributes */
   POWIATTR pAttr;                     /* in: attributes */
};

struct owigetattr
{
   int      request;                   /* OREQ_GETATTR */
   HWIDGET  hWidget;                   /* in: widget handle */
   int      nAttr;                     /* in: number of attributes */
   POWIATTR pAttr;                     /* in/out: attributes */
};

struct owicommand
{
   int      request;                   /* OREQ_COMMAND */
   HWIDGET  hWidget;                   /* in: widget handle */
   int      id;                        /* in: command ID (OCMD_*) */
   int      iParam;                    /* in: command dependent parameter */
};

struct owigetcaps
{
   int      request;                   /* OREQ_GETCAPS */
   HWIDGET  hWidget;                   /* in: widget handle */
   int      nAttr;                     /* in: number of capabilities */
   POWIATTR pAttr;                     /* in/out: capabilities */
};

struct owiprint
{
   int      request;                   /* OREQ_PRINT */
   HWIDGET  hWidget;                   /* in:  widget handle */
   int      xOrg;                      /* in:  origin to start printing */
   int      yOrg;                      /* in:  origin to start printing*/
   int      iStart;                    /* in:  vertical range of the widget to be printed */
   int      iEnd;                      /* in:  vertical range of the widget to be printed*/
   int      nAttr;                     /* in:  extra attribute information */
   POWIATTR pAttr;                     /* in:  extra attribute information */
   long     lPrinted;                  /* out: printed vertical space */
};

union owirequest                       /* consolidates all request structures */
{
   int      request;
   struct   owiopen      open;
   struct   owiclose     close;
   struct   owicreate    create;
   struct   owidestroy   destroy;
   struct   owisetattr   setattr;
   struct   owigetattr   getattr;
   struct   owicommand   command;
   struct   owigetcaps   getcaps;
   struct   owiprint     print;
};

/* Miscellaneous */

typedef long (*OWIENTRY)(union owirequest *); /* widget entrypoint pointer */

/***************************************************************************/
/* SERVICES                                                                */
/***************************************************************************/

/* Properties */

extern int    ocpBool(WMLINK wmlink, char *pszProp, int iDefault);
extern long   ocpLong(WMLINK wmlink, char *pszProp, long lDefault);
extern double ocpDouble(WMLINK wmlink, char *pszProp, double fDefault);
extern int    ocpString(WMLINK wmlink, char *pszProp, char *pszBuf, int iMax);
extern int    ocpFirst(WMLINK wmlink, char *pszOut, int iMax);
extern int    ocpNext(WMLINK wmlink, char *pszOut, int iMax);

/* Preferences */

extern int    opBool(WMLINK wmlink, char *pszKey, int bDefault);
extern long   opLong(WMLINK wmlink, char *pszKey, long lDefault);
extern double opDouble(WMLINK wmlink, char *pszKey, double fDefault);
extern int    opString(WMLINK wmlink, char *pszKey, char *pszBuf, int iMax);
extern int    opPutBool(WMLINK wmlink, char *pszKey, int bData);
extern int    opPutLong(WMLINK wmlink, char *pszKey, long lData);
extern int    opPutDouble(WMLINK wmlink, char *pszKey, double fData);
extern int    opPutString(WMLINK wmlink, char *pszKey, char *pszData);

/* Data */

extern int    odGet(WMLINK wmlink, void *pValue, int iMax, int iType);
extern int    odGetC(WMLINK wmlink, void *pValue, int iMax, int iType);
extern int    odPut(WMLINK wmlink, void *pValue, int iMax, int iType);
extern int    odPutC(WMLINK wmlink, void *pValue, int iMax, int iType);

/* Label */

extern int    olGet(WMLINK wmlink, USTR *pszLabel, int iMax);
extern int    olGetC(WMLINK wmlink, USTR *pszLabel, int iMax);
extern int    olPut(WMLINK wmlink, USTR *pszLabel);
extern int    olPutC(WMLINK wmlink, USTR *pszLabel);

/* ValRep */

extern int    ovrCount(WMLINK wmlink);
extern int    ovrByIndex(WMLINK wmlink, PVR pvr, int iIndex, int iType);
extern int    ovrByValue(WMLINK wmlink, PVR pvr, void *pValue, int iType);
extern int    ovrByRep(WMLINK wmlink, PVR pvr, char *pszRep, int iType);
extern void   ovrFree(WMLINK wmlink, PVR pvr);
extern int    ovrPut(WMLINK wmlink, PVR pvr);
extern int    ovrPutC(WMLINK wmlink, PVR pvr);

/* Access keys */

extern int    oxsParse(WMLINK wmlink, USTR *pszLabel, POCHR pochr);
extern int    oxsAddKey(WMLINK wmlink, int iKey, int iScope);
extern int    oxsRemoveKey(WMLINK wmlink, int iKey, int iScope);

/* Miscellaneous */

extern int    oNotify(WMLINK wmlink, int iNotification, int iParam);
extern long   oQuery(WMLINK wmlink, int iQuery, int iParam);
extern int    oStrConv(WMLINK wmlink, USTR *in, USTR *out, int iMax, int iOptions);
extern int    oChrConv(WMLINK wmlink, USTR *in, POCHR pout);
extern int    oKeyMode(WMLINK wmlink, int iMode);
extern void   oAttach(WMLINK wmlink, int iAttach);
extern int    oGetMessage(WMLINK wmlink, USTR *key, USTR *out, int iMax);
extern void   oMessage(WMLINK wmlink, USTR *msg, int iOptions);
extern int    oGetObjectName(WMLINK wmlink, USTR *pszOut, int iMax);
extern int    oGetLogicalObjectName(WMLINK wmlink, USTR *pszOut, int iMax);

/* 3GL interface */

extern int    oGetWidget(USTR *field, HWIDGET *wid, WMLINK *wmlink, OWIENTRY *owientry, USTR *logwid, USTR *physwid);
extern WMLINK oGetLink(HPARENT window);
extern int    oGetFormName(void *uniwidget, USTR *pszOut, int iMax);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* !OWI_H */
