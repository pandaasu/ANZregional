/*****************************************************************************
@DOC

@FILE Run-time Repository API |
      This file contains functions to get component information from the
      run-time repository.

@IN_MODULE FF

@INTERNAL
      Function          Description
      ----------------------------------------------------------------------
@FUNC | 

@COPYRIGHT
      Compuware Europe BV <cp> 1997
@OWNER
      KNI
@HISTORY
      Seq  Date     RefNum  Version  Who   Description
      ------------------------------------------------------------------------
@PR   1  | 970224 | ------ | 7.2.x  | wwo | Initial version take from FrankD's prototype
@PR   2  | 970902 | d00455 | 7.2.00 | hoa | add UGEN_SUBSYSTEM
@PR   3  | 971015 | b18656 | 7.2.02 | kgl | Add UPE,UEC,BOC,TOC,POC components
@PR   4  | 971119 | b18656 | 7.2.02 | kgl | Add URC component
@PR   5  | 980102 | e01651 | 7.2.03 | wwo | Middleware properties
@PR   6  | 980605 | e01680 | 7.2.03 | kbk | Add UGFLD_BASETYPE, UGEN_LITNAME

@END
******************************************************************************/
#ifndef URRDEF_H
#define URRDEF_H

/* @(#)CONT_ID %fv: urrdef.h-21 % %dc: Fri Jun  5 10:21:30 1998 % @(#) */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* -- Include files */
#include "uactdef.h"

/* -- Macro constants */

/* Error numbers */
#define URRAPI_SUCCESS           0
#define URRAPI_HANDLE_NOT_VALID -1
#define URRAPI_ALLOCATION_ERROR -2
#define URRAPI_INFO_ID_ERROR    -3
#define URRAPI_CANNOT_FIND      -4

/* Information ID numbers */

/* Component type */
#define UANY 0                   /* Any     */
#define US3C 1                   /* 3GL     */
#define URPT 2                   /* Report  */
#define USVC 3                   /* Service */
#define UFRM 4                   /* Form    */
#define USOS 5                   /* OS      */
#define UUPE 6                   /* Uniface Painted entity @pr3 */
#define UUEC 7                   /* Uniface Entity Collection @pr3 */
#define UBOC 8                   /* Business Object @pr3 */
#define UTOC 9                   /* Task Object @pr3 */
#define UPOC 10                  /* Presentation Object @pr3 */
#define UURC 11                  /* Uniface Reference Collection @pr4 */

/* Return value */
#define URET_VOID   11           /* the function returns void */
#define URET_STATUS 12           /* the return value is in $status */
#define URET_PRM    13           /* the return value is in Parameter 1 */

/* Component information (generic) */
#define UGEN_NAME            101 /* Component name, <= 32 bytes + '\0'              */
#define UGEN_LIBRARY         102 /* Library name, <= 16 bytes + '\0'                */
#define UGEN_ID              103 /* Unique ID, <= 64 bytes + '\0'                   */
#define UGEN_SUBSYSTEM       104 /* Subsystem name, <= 16 bytes + '\0'              */ /* @pr2 */
#define UGEN_DEFIMPNAME      105 /* Default implementation name, <= 32 bytes + '\0' */
#define UGEN_DEFPATH         106 /* Default path, <= 3 bytes + '\0'                 */
#define UGEN_SCOPE           107 /* Component scope, <= 3 bytes + '\0'              */
#define UGEN_EXECDEF         108 /* Sync/Async, 1 byte + '\0'                       */
#define UGEN_NOSTATE         109 /* State/Stateless, 1 byte + '\0'                  */ /* @pr5 */
#define UGEN_TRANSATTR       110 /* Transactional/Nontransactional, 1 byte + '\0'   */ /* @pr5 */
#define UGEN_LITNAME         111 /* @pr6 Component name, <= 255 bytes + '\0'        */
#define UGEN_TUXPROP         112 /* @pr6 Tuxedo properties, <= 255 bytes + '\0'        */
#define UGEN_ENCPROP         113 /* @pr6 Encina properties, <= 255 bytes + '\0'        */

/* Component information (implementation) */
#define UIMPL_NAME           151 /* Implementation name, <= 32 bytes + '\0'         */
#define UIMPL_ID             152 /* Implementation ID, <= 64 bytes + '\0'           */
#define UIMPL_CONTEXT        153 /* Implementation context, <= 1 byte + '\0'(bool)  */
#define UIMPL_OUTPUT         154 /* Implementation output, <= 64 bytes + '\0'       */
#define UIMPL_INCLUDE        155 /* Implementation include, <= 64 bytes + '\0'      */

/* Operation information (generic) */
#define UGOPR_NAME           201 /* Operation name, <= 32 bytes + '\0'              */
#define UGOPR_EXECTYPE       202 /* Sync/Oneway, 1 byte + '\0'                      */
#define UGOPR_PRMS           203 /* Number of parameters, 4 bytes + '\0'            */
#define UGOPR_NOSTATE        204 /* State/Stateless, 1 byte + '\0'                  */ /* @pr5 */

/* Operation information (implementation) */
#define UIOPR_NAME           251 /* Operation name, <= 32 bytes + '\0'              */
#define UIOPR_LITNAME        252 /* Opeation literal name, <= 64 bytes + '\0'       */
#define UIOPR_RETVAL         253 /* Return value, <= 2 bytes + '\0'                 */
#define UIOPR_CONTEXT        254 /* Context, <= 4 bytes + '\0'                      */
#define UIOPR_RETTYPE        255 /* Return type, <= 6 bytes + '\0'                  */

/* Parameter information (generic) */
#define UGPRM_NAME           301 /* Parameter name, <= 32 bytes + '\0'              */ 
#define UGPRM_SEQNUMBER      302 /* ASCII number, <= 4 bytes + '\0'                 */
#define UGPRM_DIRECTION      303 /* In/Out/Both, 1 byte + '\0'                      */
#define UGPRM_TYPE           304 /* Basic/Constructed, 1 byte + '\0'                */
#define UGPRM_DATATYPE       305 /* 1-letter datatype, 1 byte + '\0'                */

#define UGENT_NAME           401 /* Entity name, <= 32 bytes + '\0'                 */
#define UGENT_MODEL          402 /* Model name, <= 32 bytes + '\0'                  */
#define UGENT_FIELDS         403 /* Number of fields, <= 4 bytes + '\0'             */

#define UGFLD_NAME           501 /* Field name, <= 32 bytes + '\0'                  */
#define UGFLD_SEQNUMBER      502 /* ASCII number, <= 4 bytes + '\0'                 */
#define UGFLD_DATATYPE       503 /* 1-letter datatype, 1 byte + '\0'                */
#define UGFLD_SIZE           504 /* ASCII number, <= 12 bytes + '\0'                */
#define UGFLD_BASETYPE       505 /* @pr6 packing code translated to c type as string, e.g. "char *" */

/* Parameter information (implementation) */
#define UIPRM_NAME           351 /* Parameter name, <= 32 bytes + '\0'              */
#define UIPRM_LITNAME        352 /* Parameter literal name, <= 255 bytes + '\0'      */
#define UIPRM_ARRAYSIZE      353 /* Parameter array size, <= 4 bytes + '\0'         */
#define UIPRM_GLAB           354 /* Subtype, <= 32 bytes + '\0'                     */
#define UIPRM_BASETYPE       355 /* Parameter base type                             */
#define UIPRM_FORMAT         356 /* Parameter format                                */
#define UIPRM_LENGTH         357 /* Parameter length                                */
#define UIPRM_ACCESSMETHOD   358 /* Occurence access method                         */

/* Functions */
extern long UHCLGET  (UHACT, UCHAR *, UCHAR *, UHACT *);
extern long UHCPTGET (UHACT, int, UHACT *);
extern long UHOPRGET (UHACT, int, UHACT *);
extern long UHPRMGET (UHACT, int, UHACT *);
extern long UHENTGET (UHACT, UHACT *);
extern long UHFLDGET (UHACT, int, UHACT *);
extern long URRSINFO (UHACT, int, int, UCHAR *);
extern long URRLINFO (UHACT, int, int, long *);
extern long URRHFREE (UHACT *);

#ifdef u_lowercase

extern long uhclget  (UHACT, UCHAR *, UCHAR *, UHACT *);
extern long uhcptget (UHACT, int, UHACT *);
extern long uhoprget (UHACT, int, UHACT *);
extern long uhprmget (UHACT, int, UHACT *);
extern long uhentget (UHACT, UHACT *);
extern long uhfldget (UHACT, int, UHACT *);
extern long urrsinfo (UHACT, int, int, UCHAR *);
extern long urrlinfo (UHACT, int, int, long *);
extern long urrhfree (UHACT *);

#endif /* u_lowercase */

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* URRDEF_H */

/* End of file urrdef.h */

