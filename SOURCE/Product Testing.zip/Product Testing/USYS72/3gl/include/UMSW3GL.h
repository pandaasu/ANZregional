/*
 * Name        : umsw3gl.h
 *
 * Description : Include file for Uniface 3GL interface - MS Windows environment.
 *
 */

#ifndef UMSW3GL_H
#define UMSW3GL_H


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <malloc.h>

#ifdef _WIN32                                                        
#define far
#define XCALLBACK   __stdcall
#undef  XEXPORT
#define XEXPORT(A)  __declspec(dllexport) A
#define X3GL        __cdecl
typedef __declspec(dllexport) long (* XPROC)();
#else                                                                
#define XCALLBACK   far pascal
#undef  XEXPORT
#define XEXPORT(A)  A _far _export
#define X3GL        far _cdecl
typedef long (__export * XPROC)();
#endif                                                               
   /*
   ** These values are passed to UDLLEVENT.
   */

#define UEVT_INITDLL     1             /* DLL is being loaded     */
#define UEVT_EXITDLL     2             /* DLL is being unloaded   */
#define UEVT_INITCLIENT  3             /* A new client arrives    */
#define UEVT_EXITCLIENT  4             /* A client says goodbye   */
#define UEVT_INITGUI     5             /* Interactive mode starts */
#define UEVT_EXITGUI     6             /* Interactive mode ends   */

   /*
   ** These values are passed to UADVISE and UUNADVISE.
   */

#define UADV_PREKEY      1             /* Advise before key processed     */
#define UADV_POSTKEY     2             /* Advise after key processed      */
#define UADV_MODIFY      3             /* Advise after field modification */

#define UADV_ALL       -1L             /* All events in a class           */

   /*
   ** These values are returned from UDLLEVENT and other functions.
   */

#ifndef SUCCESS                                                 
#define SUCCESS  0
#endif                                                          

#ifndef FAILURE                                                 
#define FAILURE -1
#endif                                                          

/*
** You must declare all your 4GL callable functions with XEXPORT(A).
** Where A is the returned type
** Functions passed to UPROCINST must be declared XCALLBACK.
** Communication with UMSWLIB uses the X3GL calling sequence.
*/


/*
** Typedefs
*/

typedef unsigned char       USTRING;   /* Null terminated string */
typedef unsigned char       UARRAY;    /* Not null terminated */
typedef void *              VOIDPTR;
typedef struct unibas *     UNIBAS;
typedef struct usmbas *     USMBAS;
typedef unsigned char *     USMPTR;
typedef long                UPATH;
typedef long                UFILE;
typedef struct uassign *    UASSIGN;
typedef struct usysbas *    USYSBAS;
typedef struct hitlist *    UHITLIST;
typedef struct uctrl *      UCTRL;

#ifndef COMPONENTTYPE_DEF
#define COMPONENTTYPE_DEF
typedef enum {
    CT_FORM = 0,
    CT_SERVICE,
    CT_REPORT
} ComponentType;
#endif


typedef long (XCALLBACK *   UPROC)();

/*
** External Globals
*/
#ifndef NOGLOBALS
extern UNIBAS unibas;
extern USYSBAS usysbas;
#endif

/*
** The load/unload event notification function can be implemented
** by the custom 3GL code to allocate/deallocate resources, etc.
*/

short X3GL UDLLEVENT(short sReason);

#ifndef NO_SVC_PROTOTYPES

   /*
   ** Service function prototypes.
   */

   short  X3GL ufget(USTRING *pField, USTRING *pData, short sMax);
   short  X3GL ufgetc(USTRING *pField, USTRING *pData, short sMax);
   short  X3GL uflab(USTRING *pFieldList);
   short  X3GL uflabdbm(USTRING *pEntity, USTRING *pFieldList);
   short  X3GL ufput(USTRING *pField, USTRING *pData, short sLen);
   short  X3GL ufputc(USTRING *pField, USTRING *pData, short sLen);
   short  X3GL ufputi(USTRING *pField, USTRING *pData, short sLen);     
   short  X3GL ugetames(USTRING *pMsg);
   int    X3GL ugetbind(USTRING *pField, USTRING *pBind);
   long   X3GL ugetreg(short sReg);
   double X3GL ugetregf(short sReg);                            
   long   X3GL ugetregs(short sReg, USTRING *pData, short sMax);
   short  X3GL ugget(USTRING *pEntity, USTRING *pData, short sMax);
   short  X3GL uggetc(USTRING *pEntity, USTRING *pData, short sMax);
   short  X3GL uglab(USTRING *pEntityList);
   short  X3GL uglabdbm(USTRING *pEntityList);
   short  X3GL ugput(USTRING *pEntity, USTRING *pData, short sLen);
   short  X3GL ugputc(USTRING *pEntity, USTRING *pData, short sLen);
   long   X3GL upaddocc(USTRING *pEntity, long lNr);
   long   X3GL updelocc(USTRING *pEntity, long lNr);
   long   X3GL upsetocc(USTRING *pEntity, long lNr);
   long   X3GL updisocc(USTRING *pEntity, long from, long to);          
   short  X3GL uputames(USTRING *pMsg, short sLen);
   void   X3GL uputmess(USTRING *pMsg);
   long   X3GL uputreg(short sReg, long lData);
   long   X3GL uputregf(short sReg, double fData);              
   long   X3GL uputregs(short sReg, USTRING *pData);
   short  X3GL urclr(short sSource);
   long   X3GL urun(USTRING *pForm, short sRow, short sCol, short sRows, short sCols);
   long   X3GL uruninst(USTRING *loadname, USTRING *formname,
                        short vpos, short hpos, short vmax, short hmax);
   long   X3GL usysparm(short sFunction, USTRING *pData, short sDummy);
   long   X3GL usetparm(short sFunction, USTRING *pSource, USTRING *pDestination);
   short  X3GL uxget(USTRING *pData, short sMax);
   short  X3GL uxgetc(USTRING *pData, short sMax);
   short  X3GL uxput(USTRING *pData, short sLen);
   short  X3GL uxputc(USTRING *pData, short sLen);
   short  X3GL ucfget(USTRING *pField, USTRING *pData, short sMax, UARRAY *pType);
   short  X3GL ucfgetc(USTRING *pField, USTRING *pData, short sMax);
   long   X3GL ugettxt(USTRING *key, USTRING *buf, long max);      
   long   X3GL ugettxtc(USTRING *buf, long max);                
   long   X3GL uload(ComponentType Aotype, USTRING *loadname, USTRING *formname,
             short vpos, short hpos, short vmax, short hmax);
   long   X3GL uexec(USTRING *formname);
   void   X3GL uunload(USTRING *formname);
   long   X3GL usndmsg(USTRING *msg_to, USTRING *msg_id,
               USTRING *msg_data, long data_len, short synchronous);
   short  X3GL UFGET(USTRING *pField, USTRING *pData, short sMax);
   short  X3GL UFGETC(USTRING *pField, USTRING *pData, short sMax);
   short  X3GL UFLAB(USTRING *pFieldList);
   short  X3GL UFLABDBM(USTRING *pEntity, USTRING *pFieldList);
   short  X3GL UFPUT(USTRING *pField, USTRING *pData, short sLen);
   short  X3GL UFPUTC(USTRING *pField, USTRING *pData, short sLen);
   short  X3GL UFPUTI(USTRING *pField, USTRING *pData, short sLen);  
   short  X3GL UGETAMES(USTRING *pMsg);
   int    X3GL UGETBIND(USTRING *pField, USTRING *pBind);
   long   X3GL UGETREG(short sReg);
   double X3GL UGETREGF(short sReg);                            
   long   X3GL UGETREGS(short sReg, USTRING *pData, short sMax);
   short  X3GL UGGET(USTRING *pEntity, USTRING *pData, short sMax);
   short  X3GL UGGETC(USTRING *pEntity, USTRING *pData, short sMax);
   short  X3GL UGLAB(USTRING *pEntityList);
   short  X3GL UGLABDBM(USTRING *pEntityList);
   short  X3GL UGPUT(USTRING *pEntity, USTRING *pData, short sLen);
   short  X3GL UGPUTC(USTRING *pEntity, USTRING *pData, short sLen);
   long   X3GL UPADDOCC(USTRING *pEntity, long lNr);
   long   X3GL UPDELOCC(USTRING *pEntity, long lNr);
   long   X3GL UPSETOCC(USTRING *pEntity, long lNr);
   long   X3GL UPDISOCC(USTRING *pEntity, long from, long to);       
   short  X3GL UPUTAMES(USTRING *pMsg, short sLen);
   void   X3GL UPUTMESS(USTRING *pMsg);
   long   X3GL UPUTREG(short sReg, long lData);
   long   X3GL UPUTREGF(short sReg, double fData);              
   long   X3GL UPUTREGS(short sReg, USTRING *pData);
   short  X3GL URCLR(short sSource);
   long   X3GL URUN(USTRING *pForm, short sRow, short sCol, short sRows, short sCols);
   long   X3GL URUNINST(USTRING *loadname, USTRING *formname,
            short vpos, short hpos, short vmax, short hmax);   
   long   X3GL USYSPARM(short sFunction, USTRING *pData, short sDummy);
   long   X3GL USETPARM(short sFunction, USTRING *pSource, USTRING *pDestination);    
   short  X3GL UXGET(USTRING *pData, short sMax);
   short  X3GL UXGETC(USTRING *pData, short sMax);
   short  X3GL UXPUT(USTRING *pData, short sLen);
   short  X3GL UXPUTC(USTRING *pData, short sLen);
   short  X3GL UCFGET(USTRING *pField, USTRING *pData, short sMax, UARRAY *pType); 
   short  X3GL UCFGETC(USTRING *pField, USTRING *pData, short sMax); 
   long   X3GL UGETTXT(USTRING *key, USTRING *buf, long max);     
   long   X3GL UGETTXTC(USTRING *buf, long max);              
   long   X3GL ULOAD(ComponentType Aotype, USTRING *loadname, USTRING *formname,
                     short vpos, short hpos, short vmax, short hmax); 
   long   X3GL UEXEC(USTRING *formname);
   void   X3GL UUNLOAD(USTRING *formname); 
   long   X3GL USNDMSG(USTRING *msg_to, USTRING *msg_id,
               USTRING *msg_data, long data_len, short synchronous);   
   /*
   ** Not supported:
   */

/* int    X3GL unifbeg(int iBatch);     */
/* int    X3GL unifend(int iLevel);     */
/* int    X3GL unifmes(USTRING *pMsg);  */

/* int    X3GL UNIFBEG(int iBatch);     */
/* int    X3GL UNIFEND(int iLevel);     */
/* int    X3GL UNIFMES(USTRING *pMsg);  */

   /*
   ** Driver support functions.
   */

   short   X3GL udcurscnt(UCTRL, short, short);
   short   X3GL udfilcnt(UCTRL, short, short);
   short   X3GL udpathset(UCTRL, short, short);
   int     X3GL usort(UNIBAS, UHITLIST);
   UCTRL   X3GL uloadcb(UCTRL);
   short   X3GL ugethit(struct uctrl *, UARRAY *, UARRAY *);
   void    X3GL uaddsql(UCTRL, USTRING *);
   void    X3GL uaddhit(UCTRL, UARRAY *, short, UARRAY *, short, UARRAY *, short);
   void    X3GL uaddrec(UCTRL, UARRAY *, short, UARRAY *, short, UARRAY *, short);
   short   X3GL uready(UCTRL);
   short   X3GL uhitchk(UCTRL, short, UARRAY *);
   void    X3GL unullify(UCTRL, int);
   void    X3GL ubldprm(UCTRL, short);
   short   X3GL uprimpos(UCTRL, short);
   long    X3GL uvirtkey(USMBAS, USMPTR *, UARRAY *, short);
   void    X3GL uvirtput(USMBAS, USMPTR *, UARRAY *, short, long);
   USMPTR  X3GL uvirtini(USMBAS, USMPTR, long);
   short   X3GL udbconv(UCTRL, USTRING *, USTRING *, short, struct ufldlst *, short);
   short   X3GL uconvdb(UCTRL, UARRAY *, UARRAY *, short, struct ufldlst *, short);
   int     X3GL ucnv2dbl(VOIDPTR, int, int, int, int, double *);
   UPATH   X3GL ugetasn(UASSIGN, int, USTRING *, USTRING *, USTRING *, int);	
   void    X3GL usumfld(UCTRL, UARRAY *, short, short);
   void    X3GL usumhit(UCTRL);
   int     X3GL ulstrcpy(USTRING *, USTRING *);
   int     X3GL ustrim(USTRING *, int);
   int     X3GL usyserr(USYSBAS usysbas, int iErr);
   int     X3GL usysmsg(USYSBAS usysbas, int iErr, USTRING *pBuf);
   void    X3GL uputblob(UCTRL, int, UARRAY *, long, int);
   long    X3GL ugetblob(UCTRL, int, UARRAY *, long, int);
   void    X3GL ulogprint(USYSBAS, USTRING *);
   int     X3GL ufilwild(USYSBAS, USTRING *, int, USTRING *);
   UFILE   X3GL ufilopen(USYSBAS, USTRING *, int);
   void    X3GL ufilclose(USYSBAS, UFILE);
   int     X3GL ufilread(USYSBAS, UFILE, UARRAY *, int);
   int     X3GL ufilwrite(USYSBAS, UFILE, UARRAY *, int);
   long    X3GL ufilseek(USYSBAS, UFILE, long, int);
   int     X3GL ufildel(USYSBAS, USTRING *);
   int     X3GL ufilparse(USYSBAS , USTRING *, int *, int *, int *);
   int     X3GL ugetenv(USYSBAS, USTRING *, USTRING *);
   UARRAY* X3GL usysalloc(USYSBAS, unsigned, int, int);
   UARRAY* X3GL usysfree(USYSBAS, UARRAY *);
   UARRAY* X3GL usysrealloc(USYSBAS, UARRAY *, unsigned, int, int);  
   UARRAY* X3GL ustrdup(USYSBAS, UARRAY *);                          
   USTRING*X3GL ugetuopenflag(void);                                 
   USTRING*X3GL ugetulda(void);                                     

   short   X3GL UDCURSCNT(UCTRL, short, short);
   short   X3GL UDFILCNT(UCTRL, short, short);
   short   X3GL UDPATHSET(UCTRL, short, short);
   int     X3GL USORT(UNIBAS, UHITLIST);
   UCTRL   X3GL ULOADCB(UCTRL);
   short   X3GL UGETHIT(struct uctrl *, UARRAY *, UARRAY *);
   void    X3GL UADDSQL(UCTRL, USTRING *);
   void    X3GL UADDHIT(UCTRL, UARRAY *, short, UARRAY *, short, UARRAY *, short);
   void    X3GL UADDREC(UCTRL, UARRAY *, short, UARRAY *, short, UARRAY *, short);
   short   X3GL UREADY(UCTRL);
   short   X3GL UHITCHK(UCTRL, short, UARRAY *);
   void    X3GL UNULLIFY(UCTRL, int);
   void    X3GL UBLDPRM(UCTRL, short);
   short   X3GL UPRIMPOS(UCTRL, short);
   long    X3GL UVIRTKEY(USMBAS, USMPTR *, UARRAY *, short);
   void    X3GL UVIRTPUT(USMBAS, USMPTR *, UARRAY *, short, long);
   USMPTR  X3GL UVIRTINI(USMBAS, USMPTR, long);
   short   X3GL UDBCONV(UCTRL, VOIDPTR, VOIDPTR, short, struct ufldlst *, short);
   short   X3GL UCONVDB(UCTRL, UARRAY *, UARRAY *, short, struct ufldlst *, short);
   int     X3GL UCNV2DBL(VOIDPTR, int, int, int, int, double *);
   UPATH   X3GL UGETASN(UASSIGN, USTRING *, USTRING *, USTRING *, int, int);
   void    X3GL USUMFLD(UCTRL, UARRAY *, short, short);
   void    X3GL USUMHIT(UCTRL);
   int     X3GL ULSTRCPY(USTRING *, USTRING *);
   int     X3GL USTRIM(USTRING *, int);
   int     X3GL USYSERR(USYSBAS usysbas, int iErr);
   int     X3GL USYSMSG(USYSBAS usysbas, int iErr, USTRING *pBuf);
   void    X3GL UPUTBLOB(UCTRL, int, UARRAY *, long, int);
   long    X3GL UGETBLOB(UCTRL, int, UARRAY *, long, int);
   void    X3GL ULOGPRINT(USYSBAS, USTRING *);
   int     X3GL UFILWILD(USYSBAS, USTRING *, int, USTRING *);
   UFILE   X3GL UFILOPEN(USYSBAS, USTRING *, int);
   void    X3GL UFILCLOSE(USYSBAS, UFILE);
   int     X3GL UFILREAD(USYSBAS, UFILE, UARRAY *, int);
   int     X3GL UFILWRITE(USYSBAS, UFILE, UARRAY *, int);
   long    X3GL UFILSEEK(USYSBAS, UFILE, long, int);
   int     X3GL UFILDEL(USYSBAS, USTRING *);
   int     X3GL UFILPARSE(USYSBAS , USTRING *, int *, int *, int *);
   int     X3GL UGETENV(USYSBAS, USTRING *, USTRING *);
   UARRAY* X3GL USYSALLOC(USYSBAS, unsigned, int, int);
   UARRAY* X3GL USYSFREE(USYSBAS, UARRAY *);
   UARRAY* X3GL USYSREALLOC(USYSBAS, UARRAY *, unsigned, int, int);  
   UARRAY* X3GL USTRDUP(USYSBAS, UARRAY *);                         
   USTRING*X3GL UGETUOPENFLAG(void);                                 
   USTRING*X3GL UGETULDA(void);                                      

   /*
   ** Windows specific service functions.
   */

   short   X3GL uclient(void);
   XPROC   X3GL uget3gl(USTRING *);
   short   X3GL uadvise(short, long, UPROC);                         
   short   X3GL uunadvise(short, long, UPROC);                      
   long    X3GL ucurfld(void);
   short   X3GL ufldname(long, USTRING *);
   long    X3GL ufldlink(USTRING *, long *);
   UPROC   X3GL umakeprocinst(UPROC);                                
   void    X3GL ufreeprocinst(UPROC);                                
   USTRING*X3GL ugetprofile(void);
   int     X3GL uprintf(const char far *, ...);
#define uloadds ULOADDS                                              
   USTRING*X3GL ustringcnv(USTRING *, USTRING *, int);               
   void    X3GL uwantchars(short bWantChar);                         

   short   X3GL UCLIENT(void);
   XPROC   X3GL UGET3GL(USTRING *);
   short   X3GL UADVISE(short, long, UPROC);                         
   short   X3GL UUNADVISE(short, long, UPROC);                       
   long    X3GL UCURFLD(void);
   short   X3GL UFLDNAME(long, USTRING *);
   long    X3GL UFLDLINK(USTRING *, long *);
   UPROC   X3GL UMAKEPROCINST(UPROC);                                
   void    X3GL UFREEPROCINST(UPROC);                                
   USTRING*X3GL UGETPROFILE(void);
   int     X3GL UPRINTF(const char far *, ...);
   XEXPORT(void X3GL) ULOADDS(void);                                 
   USTRING*X3GL USTRINGCNV(USTRING *, USTRING *, int);              
   void    X3GL UWANTCHARS (short bWantChar);                       


   /* 
   ** Registry aware replacement functions for Get/WritePrivateProfileString
   */

   int uReadStringSysSetting(char *, char *, char *, char *, int, char *);
   int uWriteStringSysSetting(char *, char *, char *, char *);

   /* 
   ** Memory management changed name to avoid clash with C Runtime
   ** In version 6.1.e, malloc maps to umalloc, giving the benefits of UNIFACE memory
   ** management to our 3rd party widget writers.
   ** In version 7, malloc isn't mapped anymore, thus falls back to the c-runtime malloc.
   ** The define USE_NATIVE_MEMORY allows you to use C-runtime memory functions, so by default
   ** UNIFACE memory management is used.
   */

   void * X3GL umalloc(size_t);
   void   X3GL ufree(void *);
   void * X3GL ucalloc(size_t num, size_t size);
   void * X3GL urealloc(void * pOld, size_t size);
   char * X3GL ustringdup(char * pszText);           /* ustrdup is already used in the kernel */

#ifndef USE_NATIVE_MEMORY
#define malloc(n)       umalloc(n)
#define free(p)         ufree(p)
#define calloc(n,s)     ucalloc(n, s)
#define realloc(p, s)   urealloc(p, s)
#define _strdup(p)      ustringdup(p)
#endif /* USE_NATIVE_MEMORY */                                      

#ifndef printf
#ifndef _MAC
#define printf uprintf
#endif /* _MAC */
#endif

#ifdef _WINDOWS_
#define _INC_WINDOWS  /* Windows NT defines _WINDOWS_ rather than _INC_WINDOWS */
#endif /* _WINDOWS_ */
#ifdef _INC_WINDOWS

      /*
      ** Only include these prototypes when windows.h is included.
      ** Note that the _INC_WINDOWS symbol is automatically defined
      ** in windows.h as of version 3.1 of the SDK.
      */

      HWND      X3GL ugethwnd(void);
      HINSTANCE X3GL ugethinst(void);
      HINSTANCE X3GL ulibinst(void);
      short     X3GL udetailpos(LPPOINT);

      HWND      X3GL UGETHWND(void);
      HINSTANCE X3GL UGETHINST(void);
      HINSTANCE X3GL ULIBINST(void);
      short     X3GL UDETAILPOS(LPPOINT);

      // -- WinRunner support functions
    USTRING*  X3GL UGETFORNAME(HWND hWnd, USTRING* pszInput, int iMax);     
      USTRING*  X3GL uGetFormName(HWND hWnd, USTRING* pszInput, int iMax);   
    USTRING*  X3GL UGETNAME(HWND hWnd, USTRING* pszInput, int iMax);    
      USTRING*  X3GL uGetName(HWND hWnd, USTRING* pszInput, int iMax);   

#endif /* _INC_WINDOWS */

typedef struct __UPIWIDPARAMS
{
   void          *pwid;   /* Pointer to a widget. */
   unsigned      message; /* OWI-message. */
   long          lp;      /* First param of ulMsg. */
   void          *pp;     /* Second param of ulMsg. */
} UPIWIDPARAMS ;

     /* A pointer to a function with parameter list */
     /* 3GL function to set a spy */
void * X3GL USETUPISPY(unsigned wclass, void * pfnwidproc, unsigned *size);

#ifdef u_msw16
long X3GL UPISPYTHUNK(void * pfunc, void * pwid, unsigned msg, long lp, void * pp);

#define CALLUPIWIDPROC(a,b,c,d,e) UPISPYTHUNK(a,b,c,d,e)
#else
#define CALLUPIWIDPROC(a,b,c,d,e) (a)(b,c,d,e)
#endif

#ifdef _MAC
#ifdef DEBUG
#include "mprof.h"
#endif //DEBUG
#endif 

#endif /* NO_SVC_PROTOTYPES */

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* !UMSW3GL_H */

