/* CONT_ID %fv: uiodef.h-13 % %dc: Fri Jun 19 12:37:50 1998 % */

/******************************************************************************
@DOC

@COPYRIGHT
    Compuware Europe BV Copyright (c) 1987-1998
@INTERFACE
    
@FILE
    %name: uiodef.h % - structure definitions for DBMS drivers
@HISTORY
     Seq. Date    RefNum  Version Who Description 
     ---------------------------------------------------------------- 
@pr     1 970107  b15596  7.1.c1  mbs Multiple attempts to open files for compilation
@pr     2 970317  14799   7.2     sse APE: Not in DB entities
@pr     3 970418  14799   7.2     sse Fix on pr2
@pr     4 970502  14799   7.2     sse Partial undo of pr2
@pr     5 970606  17611   7.1.05  cbr Conditionally type wrkarea ptr (prevent lint warnings)
@pr     6 971024  18326   7.2.01  ebn Add flatfile field in uctrl
@pr     7 971113  18656   7.2.02  fdn Add activate engine entry point (replace field utdm, which was unused)
@pr     8 970126  e01637  7.2.03  sse URB: Add TMEnabled/TMCapable flags
@pr     9 970126  e02431  7.2.03  sse URB: two_phase != 0 means 2-phase commit driver
@pr    10 980619  e20237  7.2.03  mwn pM3 + pE14

980619 b20237 7.2.03 mwn 

@CHANGE_DESCR
@pr

@END
******************************************************************************/

#ifndef UIODEF_H
#define UIODEF_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define uiomax  8192                                            /*  driver transfer data-buffer size */
#define maxdrv  30

/*
	@pr5  cbr  june 6, 1997  See bug  17611

	A driver can now typedef the layout of its driver workarea before including
	uiodef.h, so we can properly declare uctrl->udrv and we don't need to cast it
	later on (this cast causes warnings from some strict lint implementations.
	When a driver does not do this, it will simply work as before.

	Example as coded in zalbint.ec:

	typedef struct
	{
		...
	} WAREA;
	#define DRIVER_WAREA_DEFINED
	#include "uiodef.h"
	...
	WAREA	warea = uctrl->udrv;
*/

#ifndef DRIVER_WAREA_DEFINED		/*@pr5*/
typedef unsigned char WAREA;		/*@pr5*/
#endif					/*@pr5*/

struct uctrl                                                    /* UNIFACE input / output control block */
{
    struct uctrl *uchfw;                                        /* (virtual) address next control block */
    struct uctrl *uchbw;                                        /* (virtual) address previous control block */
    long (*dis)(struct uctrl *);                                /* UNIFACE driver dispatch address */
    struct uctrl *mctrl;                                        /* overflow control block */
    WAREA *udrv;                        /*@pr5*/                /* UNIFACE driver 'control data' */
    unsigned char *uname;                                       /* file/table name string */
    unsigned char *umisc;                                       /* miscellanious data */
    unsigned char *ulit;                                        /* literal pool (idents) */
    unsigned char *utrnin;                                      /* dbms idents conversion */
    unsigned char *uident;                                      /* ??? */
    unsigned char *ufstring;                                    /* fieldnames string */
    struct uctrl *ulink;                                        /* outer entity */
    struct ufldlst *uflist;                                     /* fieldlist (struct ufldlst) */
    struct uidxlst *uilist;                                     /* indexlist (struct uidxlst) */
    struct uwhrlst *uwlist;                                     /* wherelist (struct uwhrlst) */
    struct uordlst *uolist;                                     /* orderlist (struct uordlst) */
    unsigned char *dbdastart;                                   /* start of db data record */
    struct uctrl *uctrlid;                                      /* (virtual) address for this control block */
    struct uctrl *mctrlid;                                      /* (virtual) address for the overflow */
    short   localId;
    short   serverId;
    unsigned char *iobuf;                                       /* I/O data buffer */
    unsigned char *sqlbuf;                                      /* (sql) work buffer */
    struct unibas *unibas;                                      /* base pointer to Uniface workarea */
    struct usysbas *usysbas;                                    /* base pointer to Uniface system workarea */
    struct uiobas *uiobas;                                      /* base pointer to Uniface io workarea */
    unsigned char *whrbuf;                                      /* (where) work buffer */
    struct hitlist *hitlist;
    struct hitlist *hitchain;
    short       dbdasegsiz;                                     /* segmentsize of dbdata */
    unsigned char Conformance;                                  /* SQL conformance Level  */
    unsigned char usubmode;                                     /* sub open mode, for RI support (FIRST_CALL,  LAST_CALL) */
    void *actdis;                                               /* Activate engine entry point @pr7 */
    struct udrvtab *udrvtab;                                    /* pointer to driver control data */
    long reservel[5];
    short reserves[1];
    short TransActionNumber;                                    /*  Internal only  */
    unsigned char blobToDo;                                     /*  True when Blobs must be fetched */
    unsigned char blobfmt;
    short         blobsattrib;
    unsigned char *sqldata;                                     /* sql transport pointer */
    unsigned char *ublob;                                       /* save information for blobs */
    unsigned char *ublobcont;                                   /* start information for blobs */
    struct hit *uhitpad;                                        /* pointer to hit */
    long udrverr;                                               /* driver error return code */
    long ubloblen;                                              /* save information for blobs */
    struct uctrl *uctrlList;                                    /* Internal tempory set of uctrls belongs to operation */
    long upathDest;                                             /* link to Destination path administration  */
    long upath;                                                 /* link to Source path administration */
    unsigned char *descsav;                                     /* desc til' opened by net */
    unsigned char *urlink;                                      /* RIB table */
    struct uiflst *uiflist;                                     /* iflist (struct uiflst) */
    short ucache;                                               /* maximum caching size (0 = disable caching) */
    short sattrib;                                              /* sql conversion */
    unsigned char hitmode;                                      /* status for addhit */
    unsigned char utrunc1;                                      /* if true truncation of trailing spaces */
                                                                /* should leave one space */
    unsigned char two_phase;                                    /* @pr9: != 0 means support 2-phase commit */
    unsigned char path_type;                                    /* internal only */
    short uifnum;                                               /* # of iflist entries */
    unsigned short ustamp;                                      /* general I/O count number */
    short uftot;                                                /* total nr of field/entity entries */
    short uopen;                                                /* open indicator */
    short udrvnum;                                              /* driver sequence number */
    short usnr;                                                 /* ucontrol sequence number */
    short udatlen;                                              /* I/O datalength */
    short ulock;                                                /* lock indication i.e. if on no close */
                                                                /* request will be done by UNIFACE */
    short ufnum;                                                /* # of db entries in fieldlist */
    short uinum;                                                /* # of entries in indexlist */
    short uwnum;                                                /* # of entries in wherelist */
    short uonum;                                                /* # of entries in orderlist */
    short urecsiz;                                              /* maximum record size */
    short umaxhits;                                             /* hitlist stepsize (0 = all) */
    short uprimlen;                                             /* length (in bytes) of primary (logical) key */
    short unwchan;                                              /* network channel number (short) */
    short segcnt;                                               /* nr of overflow segments in db */
    short lstfld;                                               /* last field required in external schema */
    short udrvini;                                              /* driver logon initialising code */
    short vsfnr;                                                /* fld nr of first segmented field */
    short netnr;                                                /* net nr in uniface adminidtration */
    short uerrtyp;                                              /* errortype */
    unsigned char usumflag;                                     /* summation flag */
    unsigned char ucbstat;                                      /* status control block, if not 0 */
                                                                /* control block marked for deletion */
    unsigned char client;                                       /* true = control block on server for client */
    unsigned char umod;                                         /* if true modifications on ucontrol made */
    unsigned char where;                                        /* support of additional where clause */
    unsigned char txtsearch;                                    /* support of where on long fields */
    unsigned char udbms[3];                                     /* 3-character DBMS mnemonic */
    unsigned char unet[3];                                      /* 3-character network mnemonic */
    unsigned char upseudb;                                      /* 1-character pseudo DBMS mnemonic */
    unsigned char ufixvar;                                      /* indication Fixed/Variable record; */
                                                                /* true if variable length / long field */
    unsigned char uoverflw;                                     /* indication overflow control block */
    unsigned char unoupd;                                       /* indication no update allowed */
    unsigned char urdbykey;                                     /* true means 'do not use physical address' */
    unsigned char uralen;                                       /* size of physical address of records/rows */
    unsigned char ufiles;                                       /* file number of internal UNIFACE/IDF files */
    unsigned char uversion;                                     /* field U_VERSION is available */
    unsigned char uoptlock;                                     /* driver supports only optimistic locking */
    unsigned char umode;                                        /* function modifier */
    unsigned char udbtyp;                                       /* 0 = fieldlevel , 1 = record level I/O */
    unsigned char udbsub;                                       /* driver sub-type 1 = link setup requested */
    unsigned char uopnreq;                                      /* database open request needed */
    unsigned char uforcfix;                                     /* force variable records into fixed records */
    unsigned char unoconst;                                     /* 1, 2, 3: DBMS constraint handling */
    unsigned char udrvcod;                                      /* pseudo code for real dbms */
    unsigned char unetcod;                                      /* pseudo code for real network */
    unsigned char udynopt;                                      /* dynamic optimistic locking request */
    unsigned char uprofil[2];                                   /* profile ascii characters for any(*) */
                                                                /* and one character(%) */
    unsigned char ucset;                                        /* characterset (0=DEC multi; 1=IBM RT...) */
    unsigned char opnfil;                                       /* info->opnfil */
    unsigned char segctrl;                                      /* write main rec before/after segs */
    unsigned char func;                                         /* driver function */
    unsigned char dversion;                                     /* driver version */
    unsigned char fillercharacter;                              /* blank (ascii or ebcdic) */
    unsigned char like;                                         /* generate LIKE and NOT_LIKE */
    unsigned char Type;                                         /* Table(s) is/are a view  (no primaryKey) addrec only  */
    unsigned char TableOpenLevel;                               /* */
    unsigned char SqlString;
    unsigned char SqlNumber;
    unsigned char SqlFloat;
    unsigned char SqlDate;
    unsigned char SqlTime;
    unsigned char SqlDateTime;
    unsigned char SqlBoolean;
    unsigned char NotInDB;                                      /* @pr3: Flag Entity Not-in-DB */
    int	OpenError;                                              /* @pr1 */
    struct uactvinfo *actvinfo;
    int           FlatFile;                                     /* @pr6 indicate that a control block belongs to a flatfile */
    unsigned char TMEnabled;                                    /* @pr8 Mark entity/activate TM controlled */
};

typedef long (*uctrlfunc)(struct uctrl *);

struct udrvtab
{
    uctrlfunc entrypoint;
    char  **drvarea;
    short pseudo;
    short version;
    short maxcur;
    short filcnt;
    short curcnt;
    short logcnt;
};

#define pMAXPACKING     512                                     /* # of Possible PackingCodes */

struct uinfo                                                    /* UNIFACE driver info/characteristics data */
{
    uctrlfunc dis;                                              /* addres of UNIFACE driver dispatch address */
    short drvsiz;                                               /* workspace for io driver 'control data' */
    short indexes;                                              /* additional space for io driver per index */
    short fields;                                               /* additional space for io driver per field */
    short maxhits;                                              /* maximum nr of hits to select */
    short recsiz;                                               /* maximum record size supported by DBMS */
                                                                /* (0 = default = UNIFACE maximum = 8192 */
    short sizmod;                                               /* round up recordsize to multiple of sizmod */
    short maxkey;                                               /* maximum key size supported by DBMS */
    short maxfield;                                             /* maximum fieldsize */
    short maxcur;                                               /* maximum cursors = install[d]->maxcur */
    short updef[16];                                            /* type defaults ###NFDTEB */
    short upfmt[pMAXPACKING];                                   /* C,U,R,LC,LU,LR,#,#, N1-32, P1-16, Q1-16, */
                                                                /* I1, I2, I3, I4, I8, F4 ,F8 ,F16, D1-16, */
                                                                /* T1-16, E1-16, B1-B8,M1-M8, J1-32, O1-32, */
                                                                /* Y1-8, Z1-8 */
    unsigned char drvnum;                                       /* driver sequence number */
    unsigned char dbms[3];                                      /* 3-character DBMS mnemonic */
    unsigned char dbtyp;                                        /* 0 = fieldlevel , 1 = record level I/O */
    unsigned char ralen;                                        /* size of  record/row address */
    unsigned char opnfil;                                       /* maximum simultaneous active (open) files */
    unsigned char osegm;                                        /* segmented primary key for overflow */
    unsigned char bound;                                        /* field line up on 2-4 byte boundary */
    unsigned char filll;                                        /* # of filler bytes preceding the fields */
    unsigned char fillt;                                        /* # of filler bytes after the fields */
    unsigned char fillv;                                        /* # of filler bytes in front of the long */
                                                                /* and variable length fields */
    unsigned char limkey;                                       /* if true: key(s) are ASCII characters only */
    unsigned char limvar;                                       /* if true: variable length fields are */
                                                                /* ASCII characters only */
    unsigned char num[6];                                       /* packing code data type numeric/float */
                                                                /* if available (10,10,10,11,11,) */
    unsigned char nsize[6];                                     /* packing sizes if available */
                                                                /* (1,2,4,4,8,minimum) */
                                                                /* array:   [0] for I1 (char) */
                                                                /* [1] for I2 (short) */
                                                                /* [2] for I4 (long) */
                                                                /* [3] for F (float) */
                                                                /* [4] for D (double) */
                                                                /* [5] for N (number) */
    unsigned char date;                                         /* packing code DATE fields */
    unsigned char datsiz;                                       /* size of DATE fields */
    unsigned char datfmt;                                       /* format of DATE fields */
    unsigned char time;                                         /* packing code TIME fields */
    unsigned char timsiz;                                       /* size of TIME fields */
    unsigned char timfmt;                                       /* format of TIME fields */
    unsigned char dtime;                                        /* packing code DATE-TIME fields */
    unsigned char dtimsiz;                                      /* size of DATE-TIME fields */
    unsigned char dtimfmt;                                      /* format of DATE-TIME fields */
    unsigned char mode;                                         /* 0 = general info request, */
                                                                /* 1 = get login string in usql */
    unsigned char fixrec;                                       /* DBMS supports only fixed length records */
    unsigned char recoverh;                                     /* # of overhead bytes / record */
    unsigned char link;                                         /* dbms needs links to outer entities */
    unsigned char alrec;                                        /* align (fill out) total record m* n-byte */
    unsigned char ali2;                                         /* align 2-byte integer on n-bytes */
    unsigned char ali4;                                         /* align 4-byte integer on n-bytes */
    unsigned char alfloat;                                      /* align 4-byte float on n-bytes */
    unsigned char aldoub;                                       /* align 8-byte double on n-bytes */
    unsigned char aldate;                                       /* align DATE fields on n-bytes */
    unsigned char altime;                                       /* align TIME fields on n-bytes */
    unsigned char ale9;                                         /* align E9 data types on n-bytes */
    unsigned char alm6;                                         /* align M6 data types on n-bytes */
    unsigned char optlock;                                      /* optimistic locking wanted */
    unsigned char binpack;                                      /* packing Binary fields (U,B) default [B] */
    unsigned char noconst;                                      /* 1 = DBMS handles DELETE constraints */
                                                                /* 2 = DBMS handles UPDATE constraints */
                                                                /* 4 = No intermediate COMMIT on import */
                                                                /* combinatios allowed (0 ... 7) */
    unsigned char profil[2];                                    /* profile ascii characters for any(*) */
                                                                /* and one character(%) */
    unsigned char autovarsiz;                                   /* maximum size when 'S' and 'B' fields */
                                                                /* should get the varchar indicator */
    unsigned char boundv;                                       /* allign varchar type fields */
    unsigned char filltv;                                       /* fill trailing for varchar */
    unsigned char supzero;                                      /* supress leading zero's */
                                                                /* (make leading spaces for numeric) */
    unsigned char alseg;                                        /* allign for segmented type fields */
    unsigned char lenseg;                                       /* support and size of segmented indirection */
    unsigned char txtsearch;                                    /* support of where on long fields */
    unsigned char where;                                        /* support of additional where clause */
    unsigned char segctrl;                                      /* write main rec before/after segs */
    unsigned char twophase;                                     /* @pr9: != 0 means support 2-phase commit */
    unsigned char tabname;                                      /* 0 = Treat name filename */
                                                                /* 1 = Treat name as table name (ignore usys expansion) */
                                                                /* 2 = driver will be requested for (overflow) name */
    short primlen;                                              /* polyserver may alter this field only */
    unsigned char mapmode;                                      /* for undefines: 1 = don't map; 2 = map to dbms defaults */
    unsigned char incent;                                       /* true if support for included entities */
    unsigned char like;                                         /* generate LIKE and NOT_LIKE */
    unsigned char Conformance;                                  /* SQL conformance Level  */
    unsigned char TableOpenLevel;                               /* */
    unsigned char NewFloatingPointMapping;                      /* */
    unsigned char SqlString;
    unsigned char SqlNumber;
    unsigned char SqlFloat;
    unsigned char SqlDate;
    unsigned char SqlTime;
    unsigned char SqlDateTime;
    unsigned char SqlBoolean;
    unsigned char NullTerm;                                     /* null terminated character fields + delete trailing spaces */
    unsigned char TMCapable;                                    /* @pr8 Mark driver capable of TM control (0=no/1=yes) */
};

struct ufldlst                                                  /* field list */
{
    long ufmax;                                                 /* maximum size of entity/field data */
                                                                /* (null = variable length) */
    long uflen;                                                 /* actual size of entity/field data */
    short ufname;                                               /* offset to entity/field in label string */
    short ufpos;                                                /* offset to entity/field data in iobuf */
    short ufocc;                                                /* entity/field occurrence length */
                                                                /* (null = variable length) */
    short ufvar;                                                /* offset to 'variable length specs' */
                                                                /* if negative: "sub fields possible" */
    unsigned short ufbits;                                      /* bit 0 true: field is possible pointer, */
                                                                /* bit 1 true: field not in LUV */
                                                                /* bit 2 true: field is varchar */
                                                                /* bit 3 is segmented string */
                                                                /* bit 4 true: read by key */
                                                                /* bit 5 true means field has binary id */
                                                                /* bit 6 indicates mandatory field */
                                                                /* bit 7 generate leading spaces for numeric */
                                                                /*       instead of leading zero's */
                                                                /* bit 8 packing code A.. */

#define INPUT_BIT  (0x0400)        /* bit 9 INPUT parameter */
#define OUTPUT_BIT (0x0800)        /* bit 10 OUTPUT parameter */
#define MULVAL_BIT (0x1000)        /* bit 11 MULTI VALUE parameter */
#define NULLTERM_BIT (0x2000)      /* bit 12 Null terminated field */

    short         udbfmt;                                       /* Uniface database packing list code */
    short         ucsfmt;                                       /* Uniface conceptual packing list code */
    unsigned char uftyp;                                        /* data type: Raw, String, Numeric, Float */
                                                                /* Date, Time, Edate-time */
    unsigned char ufpack;                                       /* data packing (coded, 0 <= packing  < 100 */
    unsigned char ufscal;                                       /* for numeric fields scaling, */
                                                                /* for date/time fields format */
    unsigned char uindex;                                       /* if field belongs to one or more indexes, */
                                                                /* number of lowest index */
    unsigned char ulevel;                                       /* hierarchic level, for fields/entity */
    unsigned char ufix;                                         /* 0 = variable length (in variable part) */
                                                                /* 1 = fixed length (in variable part) */
                                                                /* 2 = fixed length (in fixed part) */
    unsigned char ufutyp;                                       /* UNIFACE data type */
};

struct uwhrlst                                                  /* where list */
{
    short ufnr;                                                 /* entry nr in ufldlst. */
                                                                /* 0 = physical key; < 0 = index number */
    short uwdat;                                                /* offset to profile field data */
    short uwlen;                                                /* actual length of profile field data */
    short wtype;
    unsigned char uqual;                                        /* qualifier;  0 = like, */
                                                                /* 1 = less then, */
                                                                /* 2 = less equal, */
                                                                /* 3 = equal, */
                                                                /* 4 = greater equal, */
                                                                /* 5 = greater then */
    unsigned char uquals;                                       /* additional qualifier */
                                                                /* bit 0 = "not" */
                                                                /* bit 1 = "or" */
                                                                /* bit 2 = "optional" */
                                                                /* bit 3 = "null" */
    unsigned char wcalc[48];
    unsigned char uprof;                                        /* Profiled search */
};

struct uiflst                                                   /* u_where list */
{
    short data;                                                 /* offset to data */
    short len;
    unsigned char ifdata[48];                                   /* value of data */
    unsigned char ifcalc[48];
    unsigned char level;                                        /* nesting level */
    unsigned char type;                                         /* field type (zie datyp.h) */
    unsigned char opr;                                          /* operator */
    unsigned char prio;                                         /* priority operator */
    unsigned char iftype;
    unsigned char ifopr;
};

struct uidxlst                                                  /* index list */
{
    short ufnr;                                                 /* entry nr in ufldlst */
    unsigned char uidxnr;                                       /* index number */
    unsigned char uidxsnr;                                      /* index sequence number */
    unsigned char uidxuni;                                      /* indicator unique */
    unsigned char uidxtest;                                     /* Internal use */
};

struct uordlst                                                  /* order by list */
{
    short ufnr;                                                 /* entry nr in ufldlst */
    short uorder;                                               /* 0 = ascending, 1 = descending */
};

/* define all packinglist codes by name and size here */

/* p?? define the packing code */
/* s?? define the storage size of the unit */

#define pC      0                                               /* character format 1-126 */
#define pU      1                                               /* (U) trx format  32-126 */
#define pR      2                                               /* Raw format 0-255 */
/* !!!! do not use packing code 7: it is being used already !!!!! */
#define pN1     8                                               /* Number digit format (inc decimal point) */
#define pN2     9                                               /* Number digit format  " */
#define pN3     10                                              /* Number digit format  " */
#define pN4     11                                              /* Number digit format  " */
#define pN5     12                                              /* Number digit format  " */
#define pN6     13                                              /* Number digit format  " */
#define pN7     14                                              /* Number digit format  " */
#define pN8     15                                              /* Number digit format  " */
#define pN9     16                                              /* Number digit format  " */
#define pN10    17                                              /* Number digit format  " */
#define pN11    18                                              /* Number digit format  " */
#define pN12    19                                              /* Number digit format  " */
#define pN13    20                                              /* Number digit format  " */
#define pN14    21                                              /* Number digit format  " */
#define pN15    22                                              /* Number digit format  " */
#define pN16    23                                              /* Number digit format  " */
#define pN17    24                                              /* Number digit format  " */
#define pN18    25                                              /* Number digit format  " */
#define pN19    26                                              /* Number digit format  " */
#define pN20    27                                              /* Number digit format  " */
#define pN21    28                                              /* Number digit format  " */
#define pN22    29                                              /* Number digit format  " */
#define pN23    30                                              /* Number digit format  " */
#define pN24    31                                              /* Number digit format  " */
#define pN25    32                                              /* Number digit format  " */
#define pN26    33                                              /* Number digit format  " */
#define pN27    34                                              /* Number digit format  " */
#define pN28    35                                              /* Number digit format  " */
#define pN29    36                                              /* Number digit format  " */
#define pN30    37                                              /* Number digit format  " */
#define pN31    38                                              /* Number digit format  " */
#define pN32    39                                              /* Number digit format  " */
#define pP1     40                                              /* Packed decimal format */
#define pP2     41                                              /* Packed decimal format */
#define pP3     42                                              /* Packed decimal format */
#define pP4     43                                              /* Packed decimal format */
#define pP5     44                                              /* Packed decimal format */
#define pP6     45                                              /* Packed decimal format */
#define pP7     46                                              /* Packed decimal format */
#define pP8     47                                              /* Packed decimal format */
#define pP9     48                                              /* Packed decimal format */
#define pP10    49                                              /* Packed decimal format */
#define pP11    50                                              /* Packed decimal format */
#define pP12    51                                              /* Packed decimal format */
#define pP13    52                                              /* Packed decimal format */
#define pP14    53                                              /* Packed decimal format */
#define pP15    54                                              /* Packed decimal format */
#define pP16    55                                              /* Packed decimal format */
#define pQ1     56                                              /* Packed decimal format */
#define pQ2     57                                              /* Packed decimal format */
#define pQ3     58                                              /* Packed decimal format */
#define pQ4     59                                              /* Packed decimal format */
#define pQ5     60                                              /* Packed decimal format */
#define pQ6     61                                              /* Packed decimal format */
#define pQ7     62                                              /* Packed decimal format */
#define pQ8     63                                              /* Packed decimal format */
#define pQ9     64                                              /* Packed decimal format */
#define pQ10    65                                              /* Packed decimal format */
#define pQ11    66                                              /* Packed decimal format */
#define pQ12    67                                              /* Packed decimal format */
#define pQ13    68                                              /* Packed decimal format */
#define pQ14    69                                              /* Packed decimal format */
#define pQ15    70                                              /* Packed decimal format */
#define pQ16    71                                              /* Packed decimal format */
#define pI1     72                                              /* Integer 1 */
#define pI2     73                                              /* Integer 2 */
#define pI3     74                                              /* Integer 3 */
#define pI4     75                                              /* Integer 4 */
#define pI8     76                                              /* Integer 8 */
#define pF4     77                                              /* Float 4 (Real) */
#define pF8     78                                              /* Float 8 (Double) */
#define pG8     79                                              /* G_Float 8 (Double) */
#define pD1     80                                              /* Date format DD-MMM-YYYY */
#define sD1     11
#define pD2     81                                              /* Date format YYYYMMDD */
#define sD2     8
#define pD3     82                                              /* Date format DDMMYYYY */
#define sD3     8
#define pD4     83                                              /* Date format YYMMDD */
#define sD4     6
#define pD5     84                                              /* Date format DDMMYY */
#define sD5     6
#define pD6     85                                              /* Date format YYMD(binary) */
#define sD6     -4
#define pD7     86                                              /* Date format DMYY(binary) */
#define sD7     -4
#define pD8     87                                              /* Date format YMD(binary) */
#define sD8     -3
#define pD9     88                                              /* Date format DMY(binary) */
#define sD9     -3
#define pD10    89                                              /* Date format YYMMDD(binary) */
#define sD10    -6
#define pD11    90                                              /* Date format DDMMYY(binary) */
#define sD11    -6
#define pD12    91                                              /* Date format MM/DD/YYYY */
#define sD12    10
#define pD13    92                                              /* Date format */
#define sD13    10
#define pD14    93                                              /* Date format */
#define sD14    0
#define pD15    94                                              /* Date format */
#define sD15    0
#define pD16    95                                              /* Date format */
#define sD16    0
#define pT1     96                                              /* Time format HH:MM:SS */
#define sT1     8
#define pT2     97                                              /* Time format HHMMSS */
#define sT2     6
#define pT3     98                                              /* Time format DDMMYYYY HHMMSS */
#define sT3     15
#define pT4     99                                              /* Time format */
#define sT4     8
#define pT5     100                                             /* Time format */
#define sT5     10
#define pT6     101                                             /* Time format */
#define sT6     11
#define pT7     102                                             /* Time format */
#define sT7     0
#define pT8     103                                             /* Time format */
#define sT8     0
#define pT9     104                                             /* Time format */
#define sT9     0
#define pT10    105                                             /* Time format */
#define sT10    0
#define pT11    106                                             /* Time format */
#define sT11    0
#define pT12    107                                             /* Time format */
#define sT12    0
#define pT13    108                                             /* Time format */
#define sT13    0
#define pT14    109                                             /* Time format */
#define sT14    0
#define pT15    110                                             /* Time format */
#define sT15    0
#define pT16    111                                             /* Time format */
#define sT16    0
#define pE1     112                                             /* Date-Time format Sybase Linear */
#define sE1     -8
#define pE2     113                                             /* Date-Time format RDB/RMS Linear */
#define sE2     -8
#define pE3     114                                             /* Date-Time format DDMMYYYY HH:MM:SS */
#define sE3     17
#define pE4     115                                             /* Date-Time format DDMMYYYY HHMMSS */
#define sE4     15
#define pE5     116                                             /* Date-Time format Ingres DD-MMM-YYYY HH:MM:SS */
#define sE5     25
#define pE6     117                                             /* Date-Time format Oracle packed */
#define sE6     -7
#define pE7     118                                             /* Date-Time format MM/DD/YYYY HH:MM:SS.TT */
#define sE7     22
#define pE8     119                                             /* Date-Time format YYYYMMDD HHMMSS */
#define sE8     15
#define pE9     120                                             /* Date-Time format */
#define sE9     -4
#define pE10    121                                             /* Date-Time format */
#define sE10    19
#define pE11    122                                             /* Date-Time format */
#define sE11    19
#define pE12    123                                             /* Date-Time format */
#define sE12    21
#define pE13    124                                             /* Date-Time format */
#define sE13    22
#define pE14    125                                             /* Date-Time format */
#define sE14    -16												/* @pr10 */
#define pE15    126                                             /* Date-Time format */
#define sE15    0
#define pE16    127                                             /* Date-Time format */
#define sE16    0
#define pB1     128                                             /* Boolean 0/1 */
#define sB1     1
#define pB2     129                                             /* Boolean T/F */
#define sB2     1
#define pB3     130                                             /* Boolean Y/N */
#define sB3     1
#define pB4     131                                             /* Boolean 0/1 (binary) */
#define sB4     -1
#define pB5     132                                             /* Boolean 0=TRUE, -1=FALSE */
#define sB5     -2
#define pB6     133                                             /* Boolean */
#define sB6     0
#define pB7     134                                             /* Boolean */
#define sB7     0
#define pB8     135                                             /* Boolean */
#define sB8     0
#define pM1     136                                             /* Money Sybase */
#define sM1     -8
#define pM2     137                                             /* Money */
#define sM2     -8
#define pM3     138                                             /* Money */
#define sM3     -8
#define pM4     139                                             /* Money */
#define sM4     -8
#define pM5     140                                             /* Money */
#define sM5     -8
#define pM6     141                                             /* Money */
#define sM6     -4
#define pM7     142                                             /* Money */
#define sM7     -8
#define pM8     143                                             /* Money */
#define sM8     -8
#define pJ1     144                                             /* Number digit format (excl decimal point) */
#define pJ2     145                                             /* Number digit format  " */
#define pJ3     146                                             /* Number digit format  " */
#define pJ4     147                                             /* Number digit format  " */
#define pJ5     148                                             /* Number digit format  " */
#define pJ6     149                                             /* Number digit format  " */
#define pJ7     150                                             /* Number digit format  " */
#define pJ8     151                                             /* Number digit format  " */
#define pJ9     152                                             /* Number digit format  " */
#define pJ10    153                                             /* Number digit format  " */
#define pJ11    154                                             /* Number digit format  " */
#define pJ12    155                                             /* Number digit format  " */
#define pJ13    156                                             /* Number digit format  " */
#define pJ14    157                                             /* Number digit format  " */
#define pJ15    158                                             /* Number digit format  " */
#define pJ16    159                                             /* Number digit format  " */
#define pJ17    160                                             /* Number digit format  " */
#define pJ18    161                                             /* Number digit format  " */
#define pJ19    162                                             /* Number digit format  " */
#define pJ20    163                                             /* Number digit format  " */
#define pJ21    164                                             /* Number digit format  " */
#define pJ22    165                                             /* Number digit format  " */
#define pJ23    166                                             /* Number digit format  " */
#define pJ24    167                                             /* Number digit format  " */
#define pJ25    168                                             /* Number digit format  " */
#define pJ26    169                                             /* Number digit format  " */
#define pJ27    170                                             /* Number digit format  " */
#define pJ28    171                                             /* Number digit format  " */
#define pJ29    172                                             /* Number digit format  " */
#define pJ30    173                                             /* Number digit format  " */
#define pJ31    174                                             /* Number digit format  " */
#define pJ32    175                                             /* Number digit format  " */
#define pO1     176                                             /* Number digit format  (DIBOL format) */
#define pO2     177                                             /* Number digit format  " */
#define pO3     178                                             /* Number digit format  " */
#define pO4     179                                             /* Number digit format  " */
#define pO5     180                                             /* Number digit format  " */
#define pO6     181                                             /* Number digit format  " */
#define pO7     182                                             /* Number digit format  " */
#define pO8     183                                             /* Number digit format  " */
#define pO9     184                                             /* Number digit format  " */
#define pO10    185                                             /* Number digit format  " */
#define pO11    186                                             /* Number digit format  " */
#define pO12    187                                             /* Number digit format  " */
#define pO13    188                                             /* Number digit format  " */
#define pO14    189                                             /* Number digit format  " */
#define pO15    190                                             /* Number digit format  " */
#define pO16    191                                             /* Number digit format  " */
#define pO17    192                                             /* Number digit format  " */
#define pO18    193                                             /* Number digit format  " */
#define pO19    194                                             /* Number digit format  " */
#define pO20    195                                             /* Number digit format  " */
#define pO21    196                                             /* Number digit format  " */
#define pO22    197                                             /* Number digit format  " */
#define pO23    198                                             /* Number digit format  " */
#define pO24    199                                             /* Number digit format  " */
#define pO25    200                                             /* Number digit format  " */
#define pO26    201                                             /* Number digit format  " */
#define pO27    202                                             /* Number digit format  " */
#define pO28    203                                             /* Number digit format  " */
#define pO29    204                                             /* Number digit format  " */
#define pO30    205                                             /* Number digit format  " */
#define pO31    206                                             /* Number digit format  " */
#define pO32    207                                             /* Number digit format  " */
#define pY1     208                                             /* Number USER format 1 */
#define pY2     209                                             /* Number USER format 2 */
#define pY3     210                                             /* Number USER format 3 */
#define pY4     211                                             /* Number USER format 4 */
#define pY5     212                                             /* Number USER format 5 */
#define pY6     213                                             /* Number USER format 6 */
#define pY7     214                                             /* Number USER format 7 */
#define pY8     215                                             /* Number USER format 8 */
#define pY9     216                                             /* Number USER format 9 */
#define pY10    217                                             /* Number USER format 10 */
#define pY11    218                                             /* Number USER format 11 */
#define pY12    219                                             /* Number USER format 12 */
#define pY13    220                                             /* Number USER format 13 */
#define pY14    221                                             /* Number USER format 14 */
#define pY15    222                                             /* Number USER format 15 */
#define pY16    223                                             /* Number USER format 16 */
#define pY17    224                                             /* Number USER format 17 */
#define pY18    225                                             /* Number USER format 18 */
#define pY19    226                                             /* Number USER format 19 */
#define pY20    227                                             /* Number USER format 20 */
#define pY21    228                                             /* Number USER format 21 */
#define pY22    229                                             /* Number USER format 22 */
#define pY23    230                                             /* Number USER format 23 */
#define pY24    231                                             /* Number USER format 24 */
#define pY25    232                                             /* Number USER format 25 */
#define pY26    233                                             /* Number USER format 26 */
#define pY27    234                                             /* Number USER format 27 */
#define pY28    235                                             /* Number USER format 28 */
#define pY29    236                                             /* Number USER format 29 */
#define pY30    237                                             /* Number USER format 30 */
#define pY31    238                                             /* Number USER format 31 */
#define pY32    239                                             /* Number USER format 32 */
#define pZ1     240                                             /* Date-time USER format 1 */
#define pZ2     241                                             /* Date-time USER format 2 */
#define pZ3     242                                             /* Date-time USER format 3 */
#define pZ4     243                                             /* Date-time USER format 4 */
#define pZ5     244                                             /* Date-time USER format 5 */
#define pZ6     245                                             /* Date-time USER format 6 */
#define pZ7     246                                             /* Date-time USER format 7 */
#define pZ8     247                                             /* Date-time USER format 8 */
#define pH8     248                                             /* IEEE 8 bytes floating point */
#define pH4     249                                             /* IEEE 4 bytes floating point */
#define pI16    250                                             /* Integer 16 */
#define pFD8    251                                             /* D_Floating Point */
#define pFG8    pFG8                                            /* G_Floating Point */

#define FIRST_CALL 0x01
#define LAST_CALL  0x02

typedef enum _ForeignKeyRuleType
{
    RESTRICT,
    CASCADE,
    NULLIFY
} ForeignKeyRuleType;

typedef enum _KeyTypeType
{
    PRIMARY_KEY,
    CANDIDATE_KEY
} KeyTypeType;

typedef struct _RelationshipType
{
    unsigned char *RelationshipName;                            /* Null terminated name of the */
                                                                /*  relationship (user defined). */
    unsigned char *OneConceptualSchemaName;                     /* The name of the conceptual schema */
                                                                /*  in which the one entity resides. */
    unsigned char *ManyConceptualSchemaName;                    /* The name of the conceptual schema */
                                                                /*  in which the many entity resides. */
    unsigned char *RelatedEntityName;                           /* The name of the related entity, */
                                                                /*  as defined in the conceptual schema, */
                                                                /*  i.e. before entity assignment. */
    unsigned char *RelatedTableName;                            /* The name of the related table after */
                                                                /*  entity assignment. May contain full */
                                                                /*  OS file name. The driver must parse */
                                                                /*  the name, like it does with */
                                                                /*  uctrl->uname in modes 0, 1 and 2. */
    int IsOverflow;                                             /* Boolean value indication whether the */
                                                                /*  relationship is between a table and */
                                                                /*  it's overflow table. */
    int KeyNumber;                                              /* UNIFACE index number of the referenced */
                                                                /*  key in the one-table. */
    KeyTypeType KeyType;                                        /* Type of the referenced key in the */
                                                                /*  one-table. UNIFACE does not currently */
                                                                /*  support relationships on type */
                                                                /*  CANDIDATE_KEY. */
    int RIFields;                                               /* The number of fields in the foreign */
                                                                /*  key and in the referenced key. */
    int *RIFieldNumberList;                                     /* An array of 'RIFields' field numbers. */
                                                                /*  These identify the fields in the key */
                                                                /*  (primary, candidate or foreign) of the */
                                                                /*  current table in the relationship */
                                                                /*  (that is the table which is described */
                                                                /*  by the current control block). */
    unsigned char **RIFieldNameList;                            /* An array of 'RIFields' pointers to */
                                                                /*  null-terminated field names. */
                                                                /*  These identify the fields in the key */
                                                                /*  (primary, candidate or foreign) of the */
                                                                /*  related table in the relationship */
                                                                /*  (that is the table which is not */
                                                                /*  described by the current control */
                                                                /*  block). */
    ForeignKeyRuleType OnDelete;                                /* RESTRICT, CASCADE, NULLIFY. */
} RelationshipType;

typedef struct _RelationshipInfoType
{
    RelationshipType *OneRelationshipList;                      /* An array of RelationshipType */
                                                                /*  structures describing the */
                                                                /*  relationships in which the */
                                                                /*  table described by the current */
                                                                /*  control block has the `one' */
                                                                /*  role. */
    int OneRelationships;                                       /* Number of elements in the */
                                                                /*  OneRelationshipList. */
    RelationshipType *ManyRelationshipList;                     /* An array of RelationshipType */
                                                                /*  structures describing the */
                                                                /*  relationships in which the */
                                                                /*  table described by the current */
                                                                /*  control block has the `many' */
                                                                /*  role. */
    int ManyRelationships;                                      /* Number of elements in the */
                                                                /*  ManyRelationshipList. */
} RelationshipInfoType;


extern long ucnvint(struct uctrl *, unsigned char *, unsigned char *, int);
extern long ucnvext(struct uctrl *, unsigned char *, unsigned char *, int);
#define uconvint(uctrl,src,dst) ucnvint(uctrl,src,dst,0)
#define uconvext(uctrl,src,dst) ucnvext(uctrl,src,dst,0)
extern void usumhit(struct uctrl *);
extern void usumfld(struct uctrl *, unsigned char *, short , short);
extern short udcurscnt(struct uctrl *, short, short);
extern short udfilcnt(struct uctrl *, short, short);
extern short udpathset(struct uctrl *, short, short);
extern short udgetasn(struct uctrl *, unsigned char *, unsigned char *, short);
extern struct uctrl *uloadcb(struct uctrl *);
extern short ugethit(struct uctrl *, unsigned char *, unsigned char *);
extern void uaddsql(struct uctrl *, unsigned char *);
extern void uaddhit(struct uctrl *, unsigned char *, short, unsigned char *, short, unsigned char *, short);
extern void uaddrec(struct uctrl *, unsigned char *, short, unsigned char *, short, unsigned char *, short);
extern short uready(struct uctrl *);
extern short uhitchk(struct uctrl *, short, unsigned char *);
extern void unullify(struct uctrl *, int);
extern void ubldprm(struct uctrl *, short);
extern void ubldprim(struct uctrl *, unsigned char *);
extern short uprimpos(struct uctrl *, short);
extern short ufgetp(struct uctrl *, unsigned char *, unsigned char *, short);
extern void uputblob(struct uctrl *, int, unsigned char *, long, int);
extern long ugetblob(struct uctrl *, int, unsigned char *, long, int);
extern short udbconv(struct uctrl *, unsigned char *, unsigned char *, short, struct ufldlst *, short);
extern short uconvdb(struct uctrl *, unsigned char *, unsigned char *, short, struct ufldlst *, short);
extern void uaddEntParmHit(struct uctrl *uctrl);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* !UIODEF_H */
