/* @(#)CONT_ID %fv: utypes.h-3 % %dc: Mon Aug  4 11:29:51 1997 % (#)@ */

/****************************************************************************
 *
 * (c) 1996 Compuware, UNIFACE B.V.
 *
 * Uniface C-lib types
 *
 * File         utypes.h
 ****************************************************************************/




#ifndef UTYPES_H
#define UTYPES_H

typedef void		UVOID;
typedef long		ULONGINT;
typedef unsigned char	UBYTE;
typedef UBYTE 		UARRAY;          /* buffer values 0-255  */
typedef UARRAY		USTRING;         /* buffer values 1-255 closed with 0 */
typedef void *          UNATIVE;         /* OTYP_NATIVE */
typedef int             UBOOL;           /* OTYP_BOOL   */
typedef long            UNUMBER;         /* OTYP_NUMBER */
typedef double          UFLOAT;          /* OTYP_FLOAT  */
typedef double          UNIDATE;         /* OTYP_(L)DATE, OTYP_(L)TIME, OTYP_(L)DATIM */
typedef unsigned char   USTR;            /* OTYP_STR, OTYP_RAW, OTYP_IMAGE */
typedef struct uctrl *  UCTRL;           /* control block */


/* -- Macros */

#define NO_STRING	 (USTRING *) NULL

#define UMAX(a,b)        (((a) > (b)) ? (a) : (b))
#define UMIN(a,b)        (((a) < (b)) ? (a) : (b))
#define UABS(a)          (((a) >= 0) ? (a) : -(a))


#endif   /* UTYPES_H */
/* End of File utypes.h */
