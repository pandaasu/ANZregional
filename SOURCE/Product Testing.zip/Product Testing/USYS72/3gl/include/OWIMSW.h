/* @(#)CONT_ID %fv: owimsw.h-11 % %dc: Wed Jan  7 17:10:04 1998 % (#)@ */
/***************************************************************************\
* Open Widget Interface public definitions - Windows version                *
*                                                                           *
* file     OWIMSW.H                                                         *
* author   Hanpeter                                                         *
* status   Development                                                      *
* history                                                                   *
*-pr-uspr--date---who--summary----------------------------------------------*
*          930620 HPvV Created                                              *
* -- 6524  940905 HPvV Extensions and cleanup for 6.1.d                     *
* -- 9534  950522 HPvV Made C++ aware                                       *
*  1 8027  950623 TW   Made buildable for NT                                *
*  2 10178 950906 FW   Added udetailpos                                     *
*  3 6710  950915 FW   Windows 95 support                                   *
*  4 13688 960514 JLE  Added Enhanced Printing Attribute (PrintDC)          *
*  5 13688 960610 JLE  Added Word Wrapping/owiDrawTextEx                    *
*  6 13688 960626 JLE  Added a flag for getting DIB froms GetImage          *
*  7 11236 961202 ASP  User messages from UPI<-->OWI                        *
*  8 15972 961217 FW   Added owiGetState                                    *
*  9 13562 970220 PBR  Added oMessageBox service                            *
* 10       970523 PBK  Added owiNlsStyle                                    *
* 11 17588 970428 JdK  Zoom window.                                         *
* 12 17411 970613 PBR  Added owiNlsDBCSLead                                 *
* 13 00086 970613 ASP  owiNlsDBCSLead returns BOOL                          *
* 14 d00166 970716 PBR Added owiGetFocusWid, owiSetFocusWid                 *
* 15 18325 970918 JdK  Added owiTooltip and defines.                        *
* 16 18200 971020 PBK  Added NlsDrawText defines                            *
* 17 19225 980107 wbe  Added NoQuit option in OwiZoom                       *
\***************************************************************************/

#ifndef OWIMSW_H
#define OWIMSW_H


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/***************************************************************************/
/* DEPENDENCIES                                                            */
/***************************************************************************/

/* include windows.h before this file to define the following types:       */

/* UINT       unsigned int                                                 */
/* HWND       window handle                                                */
/* WPARAM     first message parameter                                      */
/* LPARAM     second message parameter                                     */
/* HFONT      font handle                                                  */
/* HBITMAP    bitmap (DDB) handle                                          */
/* HMETAFILE  metafile handle                                              */
/* HPALETTE   palette handle                                               */
/* RECT       rectangle                                                    */
/* COLORREF   rgb triple                                                   */
/* WNDPROC    window procedure pointer                                     */
/* MDICREATESTRUCT parameter structure for WM_MDICREATE                    */

/***************************************************************************/
/* CONSTANTS                                                               */
/***************************************************************************/

/* Palette management */

#define OCMD_PALETTECHANGED     OCMD_PLATFORM+1
#define ONTF_PALETTECHANGED     ONTF_PLATFORM+1
#define OATT_PALETTE            OATT_PLATFORM+1

/* OCMD_SETUPCHANGE ids */

#define OINI_UPI                 1      /* [upi] section */
#define OINI_TOOLBAR             2      /* [toolbar] section */
#define OINI_COLOR               3      /* [foreground] and/or [background] section */
#define OINI_SCREEN              4      /* [screen] section (fonts) */

/* owiGetImageEx styles */

#define OIMG_UNATIVE             0x0001 /* pData format is UNATIVE */
#define OIMG_DIALOG              0x0002 /* popup filter dialog if applicable */
#define OIMG_GSCALE              0x0004 /* map to grayscale */
#define OIMG_STDPALETTE          0x0008 /* map to standard palette */
#define OIMG_QDITHER             0x0010 /* quick (ordered) dither - NOT YET */
#define OIMG_DITHER              0x0020 /* dither (error diffusion) - NOT YET */
#define OIMG_GETDIB              0x0040 /* request image in DIB format */ /* @pr6 */

/* owiDrawText/Image styles */
                                        /* I=Image only, T=Text only, B=Both */
#define ODRW_ISOTROPIC           0x0001 /* I: preserve aspect ratio */
#define ODRW_GRAYED              0x0002 /* B: draw grayed out */
#define ODRW_3D                  0x0004 /* T: draw with 3d effect */
#define ODRW_XPARENT             0x0008 /* B: do not draw background */
#define ODRW_NOCLIP              0x0010 /* B: do not clip to format rect */
#define ODRW_MNEMONIC            0x0020 /* T: draw mnemonic characters underlined */
#define ODRW_NOWRAP              0x0040 /* T: do not wordwrap */
#define ODRW_NLSSTYLE            0x0080 /* @pr16: Draw text in Nls style, e.g. RTL */
#define ODRW_WRAPPERNLSSTYLE     0x0100 /* @pr16: Leave NLS styles up to Owidrawtext(ex)*/
#define ODRW_CALCRECT            0x1000 /* B: calculate rectangle only */
#define ODRW_PRERENDER           0x2000 /* I: render metafile on bitmap only */
#define ODRW_UPDATECOLORS        0x4000 /* B: update colors after palettechange only */

/* owiTooltip - tooltip sub functions */
#define OTIP_CREATE              0x0000 /* @pr15 Create new tooltip     */
#define OTIP_DELETE              0x0001 /* @pr15 Delete current tooltip */
#define OTIP_ACTIVE              0x0002 /* @pr15 Is tooltip active?     */

/* Win32 control color message mappings */

#ifndef WM_CTLCOLORBTN
   #define WM_CTLCOLORBTN               WM_CTLCOLOR
   #define WM_CTLCOLORDLG               WM_CTLCOLOR
   #define WM_CTLCOLORLISTBOX           WM_CTLCOLOR
   #define WM_CTLCOLORMSGBOX            WM_CTLCOLOR
   #define WM_CTLCOLORSCROLLBAR         WM_CTLCOLOR
   #define WM_CTLCOLORSTATIC            WM_CTLCOLOR
   #define WM_CTLCOLOREDIT              WM_CTLCOLOR
#endif /* !WM_CTLCOLORBTN */

/* Win32 control color message cracker mappings */

#ifndef HANDLE_WM_CTLCOLORBTN
   #define HANDLE_WM_CTLCOLORBTN        HANDLE_WM_CTLCOLOR
   #define HANDLE_WM_CTLCOLORDLG        HANDLE_WM_CTLCOLOR
   #define HANDLE_WM_CTLCOLORLISTBOX    HANDLE_WM_CTLCOLOR
   #define HANDLE_WM_CTLCOLORMSGBOX     HANDLE_WM_CTLCOLOR
   #define HANDLE_WM_CTLCOLORSCROLLBAR  HANDLE_WM_CTLCOLOR
   #define HANDLE_WM_CTLCOLORSTATIC     HANDLE_WM_CTLCOLOR
   #define HANDLE_WM_CTLCOLOREDIT       HANDLE_WM_CTLCOLOR
#endif /* !HANDLE_WM_CTLCOLORBTN */

/***************************************************************************/
/* ATTRUBUTES                                                    @pr4      */
/***************************************************************************/

#define OATT_PRINTDC    OATT_PLATFORM       // @pr4 : HDC to print to

/***************************************************************************/
/* DATA TYPES                                                              */
/***************************************************************************/

/* Platform dependent types for OWI.H */

typedef struct _widinst*           WMLINK;  /* link to GUI driver widget instance */
typedef COLORREF                   UCOLOR;  /* color spec */
typedef struct HWND__ NEAR * HPARENT;       /* parent window handle @pr1, @pr3 */
typedef void*                      HWIDGET; /* handle to OWI widget instance */
typedef void*                      HCLIENT; /* handle to OWI client instance - NOT USED IN WINDOWS */
typedef void*                      HANCHOR; /* handle to global context - NOT USED IN WINDOWS */

/* Image structure */

typedef struct _owiimg
{
   UINT      uStyle;                    /* internal use */
   HBITMAP   hbImage;                   /* main bitmap */
   int       nColors;                   /* number of colors */
   HPALETTE  hPalette;                  /* palette */
   int       cx;                        /* width of bitmap */
   int       cy;                        /* height of bitmap */
   HMETAFILE hMeta;                     /* metafile */
   RECT      rMeta;                     /* metafile extent */
   HBITMAP   hbIconANDMask;             /* icon mask */
   HANDLE    hDIB;                      /* DIB version */
} OWIIMG, *POWIIMG;

/***************************************************************************/
/* SERVICES                                                                */
/***************************************************************************/

/* Message handling */

extern long    owiDefWndProc(WMLINK wmlink, HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, WNDPROC pfDefProc);
extern BOOL    owiKeyFilter(WMLINK wmlink, HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

/* Fonts */

extern HFONT   owiCreateFont(WMLINK wmlink, char *pszLogicalName, UINT uStyle);
extern void    owiDestroyFont(WMLINK wmlink, HFONT hFont);

/* Images */

extern POWIIMG owiGetImage(WMLINK wmlink, char cType, char *pszImage);
extern POWIIMG owiGetImageEx(WMLINK wmlink, char cType, void *pData, int cx, int cy, int nDepth, UINT uFlags);
extern void    owiFreeImage(WMLINK wmlink, POWIIMG pImage);
extern BOOL    owiDrawImage(WMLINK wmlink, HDC hdc, POWIIMG pImage, LPRECT lpr, int hScale, int vScale,
                            int hAlign, int vAlign, int hOffset, int vOffset, UINT uFlags);

/* Text */

extern BOOL    owiDrawText(WMLINK wmlink, HDC hdc, char *pszText, HFONT hFont, LPRECT lpr, int hAlign, int vAlign, UINT uFlags);
extern BOOL    owiDrawTextEx(WMLINK wmlink, HDC hdc, char *pszText, HFONT hFont, LPRECT lpr, int hAlign, int vAlign, UINT uFlags, UINT iFirstLine, UINT iLastline);

/*
** @pr15 -Service function for maintaining a tooltip in a widget.
*/
extern BOOL owiTooltip(               //out: 1 | 0  on iAction = 0
                 WMLINK link,         //in: Link to owi interface.
                 char   *pszTipText,  //in: Text for tooltip.
                 HWND   hParent,      //in: Parent windowhandle
                 int    iAction);     //in: OTIP_NEW|OTIP_DEL|OTIP_SHOW

/* MDI window management */

extern HWND    owiCreateMDIChild(WMLINK wmlink, MDICREATESTRUCT *pMDI);
extern void    owiDestroyMDIChild(WMLINK wmlink, HWND hWnd);

extern int     owiDetailPos(WMLINK wmlink, int xPos, int yPos);      // @pr2
extern char *  owiWordWrap(WMLINK wmlink, HDC hDC, char * pszText, HFONT hFont, int cx, UINT * piLines);

extern long    owiGetState(WMLINK wmlink);                           // @pr8

/*
** @pr11 zoom service functions, to be used in combination with the
** OATT_NEWPARENT attrib.
** Widget may not call this when OATT_NEWPARENT is not supported.
*/
long owiZoom(WMLINK wmlink,
             long lZoom,          /* 1 = Quick zoom 0 = normal zoom */
             char *pszTitle,     /* Text in titlebar of zoom window*/
             BOOL bNoQuit);      /* true if quit not possible @pr17 */

long owiUnZoom(WMLINK wmlink);     /* @pr11 */

extern long    owiNlsStyle(WMLINK wmlink, int iStyleRequest);        // @pr10
extern BOOL    owiNlsDBCSLead(WMLINK wmlink, char cTest);            // @pr12 @pr13

/* Message from UPI to OWI widgets */                                // @pr7

#define WM_UPIOWI           (WM_USER+2000)
#define WM_CANCELCAPTURE    WM_UPIOWI
                                                                                                  // @pr5 - end
/* Askmess-style message box */

extern int     oMessageBox(WMLINK wmlink, int iMsg);                 // @pr9

/* @pr14 Widget focus services */

extern LPVOID   owiGetFocusWid(WMLINK wmlink);                       // @pr14
extern BOOL     owiSetFocusWid(WMLINK wmlink, LPVOID lpWid);         // @pr14

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* !OWIMSW_H */
