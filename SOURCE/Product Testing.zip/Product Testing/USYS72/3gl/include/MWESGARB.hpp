/* CONT_ID %fv: mwesgarb.hpp-4 % %dc: Mon Jul  6 08:28:22 1998 %"; */
/*****************************************************************************
@DOC

@COPYRIGHT
    Compuware Europe BV Copyright (c) 1997
@MODULE
    <Module-Id>
@INTERFACE

@FILE
    %name: mwesgarb.hpp % - Definition of the class which implements the ICC interface for Encina
@INMODULE
    <module title>
@OWNER
    %created_by: sjaak %
@HISTORY
      Seq. Date   RefNum  Version Who  Description 
      ------------------------------------------------------------------------
@pr     0  980630 e02545  7.2.03  JLE  Initial version (in this form)
@pr     1  980706 e02545  7.2.03  sse  Include dce/pthread.h on SUN
      ------------------------------------------------------------------------
      Seq. Date   RefNum  Version Who  Description 

@CHANGE_DESCR
      @pr

@END
*****************************************************************************/

#ifndef __MWESGARB_HPP_INCLUDED__
#define __MWESGARB_HPP_INCLUDED__

// Use same define to include pthread.h as Transarc uses
extern "C" {
#if defined (sun)
// For Transarc DCE on SUN include dce/pthread.h
# include <dce/pthread.h>
#else   /* sun */
# include <pthread.h>
#endif  /* sun */
}

#include <encina/symbols.h>
#include <trpc/trpc.h>
#include <ots/dce/otsInterfaceMgr.H>

#if defined(_WIN32) && defined(DEFINING_GARBAGE)
#define GARBAGE_LINKING __declspec(dllexport)
#else
#define GARBAGE_LINKING
#endif


//-- Base class for objects which can be managed by the garbage collector
class GarbageCollectable
{
friend class GarbageCenter;

public:
    GARBAGE_LINKING GarbageCollectable(long timeout = 2 * 60 * 60);

    GARBAGE_LINKING int isDeleted()             { return deleted; };
    GARBAGE_LINKING void setDeleted()           { deleted = 1; };

    GARBAGE_LINKING void insertAfter(GarbageCollectable * object);
    GARBAGE_LINKING void removeFromList();

    GARBAGE_LINKING void GarbageCollectable::resetExpirationTime();

    GARBAGE_LINKING OtsInterfaceMgr * getInterfaceMgr() { return interfaceMgr; }; 
    GARBAGE_LINKING void setInterfaceMgr(OtsInterfaceMgr * newInterfaceMgr) { interfaceMgr = newInterfaceMgr; };

private:
    int deleted;
    long lifeTime;
    long expirationTime;
    GarbageCollectable * next;
    GarbageCollectable * prev;
    OtsInterfaceMgr * interfaceMgr;
};

/*
//-- Special calling convention for Windows platforms
#ifdef WIN32
#define ENCINA_CALLBACK __stdcall
#else
#define ENCINA_CALLBACK
#endif
*/

//-- The garbage collector for all UNIFACE-Encina servers
class GarbageCenter
{
public:
    GARBAGE_LINKING GarbageCenter(
        long collectorWaitTime = 10 * 60,
        long destructorWaitTime = 20, 
        long maxDeadObjects = 32);
    GARBAGE_LINKING ~GarbageCenter();

    GARBAGE_LINKING static void start();
    GARBAGE_LINKING static void stop();

    GARBAGE_LINKING static void insertObject(GarbageCollectable * object);
    GARBAGE_LINKING static void deleteObject(GarbageCollectable * object, int activateGarbageDestructor = 1);

    //-- Time functions
    GARBAGE_LINKING static long now();
    GARBAGE_LINKING static long laterThanNow(long howMuchLater); 
    GARBAGE_LINKING static void laterThanNow(long howMuchLater, timespec_t * result);

private:
    //-- Coordination functions
    static void lockLivingList();
    static void unlockLivingList();
    static void lockDeadList();
    static void unlockDeadList();

    //-- Living objects administration
    static GarbageCollectable * livingObjects;
    static int noLivingObjects;
    static pthread_mutex_t livingMutex;
    static pthread_cond_t livingCondition;
    
    //-- Dead objects administration
    static GarbageCollectable * deadObjects;
    static GarbageCollectable * waitingObject; 
    static long numDeadObjects;
    static pthread_mutex_t deadMutex;
    static pthread_cond_t deadCondition;
    static long deadObjectsTiggerLevel;

    //-- Garbage Collector
    static int collectorStarted;
    static void * garbageCollector(void *);
    static pthread_t collectorThread;
    static long collectorInterval;

    //-- Garbage Destructor
    static int destructorStarted;
    static void * garbageDestructor(void *);
    static pthread_t destructorThread;
    static long destructorInterval;

    //-- Callback function to do the pre- and post-processing
    static void ENCINA_CALLING preProcessor(
                    rpc_binding_handle_t handle,
                    void *               argP,
                    trpc_tranInfo_t *,
                    trpc_ifSpec_t *);
    static void ENCINA_CALLING postProcessor(
                    rpc_binding_handle_t handle,
                    void *               argP,
                    trpc_tranInfo_t *,
                    trpc_ifSpec_t *);

    static GarbageCollectable * findLivingObject(OtsInterfaceMgr * object);
    static GarbageCollectable * findDeadObject(OtsInterfaceMgr * object);
};

//-- The globally accessible garbage collector for this server
extern GarbageCenter * cleaningCo;

#endif //-- __MWESGARB_HPP_INCLUDED__
