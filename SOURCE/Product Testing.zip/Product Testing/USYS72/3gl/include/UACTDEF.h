/* Compuware UNIFACE */
/* File: uactdef.h */

#ifndef UACTDEF_H
#define UACTDEF_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/* -- Include Files */

#include "utypes.h"


/* -- Macro constants */

/* UNIFACE environment error code for functions UECREATE(), UEOPEN() and UEDELETE() */
#define UINI_SUCCESS                         1 
#define UINI_LOAD_ERROR                     -1 
#define UINI_LICENCE_ERROR                  -2 
#define UINI_ALLOC_ERROR                    -4

/* UNIFACE run modes for UECREATE() */
#define URUN_CLIENT                          0  /* Not supported yet */
#define URUN_BATCH_CLIENT                    1  /* As client in batch mode */ 
#define URUN_SERVER                          2  /* In server mode */

/*
 * Activate error codes
 */
#define UACT_SUCCESS                         0 
#define UACT_FAILURE                        -1

/*
 * New_instance communication modes
 */
#define UDEFAULT_COMM_MODE                   0
#define USYNC_COMM_MODE                      1
#define UASYNC_COMM_MODE                     2

/*
 * Name size definitions
 */
#define UFSZ_F16          16
#define UFSZ_F32          32
#define ULIBNAMESIZE      UFSZ_F16                   /* library */
#define UCPTNAMESIZE      UFSZ_F32                   /* component */
#define ULIBCPTNAMESIZE  (UFSZ_F16 + 1 + UFSZ_F32)   /* library + '.' + component */
#define UINSTNAMESIZE     UFSZ_F16                   /* instance */
#define UOPRNAMESIZE      UFSZ_F16                   /* operation */
#define UPRMNAMESIZE     (UFSZ_F32 + 1 + UFSZ_F32)   /* parameter (entity + '.' + model) */

/*
 * Data type definitions
 */
#define UTYPE_UNKNOWN            0
#define UTYPE_STRING             1
#define UTYPE_BOOLEAN            2
#define UTYPE_NUMERIC            3
#define UTYPE_FLOAT              4
#define UTYPE_DATE               5
#define UTYPE_TIME               6
#define UTYPE_DATETIME           7
#define UTYPE_LDATE              8
#define UTYPE_LTIME              9
#define UTYPE_LDATETIME         10
#define UTYPE_RAW               11
#define UTYPE_IMAGE             12
#define UTYPE_ENTITY            13

/*
 * Parameter directions
 */
#define UPARM_INPUT           0x01
#define UPARM_OUTPUT          0x02

/*
 * Item list options
 */
#define UITEM_OPTION_NONE        0
#define UITEM_OPTION_ID          1
#define UITEM_OPTION_ID_CASE     2


/* -- Types */

typedef struct AnyInfo *    UHACT;
typedef unsigned char       UCHAR;


/* -- Prototypes */

/*
 * Call in
 */

/* Initialization functions */
extern long UECREATE (int, UVOID *, UCHAR *, UCHAR *,
                      UCHAR *, UCHAR *, UHACT *);
extern long UEOPEN   (UHACT *);
extern long UEDELETE (UHACT, int);

/* Instance functions */
extern long UINSTNEW (UHACT, UCHAR *, UCHAR *, UCHAR *,
                      int, UCHAR *, UHACT *, long *);
extern long UINSTOPN (UHACT, UCHAR *, UHACT *);
extern long UINSTDEL (UHACT, long *);
extern long UINSTOPR (UHACT, UCHAR *, int, UHACT *);

/* Operation functions */
extern long UOPRACT  (UHACT, long *, long *);
extern long UOPRPRMS (UHACT, long *);

/* Basic and entity parameter functions */
extern long UPRMPUTH (UHACT, int, UHACT);
extern long UPRMGETH (UHACT, int, UBOOL, UHACT *);
extern long UPRMTYPE (UHACT, int *);
extern long UPRMPUTS (UHACT, UCHAR *);
extern long UPRMGETS (UHACT, UCHAR **);
extern long UPRMDIR  (UHACT, int, int *);

/* Entity functions */
extern long UENTOCCS (UHACT, long *);
extern long UENTFLDS (UHACT, long *);
extern long UENTCREO (UHACT, long);
extern long UENTREMO (UHACT, long);
extern long UENTSETO (UHACT, long);
extern long UENTGETO (UHACT, long *);

/* Item list functions */
extern long ULISTNEW (UHACT, UHACT *);
extern long ULISTGET (UHACT, int, int, UCHAR *, UCHAR **);
extern long ULISTPUT (UHACT, int, int, UCHAR *, UCHAR *);
extern long ULISTDEL (UHACT, int, int, UCHAR *);

/* Memory functions */
extern long UNIALLOC (UHACT, long, UVOID **);
extern long UNIFREE  (UHACT, UVOID *);
extern long UFREEH   (UHACT *);

/* Miscellaneous functions */
extern long UNINAME  (UHACT, int, int, UCHAR *);

/* Parameter conversion functions */
extern long UCHAR2UF (UHACT, int, UBYTE);
extern long UINT2UF  (UHACT, int, int);
extern long ULONG2UF (UHACT, int, long);
extern long UDBL2UF  (UHACT, int, double);
extern long USTR2UF  (UHACT, int, UCHAR *);
extern long UBIN2UF  (UHACT, int, UBYTE *, long);
extern long ULIST2UF (UHACT, int, UHACT);
extern long UUF2CHAR (UHACT, int, UBYTE *);
extern long UUF2INT  (UHACT, int, int *);
extern long UUF2LONG (UHACT, int, long *);
extern long UUF2DBL  (UHACT, int, double *);
extern long UUF2STR  (UHACT, int, UCHAR **);
extern long UUF2BIN  (UHACT, int, UBYTE **, long *);
extern long UUF2LIST (UHACT, int, UHACT);

/*
 * Call out
 */

/* Parameter functions */
extern long UGETPARM (UCTRL, UVOID *, int);
extern long UPUTPARM (UCTRL, UVOID *, int);

#ifdef u_lowercase

/*
 * Call in
 */

/* Initialization functions */
extern long uecreate (int, UVOID *, UCHAR *, UCHAR *,
                      UCHAR *, UCHAR *, UHACT *);
extern long ueopen   (UHACT *);
extern long uedelete (UHACT, int);

/* Instance functions */
extern long uinstnew (UHACT, UCHAR *, UCHAR *, UCHAR *,
                      int, UCHAR *, UHACT *, long *);
extern long uinstopn (UHACT, UCHAR *, UHACT *);
extern long uinstdel (UHACT, long *);
extern long uinstopr (UHACT, UCHAR *, int, UHACT *);

/* Operation functions */
extern long uopract  (UHACT, long *, long *);
extern long uoprprms (UHACT, long *);

/* Basic and entity parameter functions */
extern long uprmputh (UHACT, int, UHACT);
extern long uprmgeth (UHACT, int, UBOOL, UHACT *);
extern long uprmtype (UHACT, int *);
extern long uprmputs (UHACT, UCHAR *);
extern long uprmgets (UHACT, UCHAR **);
extern long uprmdir  (UHACT, int, int *);

/* Entity functions */
extern long uentoccs (UHACT, long *);
extern long uentflds (UHACT, long *);
extern long uentcreo (UHACT, long);
extern long uentremo (UHACT, long);
extern long uentseto (UHACT, long);
extern long uentgeto (UHACT, long *);

/* Item list functions */
extern long ulistnew (UHACT, UHACT *);
extern long ulistget (UHACT, int, int, UCHAR *, UCHAR **);
extern long ulistput (UHACT, int, int, UCHAR *, UCHAR *);
extern long ulistdel (UHACT, int, int, UCHAR *);

/* Memory functions */
extern long unialloc (UHACT, long, UVOID **);
extern long unifree  (UHACT, UVOID *);
extern long ufreeh   (UHACT *);

/* Miscellaneous functions */
extern long uniname  (UHACT, int, int, UCHAR *);

/* Parameter conversion functions */
extern long uchar2uf (UHACT, int, UBYTE);
extern long uint2uf  (UHACT, int, int);
extern long ulong2uf (UHACT, int, long);
extern long udbl2uf  (UHACT, int, double);
extern long ustr2uf  (UHACT, int, UCHAR *);
extern long ubin2uf  (UHACT, int, UBYTE *, long);
extern long ulist2uf (UHACT, int, UHACT);
extern long uuf2char (UHACT, int, UBYTE *);
extern long uuf2int  (UHACT, int, int *);
extern long uuf2long (UHACT, int, long *);
extern long uuf2dbl  (UHACT, int, double *);
extern long uuf2str  (UHACT, int, UCHAR **);
extern long uuf2bin  (UHACT, int, UBYTE **, long *);
extern long uuf2list (UHACT, int, UHACT);

/*
 * Call out
 */

/* Parameter functions */
extern long ugetparm (UCTRL, UVOID *, int);
extern long uputparm (UCTRL, UVOID *, int);

#endif /* u_lowercase */


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* UACTDEF_H */

/* End of file uactdef.h */
