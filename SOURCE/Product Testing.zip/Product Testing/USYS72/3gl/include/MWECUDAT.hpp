/* CONT_ID %fv: mwecudat.hpp-13 % %dc: Tue Jun 16 10:41:31 1998 %"; */
/*****************************************************************************
@DOC

@COPYRIGHT
    Compuware Europe BV Copyright (c) 1997
@MODULE
    UENC
@INTERFACE

@FILE
    %name: mwecudat.hpp % - Data transfer helper class between ICC driver and C-Stub
@INMODULE
    Encina ICC driver
@OWNER
    %created_by: patrickh %
@HISTORY
      Seq. Date   RefNum  Version Who  Description 
      ------------------------------------------------------------------------
@pr     0  980112 e01599  7.2.03  jle  Initial version
@pr     0  980403 e01983  7.2.03  sse  Port to UNIX
@pr     0  980405 e01604  7.2.03  jle  Entity parameters
@pr     0  980605 e01614  7.2.03  jle  Tracing and macros
@pr     1  980615 e02310  7.2.03  PHN  Client stub changes for 3gl components
      ------------------------------------------------------------------------
      Seq. Date   RefNum  Version Who  Description 

@CHANGE_DESCR
      @pr

@END
*****************************************************************************/

#ifndef __MWECUDAT_HPP_INCLUDED__
#define __MWECUDAT_HPP_INCLUDED__

#include <dce/idlbase.h>

#ifdef _WIN32
# define UCEXPORT __declspec(dllexport)
#else
# define UCEXPORT
#endif

struct OperationVectors
{
    const char  *Name;
    const void (*Vector)(void);
};

struct ComponentVectors
{
    const char  *Name;
    const struct OperationVectors *Operations;
};

// Link to external Component to Operations vector */
extern const struct ComponentVectors unina_t_ComponentTable[];


struct UNIRESULT
{
    idl_long_int status;
    idl_long_int procError;
    idl_long_int encinaError;
};

struct UNIINSTANCE
{
    void * object;
    void * objectRef;

    UNIINSTANCE(void * newObjectRef, void * newObject)
    {
        object = newObject;
        objectRef = newObjectRef;
    }
};


#if defined(_WIN32) && defined( DEFINING_UNIENTITY)
#define UNIENTITY_LINKING __declspec(dllexport)
#else
#define UNIENTITY_LINKING
#endif

//-- Forward definition
class UNIDATA;

class UNIENTITY 
{
public:
    UNIENTITY_LINKING UNIENTITY(void * hEntity, void * callback);
    UNIENTITY_LINKING ~UNIENTITY();
    UNIENTITY_LINKING long numOcc();
    UNIENTITY_LINKING void getEntityData(long occNum, UNIDATA unidata[]);
    UNIENTITY_LINKING void putEntityData(long occNum, UNIDATA unidata[]);

private:
    void * m_hEntity;
    void * m_callback;
    void * m_convertor;
};

class UNIDATA
{
public:
    UNIDATA();
    ~UNIDATA();

    enum UNIDATATYPE { UD_NODATA, UD_CHAR,   UD_STRING,  UD_SHORT, UD_LONG,
		               UD_FLOAT,  UD_DOUBLE, UD_BOOLEAN, UD_BINARY, UD_ENTITY };

    UNIDATATYPE type;

    typedef struct {
		idl_long_int size;
		idl_byte     data[1];
	} binary;

    void typeCheck(UNIDATATYPE requestedType);

    void              setString(idl_char * string = NULL, idl_long_int size = 0);
    void              inheritString(idl_char * string);
	idl_char *        getString();
	idl_char **       getStringRef();
	idl_char *        orphanString();
    
    void              setChar(idl_char c = '\0');
	idl_char          getChar();
	idl_char *        getCharRef();
	
    void              setBool(idl_boolean b = false);
	idl_boolean       getBool();
    idl_boolean *     getBoolRef();
    
    void              setShort(idl_short_int s = 0);
	idl_short_int     getShort();
	idl_short_int *   getShortRef();
    
    void              setLong(idl_long_int l = 0);
	idl_long_int      getLong();
	idl_long_int *    getLongRef();
	
    void              setDouble(idl_long_float d = 0);
	idl_long_float    getDouble();
	idl_long_float *  getDoubleRef();
	
    void              setFloat(idl_short_float f = 0);
	idl_short_float   getFloat();
	idl_short_float * getFloatRef();
	
    void              setBinary(idl_long_int dataSize = 0,
                                idl_byte *   data     = NULL,
                                idl_long_int bufSize  = 0);  // @pr1
    void              inheritBinary(binary * newBinary);
	void              getBinary(idl_byte ** data, idl_long_int * size);
    binary *          getBinary();
    binary **         getBinaryRef();
    binary *          orphanBinary();
    idl_byte *        getBinaryData();  // @pr1

    void              setEntity(UNIENTITY * entity);
    UNIENTITY *       getEntity();

private:
    union
    {
        idl_char        c;
        idl_char *      str;
        idl_short_int   s;
        idl_long_int    l;
        idl_short_float f;
        idl_long_float  d;
		idl_boolean     b;
        binary *        bin;
        UNIENTITY *     e;
    } value;
};

//-- Include the implementations which nobody is allowed to see (hahaha)
#include "mwecudat.inl"

//-- Macro's used for entry point name generation of client stubs.
#ifdef UNINA_SERVERCLIENT
#define UNINA_PREFIX(name) unina_s_##name
#else
#define UNINA_PREFIX(name) unina_c_##name
#endif

//-- Trace object to access the UNIFACE tracing system
#define ENCINA_ICC_TRACECAT   'V'

#if defined(_WIN32) && defined( DEFINING_UNITRACER)
#define UNITRACER_LINKING __declspec(dllexport)
#else
#define UNITRACER_LINKING
#endif

class UNITRACER
{
public:
    UNITRACER(void * initData, unsigned char category = ENCINA_ICC_TRACECAT, long bufferSize = 2048);
    ~UNITRACER();

    UNITRACER_LINKING void traceEnter(char * format, ...);
    UNITRACER_LINKING void traceExit(char * format, ...);
    UNITRACER_LINKING void traceInfo(char * format, ...);
    UNITRACER_LINKING void traceWarning(char * format, ...);
    UNITRACER_LINKING void traceError(char * format, ...);
    UNITRACER_LINKING void traceFatal(char * format, ...);

private:
    void trace(int level, char * textBuffer);

    char * textBuffer;
    void * unibas;
    unsigned char traceCategory;
};

#endif // __MWECUDAT_HPP_INCLUDED__
