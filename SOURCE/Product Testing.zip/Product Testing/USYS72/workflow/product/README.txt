Table of contents:

1. INTRODUCTION
2. REQUIRED SOFTWARE
3. INSTALLATION
4. MAPPING OF SUPPORTED FILENET WORKFLO FUNCTIONS
5. UNSUPPORTED FILENET WORKFLO FUNCTIONS


1. INTRODUCTION

In UNIFACE 7.2.03, Compuware introduces the first phase of its WorkFlow 
Integration strategy. This provides support for the FileNet Workflow product
from FileNet Corporation. Access to FileNet is gained by making use of their
Panagon Visual Workflo product and the corresponding Visual Workflos API 
(VWAPI DLL).

The UNIFACE Workflow Integration is implemented using the UNIFACE call-out 
mechanism (the ability to call a service from a UNIFACE form via the activate
statement). The UNIFACE Workflow Integration provides signatures for functions
from FileNet's VWAPI DLL. Some of the API functions (listed in section 5) are
not implemented due to restrictions in the Call-Out interface. Functions which
use pointers, Static and/or Variable length arrays are not supported.

Signatures have descriptions, generic comments, comments per operation and
keywords. This allows for easy access and browsing through supported operations
by the UNIFACE Workflow Integration product. For reasons of convenience, all
operations are divided into meaningful components such as queue and data management, 
error handling, etc. making it possible to quickly identify the required operation. 
An overview of the mapping from the UNIFACE operation to the physical Visual Workflo
API function is listed below in section 4.


2. REQUIRED SOFTWARE

- Windows 95 or NT4
- UNIFACE 7.2.03
- FileNet Visual Workflo version 2.0
  (Should Contain: FileNet VWAPI.DLL 
    		   Information:
    		   Version 1, 0, 0, 1
		   Modified: Tuesday, December 03, 1996 5:15:00 PM
		   Size: 154,112 bytes)


3. INSTALLATION

To install the UNIFACE FileNet Workflow Integration product perform
the following steps:

-1) add the following demandload to the usys.ini in the Uniface bin
   directory or append it to your existing entry.

   demandload: [dir]\FileNet\VWorkflo\vwapi.dll
   
   Where [dir] is equal to the drive and or directory where the 
   the FileNet software is installed.

-2) start Uniface Development (IDF)
   go to Utilities-Import
   import  wfifnsig.trx
   close

After installation, the Subsystem FN_SIGNATURES will be available in
the Assembly Workbench. FN_SIGNATURES contains the following 3GL
components:
FN_DATA
FN_ERROR
FN_LOGGING
FN_LOGON
FN_QUEUE
FN_WOBACCESS
FN_WOBCREAT
FN_WOBINFO
FN_WOBLOC


4. MAPPING OF SUPPORTED FILENET FUNCTIONS

Each FN_SIGNATURES component consists of several operations. The tables below
show the mapping from the UNIFACE operations to the physical FileNet VWAPI 
functions.

FN_DATA:
	GETBOOLEAN		VW_GetBoolean
	GETDATATYPE		VW_GetDataType
	GETFLOAT		VW_GetFloat
	GETINTEGER		VW_GetInteger
	GETSTRING		VW_GetString
	GETSTRINGSIZE*		VW_GetStringSize
	GETTIME			VW_GetTime
	SETBOOLEAN		VW_SetBoolean
	SETFLOAT		VW_SetFloat
	SETINTEGER		VW_SetInteger
	SETSTRING		VW_SetString
	SETTIME			VW_SetTime

FN_ERROR:
	CHECKVERSION		VW_CheckVersionCompatibility
	GETERRORMSG		VW_GetErrorMessage
	GETERRORMSGSIZE*	VW_GetErrorMessageSize
	RAISEEXCEPTION		VW_RaiseException
	TERMINATEWORKOBJ	VW_TerminateWorkObject

FN_LOGGING:
	GETLOGGINGSTATE		VW_GetLoggingState
	LOGMESSAGE		VW_LogMessage
	SETLOGGINGSTATE		VW_SetLoggingState

FN_LOGON:
	LOGOFF			VW_Logoff
	LOGON			VW_Logon

FN_QUEUE:
	ATTACHTOWQ		VW_AttachToWorkQueue
	BEGINBROWSEWQ		VW_BeginBrowsingWorkQueue
	CREATEBROWSEMOD		VW_BrmCreateBrowseModifier
	DETACHFROMWQ		VW_DetachFromWorkQueue
	ENDBROWSEWQ		VW_EndBrowsingWorkQueue
	FREEBROWSEMOD		VW_BrmFreeBrowseModifier
	LEAVEWORK		VW_LeaveWork
	LOCKWORKOBJ		VW_LockWorkObject
	NEXTWORKOBJ		VW_NextWorkObjectToBrowse
	REPORTTOWORK		VW_ReportToWork
	SETPRESELECTRULE	VW_BrmSetPreSelectRule
	SETSELECTRULE		VW_BrmSetSelectRule
	UNLOCKDISPATCH		VW_UnlockAndDispatch
	UNLOCKWORKOBJ		VW_UnlockWorkObject

FN_WOBACCESS:
	FREEACCESSHANDLE	VW_FreeAccessHandle
	GETACCESSHANDLE		VW_GetAccessHandle
	QUERYACCHANDLE		VW_WobQueryGetAccessHandle

FN_WOBCREAT:
	CREATEWORKOBJ		VW_CreateWorkObject
	DISPATCHWORKOBJ		VW_DispatchWorkObject

FN_WOBINFO:
	GETOPERNAME		VW_GetOperationName
	GETOPERNAMESIZE*	VW_GetOperationNameSize
	GETWORKPERFORMER	VW_GetWorkPerformerHandle

FN_WOBLOC:
	QUERYCREATE		VW_WobQueryCreate
	QUERYEND		VW_WobQueryEnd
	QUERYEXEC		VW_WobQueryExecute
	QUERYINSTRSHEET		VW_WobQueryInstrSheet
	QUERYOPER		VW_WobQueryOperation
	QUERYWORKPERF		VW_WobQueryWorkPerformerClass

*These functions return the size of a string, which, according
 to the Visual Workflo 2.0 documentation should be used to
 allocate memory for getting the string itself. Due to limitations
 of the current UNIFACE mechanism, the size of memory for getting
 these strings is fixed. Should you require to support strings
 longer than 256 bytes the definitions of these operations in
 the signatures require to be modified. Please refer to the UNIFACE
 documentation for information on how to change the definition of
 an operation.

5. UNSUPPORTED FILENET WORKFLO FUNCTIONS

UNIFACE supports simple data types such as Numeric or String and does not 
support pointers and arrays. The following FileNet API functions are therefore
not supported:

VW_BrmSetSortRules
VW_CurrentException
VW_GetArrayPtr
VW_SetArrayPtr
VW_FreeArrayPtr
VW_GetArraySize
VW_GetDataTypeArray
VW_GetFPNumber
VW_SetFPNumber
VW_SetFieldNames

END OF README FILE.