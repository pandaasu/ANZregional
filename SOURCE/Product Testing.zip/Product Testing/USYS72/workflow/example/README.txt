Table of contents:

1. INTRODUCTION
2. INSTALLATION
3. AUTO CLAIM DEMO
4. FileNet WORKFLOW SERVICE MAPPING

1. INTRODUCTION:

A UNIFACE example application is included in the UNIFACE FileNet Workflow 
Integration product. It demonstrates how the FileNet WorkFlo API can be addressed
via a UNIFACE application. The example application is equivalent to the Autoclaim
example which is shipped with FileNet's Visual Workflo product. The Autoclaim
application consists of three forms which are used in different stages of
processing a car insurance claim.  Please refer to the autoclms.doc in the FileNet
installation for further information the example application. A UNIFACE form 
(FNVWAPI.FRM) can be found in the example directory. This form provides guidance
how to create an abstraction level between your UNIFACE application and the 
FileNet workflow system.


2. INSTALLATION

To install the UNIFACE FileNet
Workflow Integration product perform the following steps:

-1) add the following demandload to the usys.ini in the Uniface bin
   directory or append it to your existing entry.

   demandload: [dir]\FileNet\VWorkflo\vwapi.dll
   
   Where [dir] is equal to the drive and or directory where the 
   the FileNet software is installed.

-2) add the following to the [SETTINGS] section of the asn file
   (usys.asn in the usys directory or local asn file in 
    your project directory)
   $variation = XJVWAPI
   $search_descriptor=dbms_first

-3) start Uniface Development (IDF)
   go to Utilities-Import
   import  wfifngen.exp
           wfifnex.exp
           wfifnsig.trx (From the product directory)
   close

-4) compile all via the command line of IDF
   (start IDF
    in the command line type: /all
    enter)

-5) in the shortcut to Uniface Deployment
   (go to Properties-Shortcut- Target)
   add the name of the 
   startupshell: FNVW 

-6) start Uniface Deployment


3. AUTO CLAIM DEMO

The UNIFACE forms have been designed to provide the same functionality as the 
FileNet Visual Basic (Autoclaim) application. The compiled Visual Basic program 
and sources can be found in the autoclms directory of Visual Workflo. 

Below is a list of UNIFACE forms and their equivalent in Visual Basic:

- FNVWAUTO.FRM, has the visual basic equivalent AUTOCLM.EXE. This form allows the 
  insurance agent to enter the claim data. This results in a work object being 
  created and a work object being added into the FileNet Workflow system.

- FNVWBASK.FRM, has the visual basic equivalent AJDINBSK.EXE. This form represents
  the adjustor inbasket. This form allows the adjustor to assign new claims to a 
  field estimator to review damages and to a medical reviewer to assess medical
  expenses if the claim involves an injury.

- FNVWADJR.FRM, has the visual basic equivalent ADJRVW.exe. This form allows the
  adjustor to review the materials provided by the field estimator and medical
  reviewer. The adjustor determines if the claim can be settled with this 
  information or if there is an exceptional case which needs supervisor review.

The following two Visual Basic forms are not implemented in the UNIFACE version
of the example Autoclaim application:

- UNATTEND.exe (Unattended Operations)
- MFWP.exe     (MAINFRAMEWP)	


4. FileNet WORKFLOW SERVICE MAPPING

The Filenet Service (FNVWAPI.FRM) is shipped as a form for debug reasons. This
form allows the workflow engine to send messages to this form. In a development
scenario this can be an aid in debugging your application. After development is
completed the form can be translated into a UNIFACE service. It provides standard
error handling (via include procs) for both the UNIFACE inter-component 
communication and the VWAPI errors.

Interface as offered by FNVWAPI.FRM:

StartSession
  In: WorkQueueName
  VW_CheckVersionCompatibility
  VW_Logon
  VW_AttachToWorkQueue
  VW_ReportToWork

This function does the following:
- checks the version of the APIs being used is compatible with the currently
  running version of the APIs
- logs on and saves the logon Id
- establishes a Work Queue for an active Work Performer
- establishes the caller as an active Work Performer

EndSession
calls:
  VW_EndBrowseQueue
  VW_LeaveWork
  VW_DetachFromWorkQueue
  VW_Logoff
This function does the following:
- releases any resources pertaining to browsing information
- closes the active work performer
- releases the work queue
- logs off from the system.

GetLogonId
  OUT: LogonId
This function returns the current Logon ID

GetWpId
  OUT: WorkPerformerId
This function returns the current Work performer ID

GetWqId
  OUT: WorkQueueId
This function returns the current Work queue ID

BeginTask
  IN: WorkObjectId
calls:
  VW_LockWorkObject
This function locks a Work Object (identified by WorkObjectId) in a
browse queue.

CompleteTask
  IN: lockid
calls:
  VW_UnlockAndDispatch
This function does the following:
- unlocks the Work Object identified by lockId
- dispatches the Work Object to the next Work Queue indicated by its 
  Instruction Sheet.

CancelTask
  IN: lockid
This function unlocks the Work Object identified by lockid. The work
object remains in the current work queue.

BindToUser
  IN: WorkObjectId
  IN: UserName
calls:
  VW_GetAccessHandle
  VW_BindToUser
  VW_FreeAccesshandle
This function restricts processing of the Work Object to the user specified
by the User Name.

CreateWorkObj
  IN: WorkClassName
calls:
  VW_CreateWorkObject
This function creates a Work Object of the Work Class specified by
WorkClassName using the initial field values set during Work Class
definition.


BeginBrowseWQ
  OUT: BrowseId
  IN:  MaximumWorkObjectCount
  OUT: WorkObjectCount
  IN:  BrowseHandle
calls:
  VW_BeginBrowsingWorkQueue
This function establishes a browse session of the Work Queue associated with
the current work performer. The browse handle may be set to zero for default
browsing, or obtained via a call to "FN_QUEUE".CreateBrowseMod.


EndBrowseWQ
  IN:  BrowseId
calls:
  VW_EndBrowsingWorkQueue
This function releases and invalidates all resources allocated to the browse
session identified by BrowseId, or any Work Object Id's associated with it.


GetVariable
  IN: handle
  IN: variableName
  INOUT: value
calls:
  VW_GetDataType
  VW_GetInteger
  VW_GetFloat
  VW_GetString
  VW_GetBoolean
  VW_GetTime
This function gets the value of the variable identified by variableName. The
supplied handle can be the related work performer id.


SetVariable
  IN: handle
  IN: variableName
  INOUT: value
calls:
  VW_GetDataType
  VW_SetInteger
  VW_SetFloat
  VW_SetString
  VW_SetBoolean
  VW_SetTime
This function sets the variable identified by variableName to value. The 
supplied handle can be the related work performer id.

END OF README FILE.
