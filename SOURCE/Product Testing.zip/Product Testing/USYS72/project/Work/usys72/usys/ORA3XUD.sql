Rem
Rem   Description
Rem   -----------
Rem   Action                    : Drop DBMS referential integrity controls
Rem   Application Model         : UVCS
Rem   DBMS Version              : Oracle 7.3
Rem   Uniface Driver Version    : U3.3
Rem   Uniface Version           : UNIFACE 7.2 and above
Rem   Required User Option      : DF
Rem   File Version              : %U%
Rem   File Name                 : ora3xud.sql
Rem
Rem   Application model UVCS
Rem   ----------------------
Rem   The entities of the application model UVCS contain information needed for
Rem   version control of applications. The Application Development System
Rem   maintains the information stored in the entities of UVCS. It locates the
Rem   associated tables or files on the path $IDF.
Rem
Rem   Copyright (c) 1996, Compuware Europe B.V.
Rem

ALTER TABLE "OUVAPPL"
  DROP CONSTRAINT "OUVAPPL"
/

ALTER TABLE "OUVASCI"
  DROP CONSTRAINT "OUVASCI"
/

ALTER TABLE "OUVCFIEL"
  DROP CONSTRAINT "OUVCFIEL"
/

ALTER TABLE "OUVCGROU"
  DROP CONSTRAINT "OUVCGROU"
/

ALTER TABLE "OUVCKEY"
  DROP CONSTRAINT "OUVCKEY"
/

ALTER TABLE "OUVCRELS"
  DROP CONSTRAINT "OUVCRELS"
/

ALTER TABLE "OUVCSCH"
  DROP CONSTRAINT "OUVCSCH"
/

ALTER TABLE "OUVCSDIA"
  DROP CONSTRAINT "OUVCSDIA"
/

ALTER TABLE "OUVCTABL"
  DROP CONSTRAINT "OUVCTABL"
/

ALTER TABLE "UVELMLS"
  DROP CONSTRAINT "U_UVELMT_UVELMLS_UVCS"
  DROP CONSTRAINT "U_UVSYSLS_UVELMLS_UVCS"
  DROP CONSTRAINT "U_UVVERS_UVELMLS_UVCS"
/

ALTER TABLE "OUVFORM"
  DROP CONSTRAINT "OUVFORM"
/

ALTER TABLE "OUVGFIF"
  DROP CONSTRAINT "OUVGFIF"
/

ALTER TABLE "OUVGFLAY"
  DROP CONSTRAINT "OUVGFLAY"
/

ALTER TABLE "OUVGFSYN"
  DROP CONSTRAINT "OUVGFSYN"
/

ALTER TABLE "OUVGGIF"
  DROP CONSTRAINT "OUVGGIF"
/

ALTER TABLE "OUVGLYPH"
  DROP CONSTRAINT "OUVGLYPH"
/

ALTER TABLE "OUVGREGS"
  DROP CONSTRAINT "OUVGREGS"
/

ALTER TABLE "OUVSITEM"
  DROP CONSTRAINT "OUVSITEM"
/

ALTER TABLE "OUVSMENU"
  DROP CONSTRAINT "OUVSMENU"
/

ALTER TABLE "OUVSOURC"
  DROP CONSTRAINT "OUVSOURC"
/

ALTER TABLE "OUVSYSLS"
  DROP CONSTRAINT "OUVSYSLS"
/

ALTER TABLE "OUVTPLFL"
  DROP CONSTRAINT "OUVTPLFL"
/

ALTER TABLE "UVVERS"
  DROP CONSTRAINT "U_UVELMT_UVVERS_UVCS"
/

ALTER TABLE "OUVVERS"
  DROP CONSTRAINT "OUVVERS"
/

ALTER TABLE "OUVXFIEL"
  DROP CONSTRAINT "OUVXFIEL"
/

ALTER TABLE "OUVXGROU"
  DROP CONSTRAINT "OUVXGROU"
/

ALTER TABLE "OUVXREGS"
  DROP CONSTRAINT "OUVXREGS"
/

ALTER TABLE "OUVSUBS"
  DROP CONSTRAINT "OUVSUBS"
/

