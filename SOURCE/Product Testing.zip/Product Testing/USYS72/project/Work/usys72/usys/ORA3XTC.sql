rem @(#)CONT_ID %fv: % %dc: % (#)@
Rem
Rem   Description
Rem   -----------
Rem   Action                    : Create DBMS referential integrity controls
Rem   Application Model         : TEXT
Rem   DBMS Version              : Oracle 7.1 or 7.2
Rem   Uniface Driver Version    : U3.1
Rem   Uniface Version           : UNIFACE 7.1 and above
Rem   Required User Option      : DF
Rem   File Version              : %U%
Rem   File Name                 : ora3xtc.sql
Rem
Rem   Application model TEXT
Rem   ----------------------
Rem   The entities of the application model TEXT contain information which is
Rem   accessed at run-time by all UNIFACE applications. These entities are
Rem   located on the path $UUU.
Rem
Rem   The Application Development System is responsible for maintaining the
Rem   information stored in the entities of the application model TEXT.
Rem
Rem   Copyright (c) 1995, Uniface B.V.
Rem

ALTER TABLE "OUOBJ"
  ADD ( CONSTRAINT "OUOBJ" FOREIGN KEY (
	"UCSUB",
	"UCLABEL",
	"UCVAR",
	"UCTYPE",
	"UCLASS" )
  REFERENCES "UOBJ" (
	"UCSUB",
	"UCLABEL",
	"UCVAR",
	"UCTYPE",
	"UCLASS" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSYSANA"
  ADD ( CONSTRAINT "OUSYSANA" FOREIGN KEY (
	"U_VLAB",
	"U_GLAB",
	"U_VAR" )
  REFERENCES "USYSANA" (
	"U_VLAB",
	"U_GLAB",
	"U_VAR" )
  ON DELETE CASCADE )
/

