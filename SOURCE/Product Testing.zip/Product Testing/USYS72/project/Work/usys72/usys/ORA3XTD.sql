rem @(#)CONT_ID %fv: % %dc: % (#)@
Rem
Rem   Description
Rem   -----------
Rem   Action                    : Drop DBMS referential integrity controls
Rem   Application Model         : TEXT
Rem   DBMS Version              : Oracle 7.1 or 7.2
Rem   Uniface Driver Version    : U3.1
Rem   Uniface Version           : UNIFACE 7.1 and above
Rem   Required User Option      : DF
Rem   File Version              : %U%
Rem   File Name                 : ora3xtd.sql
Rem
Rem   Application model TEXT
Rem   ----------------------
Rem   The entities of the application model TEXT contain information which is
Rem   accessed at run-time by all UNIFACE applications. These entities are
Rem   located on the path $UUU.
Rem
Rem   The Application Development System is responsible for maintaining the
Rem   information stored in the entities of the application model TEXT.
Rem
Rem   Copyright (c) 1995, Uniface B.V.
Rem

ALTER TABLE "OUOBJ"
  DROP CONSTRAINT "OUOBJ"
/

ALTER TABLE "OUSYSANA"
  DROP CONSTRAINT "OUSYSANA"
/

