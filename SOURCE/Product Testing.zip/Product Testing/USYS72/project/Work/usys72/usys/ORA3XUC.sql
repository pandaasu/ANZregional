Rem
Rem   Description
Rem   -----------
Rem   Action                    : Create DBMS referential integrity controls
Rem   Application Model         : UVCS
Rem   DBMS Version              : Oracle 7.3
Rem   Uniface Driver Version    : U3.3
Rem   Uniface Version           : UNIFACE 7.2 and above
Rem   Required User Option      : DF
Rem   File Version              : %U%
Rem   File Name                 : ora3xuc.sql
Rem
Rem   Application model UVCS
Rem   ----------------------
Rem   The entities of the application model UVCS contain information needed for
Rem   version control of applications. The Application Development System
Rem   maintains the information stored in the entities of UVCS. It locates the
Rem   associated tables or files on the path $IDF.
Rem
Rem   Copyright (c) 1996, Compuware Europe B.V.
Rem

ALTER TABLE "OUVAPPL"
  ADD ( CONSTRAINT "OUVAPPL" FOREIGN KEY (
        "UVERS",
        "ULABEL" )
  REFERENCES "UVAPPL" ( 
        "UVERS",
        "ULABEL" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVASCI"
  ADD ( CONSTRAINT "OUVASCI" FOREIGN KEY (
        "UVERS",
        "ULABEL" )
  REFERENCES "UVASCI" ( 
        "UVERS",
        "ULABEL" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVCFIEL"
  ADD ( CONSTRAINT "OUVCFIEL" FOREIGN KEY (
        "UVERS",
        "U_VLAB",
        "U_TLAB",
        "U_FLAB" )
  REFERENCES "UVCFIEL" ( 
        "UVERS",
        "U_VLAB",
        "U_TLAB",
        "U_FLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVCGROU"
  ADD ( CONSTRAINT "OUVCGROU" FOREIGN KEY (
        "UVERS",
        "U_VLAB",
        "U_GLAB" )
  REFERENCES "UVCGROU" ( 
        "UVERS",
        "U_VLAB",
        "U_GLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVCKEY"
  ADD ( CONSTRAINT "OUVCKEY" FOREIGN KEY (
        "UVERS",
        "U_VLAB",
        "U_TLAB",
        "U_KSEQ" )
  REFERENCES "UVCKEY" ( 
        "UVERS",
        "U_VLAB",
        "U_TLAB",
        "U_KSEQ" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVCRELS"
  ADD ( CONSTRAINT "OUVCRELS" FOREIGN KEY (
        "UVERS",
        "U_VLAB",
        "U_GLAB",
        "U_RGLAB" )
  REFERENCES "UVCRELS" ( 
        "UVERS",
        "U_VLAB",
        "U_GLAB",
        "U_RGLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVCSCH"
  ADD ( CONSTRAINT "OUVCSCH" FOREIGN KEY (
        "UVERS",
        "U_VLAB" )
  REFERENCES "UVCSCH" ( 
        "UVERS",
        "U_VLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVCSDIA"
  ADD ( CONSTRAINT "OUVCSDIA" FOREIGN KEY (
        "UVERS",
        "U_VLAB" )
  REFERENCES "UVCSDIA" ( 
        "UVERS",
        "U_VLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVCTABL"
  ADD ( CONSTRAINT "OUVCTABL" FOREIGN KEY (
        "UVERS",
        "U_VLAB",
        "U_TLAB" )
  REFERENCES "UVCTABL" ( 
        "UVERS",
        "U_VLAB",
        "U_TLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "UVELMLS"
  ADD ( CONSTRAINT "U_UVELMT_UVELMLS_UVCS" FOREIGN KEY (
        "UTYPE",
        "ULABEL",
        "UBRANCH" )
  REFERENCES "UVELMT" ( 
        "UTYPE",
        "ULABEL",
        "UBRANCH" ) )
  ADD ( CONSTRAINT "U_UVSYSLS_UVELMLS_UVCS" FOREIGN KEY (
        "UVLISTNAME",
        "UVBRANCH",
        "UVVERSION" )
  REFERENCES "UVSYSLS" ( 
        "UVLISTNAME",
        "UVBRANCH",
        "UVVERSION" ) )
  ADD ( CONSTRAINT "U_UVVERS_UVELMLS_UVCS" FOREIGN KEY (
        "UTYPE",
        "ULABEL",
        "UBRANCH",
        "UVERSION" )
  REFERENCES "UVVERS" ( 
        "UTYPE",
        "ULABEL",
        "UBRANCH",
        "UVERSION" ) )
/

ALTER TABLE "OUVFORM"
  ADD ( CONSTRAINT "OUVFORM" FOREIGN KEY (
        "UVERS",
        "ULABEL" )
  REFERENCES "UVFORM" ( 
        "UVERS",
        "ULABEL" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVGFIF"
  ADD ( CONSTRAINT "OUVGFIF" FOREIGN KEY (
        "UVERS",
        "U_MLAB" )
  REFERENCES "UVGFIF" ( 
        "UVERS",
        "U_MLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVGFLAY"
  ADD ( CONSTRAINT "OUVGFLAY" FOREIGN KEY (
        "UVERS",
        "U_MLAB" )
  REFERENCES "UVGFLAY" ( 
        "UVERS",
        "U_MLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVGFSYN"
  ADD ( CONSTRAINT "OUVGFSYN" FOREIGN KEY (
        "UVERS",
        "U_MLAB" )
  REFERENCES "UVGFSYN" ( 
        "UVERS",
        "U_MLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVGGIF"
  ADD ( CONSTRAINT "OUVGGIF" FOREIGN KEY (
        "UVERS",
        "U_MLAB" )
  REFERENCES "UVGGIF" ( 
        "UVERS",
        "U_MLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVGLYPH"
  ADD ( CONSTRAINT "OUVGLYPH" FOREIGN KEY (
        "UVERS",
        "UCSUB",
        "UCVAR",
        "UCTYPE",
        "UCLABEL",
        "UCLASS" )
  REFERENCES "UVGLYPH" ( 
        "UVERS",
        "UCSUB",
        "UCVAR",
        "UCTYPE",
        "UCLABEL",
        "UCLASS" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVGREGS"
  ADD ( CONSTRAINT "OUVGREGS" FOREIGN KEY (
        "UVERS",
        "U_FORMLIB",
        "U_NAME" )
  REFERENCES "UVGREGS" ( 
        "UVERS",
        "U_FORMLIB",
        "U_NAME" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVSITEM"
  ADD ( CONSTRAINT "OUVSITEM" FOREIGN KEY (
        "UVERS",
        "UVAR",
        "ULAN",
        "UMENU",
        "UTECHSEQ" )
  REFERENCES "UVSITEM" ( 
        "UVERS",
        "UVAR",
        "ULAN",
        "UMENU",
        "UTECHSEQ" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVSMENU"
  ADD ( CONSTRAINT "OUVSMENU" FOREIGN KEY (
        "UVERS",
        "UVAR",
        "ULAN",
        "UMENU" )
  REFERENCES "UVSMENU" ( 
        "UVERS",
        "UVAR",
        "ULAN",
        "UMENU" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVSOURC"
  ADD ( CONSTRAINT "OUVSOURC" FOREIGN KEY (
        "UVERS",
        "USUB",
        "UVAR",
        "ULAN",
        "ULABEL" )
  REFERENCES "UVSOURC" ( 
        "UVERS",
        "USUB",
        "UVAR",
        "ULAN",
        "ULABEL" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVSYSLS"
  ADD ( CONSTRAINT "OUVSYSLS" FOREIGN KEY (
        "UVLISTNAME",
        "UVBRANCH",
        "UVVERSION" )
  REFERENCES "UVSYSLS" ( 
        "UVLISTNAME",
        "UVBRANCH",
        "UVVERSION" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVTPLFL"
  ADD ( CONSTRAINT "OUVTPLFL" FOREIGN KEY (
        "UVERS",
        "TEMPLATENAME" )
  REFERENCES "UVTPLFL" ( 
        "UVERS",
        "TEMPLATENAME" )
  ON DELETE CASCADE )
/

ALTER TABLE "UVVERS"
  ADD ( CONSTRAINT "U_UVELMT_UVVERS_UVCS" FOREIGN KEY (
        "UTYPE",
        "ULABEL",
        "UBRANCH" )
  REFERENCES "UVELMT" ( 
        "UTYPE",
        "ULABEL",
        "UBRANCH" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVVERS"
  ADD ( CONSTRAINT "OUVVERS" FOREIGN KEY (
        "UTYPE",
        "ULABEL",
        "UBRANCH",
        "UVERSION" )
  REFERENCES "UVVERS" ( 
        "UTYPE",
        "ULABEL",
        "UBRANCH",
        "UVERSION" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVXFIEL"
  ADD ( CONSTRAINT "OUVXFIEL" FOREIGN KEY (
        "UVERS",
        "UFORM",
        "TECHBASE",
        "GRP",
        "ULABEL" )
  REFERENCES "UVXFIEL" ( 
        "UVERS",
        "UFORM",
        "TECHBASE",
        "GRP",
        "ULABEL" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVXGROU"
  ADD ( CONSTRAINT "OUVXGROU" FOREIGN KEY (
        "UVERS",
        "UFORM",
        "UBASE",
        "ULABEL" )
  REFERENCES "UVXGROU" ( 
        "UVERS",
        "UFORM",
        "UBASE",
        "ULABEL" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVXREGS"
  ADD ( CONSTRAINT "OUVXREGS" FOREIGN KEY (
        "UVERS",
        "U_FORMLIB",
        "U_NAME" )
  REFERENCES "UVXREGS" ( 
        "UVERS",
        "U_FORMLIB",
        "U_NAME" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUVSUBS"
  ADD ( CONSTRAINT "OUVSUBS" FOREIGN KEY (
        "USUBSYSTEM" )
  REFERENCES "UVSUBS" ( 
        "USUBSYSTEM" )
  ON DELETE CASCADE )
/

