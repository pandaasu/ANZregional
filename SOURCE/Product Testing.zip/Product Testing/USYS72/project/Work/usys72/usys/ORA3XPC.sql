rem @(#)CONT_ID %fv: % %dc: % (#)@
Rem
Rem   Description
Rem   -----------
Rem   Action                    : Create DBMS Referential integrity controls
Rem   Application Model         : PRINTER
Rem   DBMS Version              : Oracle 7.1 or 7.2
Rem   Uniface Driver Version    : U3.1
Rem   Uniface Version           : UNIFACE 7.1 and above
Rem   Required User Option      : DF
Rem   File Version              : %U%
Rem   File Name                 : ora3xpc.sql
Rem
Rem   Application model PRINTER
Rem   -------------------------
Rem   The application model PRINTER contains the single entity, PRATT. All
Rem   applications, except those which never print, access the table or file
Rem   associated with PRATT.PRINTER on the path $SYS.
Rem
Rem   Copyright (c) 1995, Uniface B.V.
Rem

ALTER TABLE "OPRATT"
  ADD ( CONSTRAINT "OPRATT" FOREIGN KEY (
	"LAYOUT" )
  REFERENCES "PRATT" (
	"LAYOUT" )
  ON DELETE CASCADE )
/

