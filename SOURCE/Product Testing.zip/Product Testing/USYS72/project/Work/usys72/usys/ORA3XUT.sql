Rem    Description
Rem    -----------
Rem    Application Model        : UVCS
Rem   DBMS Version              : Oracle 7.3
Rem   Uniface Driver Version    : U3.3
Rem   Uniface Version           : UNIFACE 7.2 and above
Rem    File Version             : %U%
Rem
Rem    Application model UVCS
Rem    ----------------------
Rem    The entities of the application model UVCS contain information needed for
Rem    version control of applications. The Application Development System
Rem    maintains the information stored in the entities of UVCS. It locates the
Rem    associated tables or files on the path $IDF.
Rem
Rem    Copyright (c) 1996 Compuware Europe B.V.

CREATE TABLE "UVAPLFR"(
        "ULABEL"                            CHAR(16),
        "UFORM"                             CHAR(16),
        "UVERS"                             CHAR(12),
  CONSTRAINT "UVAPLFRP1" PRIMARY KEY(
        "UVERS",
        "ULABEL",
        "UFORM" ))
/

CREATE OR REPLACE PACKAGE "UVAPLFR$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER );

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XULABEL"                           IN OUT
          "UVAPLFR"."ULABEL"%TYPE,

        "XUFORM"                            IN OUT
          "UVAPLFR"."UFORM"%TYPE,

        "XUVERS"                            IN OUT
          "UVAPLFR"."UVERS"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WUVERS"                            IN
          "UVAPLFR"."UVERS"%TYPE,

        "WULABEL"                           IN
          "UVAPLFR"."ULABEL"%TYPE,

        "WUFORM"                            IN
          "UVAPLFR"."UFORM"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER );
END "UVAPLFR$U";
/

CREATE OR REPLACE PACKAGE BODY "UVAPLFR$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER )

  IS
  BEGIN

    "PACKAGE_VERSION"."MAJOR_VERSION" := 2;
    "PACKAGE_VERSION"."MINOR_VERSION" := 2;

  END "PACKAGE_VERSION";

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XULABEL"                           IN OUT
          "UVAPLFR"."ULABEL"%TYPE,

        "XUFORM"                            IN OUT
          "UVAPLFR"."UFORM"%TYPE,

        "XUVERS"                            IN OUT
          "UVAPLFR"."UVERS"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WUVERS"                            IN
          "UVAPLFR"."UVERS"%TYPE,

        "WULABEL"                           IN
          "UVAPLFR"."ULABEL"%TYPE,

        "WUFORM"                            IN
          "UVAPLFR"."UFORM"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER )

  IS

    "DUMMY_FIELD"                       
          NUMBER;

    "NUM_FALSE"                         CONSTANT NUMBER  := 0;
    "NUM_TRUE"                          CONSTANT NUMBER  := 1;

    "SELECT_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 0;
    "SELECT_ROWIDROW_BY_PRIMARY_KEY"    CONSTANT NUMBER  := 1;
    "SELECT_ROW_BY_ROWID"               CONSTANT NUMBER  := 2;
    "CHECK_EXISTENCE_OF_PRIMARY_KEY"    CONSTANT NUMBER  := 3;
    "LOCK_ROW_BY_PRIMARY_KEY"           CONSTANT NUMBER  := 4;
    "LOCK_ROW_BY_ROWID"                 CONSTANT NUMBER  := 5;
    "DELETE_ROW_BY_ROWID"               CONSTANT NUMBER  := 6;
    "DELETE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 7;

  BEGIN

    "ONE_ROW_AFFECTED" := "NUM_TRUE";

    IF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "ULABEL",
        "UFORM",
        "UVERS"
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUFORM",
        "UNIFACE_IO"."XUVERS"
      FROM "UVAPLFR"
      WHERE 
        "UVERS" = "UNIFACE_IO"."WUVERS" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UFORM" = "UNIFACE_IO"."WUFORM";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROWIDROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "ULABEL",
        "UFORM",
        "UVERS",
        ROWID
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUFORM",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XROWID"
      FROM "UVAPLFR"
      WHERE 
        "UVERS" = "UNIFACE_IO"."WUVERS" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UFORM" = "UNIFACE_IO"."WUFORM";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_ROWID" THEN

      SELECT /*+ FIRST_ROWS */ 
        "ULABEL",
        "UFORM",
        "UVERS"
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUFORM",
        "UNIFACE_IO"."XUVERS"
      FROM "UVAPLFR"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "CHECK_EXISTENCE_OF_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 0
      INTO
        "UNIFACE_IO"."DUMMY_FIELD"
      FROM "UVAPLFR"
      WHERE 
        "UVERS" = "UNIFACE_IO"."WUVERS" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UFORM" = "UNIFACE_IO"."WUFORM";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_PRIMARY_KEY" THEN

      SELECT 
        "ULABEL",
        "UFORM",
        "UVERS",
        ROWID
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUFORM",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XROWID"
      FROM "UVAPLFR"
      WHERE 
        "UVERS" = "UNIFACE_IO"."WUVERS" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UFORM" = "UNIFACE_IO"."WUFORM"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_ROWID" THEN

      SELECT 
        "ULABEL",
        "UFORM",
        "UVERS"
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUFORM",
        "UNIFACE_IO"."XUVERS"
      FROM "UVAPLFR"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_ROWID" THEN

      DELETE FROM "UVAPLFR"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_PRIMARY_KEY" THEN

      DELETE FROM "UVAPLFR"
      WHERE 
        "UVERS" = "UNIFACE_IO"."WUVERS" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UFORM" = "UNIFACE_IO"."WUFORM";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSE

      raise_application_error( -20000, 'Unhandled UNIFACE I/O request' );

    END IF;

  EXCEPTION

    WHEN NO_DATA_FOUND THEN

      "ONE_ROW_AFFECTED" := "NUM_FALSE";

  END "UNIFACE_IO";
END "UVAPLFR$U";
/

CREATE TABLE "UVAPLLS"(
        "U_APPLNAME"                        CHAR(16),
        "U_LISTNAME"                        CHAR(16),
        "U_OBJTYPE"                         CHAR(2),
        "U_OFIELD"                          CHAR(34),
        "U_OENT"                            CHAR(32),
        "U_OVIEW"                           CHAR(32),
        "UVERS"                             CHAR(12),
        "U_MARKER"                          CHAR(1),
        "TECHVIEW"                          CHAR(16),
        "U_STAT"                            CHAR(4),
        "UTIMESTAMP"                        DATE,
  CONSTRAINT "UVAPLLSP1" PRIMARY KEY(
        "UVERS",
        "U_LISTNAME",
        "U_OBJTYPE",
        "TECHVIEW",
        "U_OENT",
        "U_OFIELD" ))
/

CREATE INDEX "UVAPLLSI2" ON "UVAPLLS"(
        "UVERS",
        "U_APPLNAME" )
/

CREATE OR REPLACE PACKAGE "UVAPLLS$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER );

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XU_APPLNAME"                       IN OUT
          "UVAPLLS"."U_APPLNAME"%TYPE,

        "XU_LISTNAME"                       IN OUT
          "UVAPLLS"."U_LISTNAME"%TYPE,

        "XU_OBJTYPE"                        IN OUT
          "UVAPLLS"."U_OBJTYPE"%TYPE,

        "XU_OFIELD"                         IN OUT
          "UVAPLLS"."U_OFIELD"%TYPE,

        "XU_OENT"                           IN OUT
          "UVAPLLS"."U_OENT"%TYPE,

        "XU_OVIEW"                          IN OUT
          "UVAPLLS"."U_OVIEW"%TYPE,

        "XUVERS"                            IN OUT
          "UVAPLLS"."UVERS"%TYPE,

        "XU_MARKER"                         IN OUT
          "UVAPLLS"."U_MARKER"%TYPE,

        "XTECHVIEW"                         IN OUT
          "UVAPLLS"."TECHVIEW"%TYPE,

        "XU_STAT"                           IN OUT
          "UVAPLLS"."U_STAT"%TYPE,

        "XUTIMESTAMP"                       IN OUT
          "UVAPLLS"."UTIMESTAMP"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WUVERS"                            IN
          "UVAPLLS"."UVERS"%TYPE,

        "WU_LISTNAME"                       IN
          "UVAPLLS"."U_LISTNAME"%TYPE,

        "WU_OBJTYPE"                        IN
          "UVAPLLS"."U_OBJTYPE"%TYPE,

        "WTECHVIEW"                         IN
          "UVAPLLS"."TECHVIEW"%TYPE,

        "WU_OENT"                           IN
          "UVAPLLS"."U_OENT"%TYPE,

        "WU_OFIELD"                         IN
          "UVAPLLS"."U_OFIELD"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER );
END "UVAPLLS$U";
/

CREATE OR REPLACE PACKAGE BODY "UVAPLLS$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER )

  IS
  BEGIN

    "PACKAGE_VERSION"."MAJOR_VERSION" := 2;
    "PACKAGE_VERSION"."MINOR_VERSION" := 2;

  END "PACKAGE_VERSION";

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XU_APPLNAME"                       IN OUT
          "UVAPLLS"."U_APPLNAME"%TYPE,

        "XU_LISTNAME"                       IN OUT
          "UVAPLLS"."U_LISTNAME"%TYPE,

        "XU_OBJTYPE"                        IN OUT
          "UVAPLLS"."U_OBJTYPE"%TYPE,

        "XU_OFIELD"                         IN OUT
          "UVAPLLS"."U_OFIELD"%TYPE,

        "XU_OENT"                           IN OUT
          "UVAPLLS"."U_OENT"%TYPE,

        "XU_OVIEW"                          IN OUT
          "UVAPLLS"."U_OVIEW"%TYPE,

        "XUVERS"                            IN OUT
          "UVAPLLS"."UVERS"%TYPE,

        "XU_MARKER"                         IN OUT
          "UVAPLLS"."U_MARKER"%TYPE,

        "XTECHVIEW"                         IN OUT
          "UVAPLLS"."TECHVIEW"%TYPE,

        "XU_STAT"                           IN OUT
          "UVAPLLS"."U_STAT"%TYPE,

        "XUTIMESTAMP"                       IN OUT
          "UVAPLLS"."UTIMESTAMP"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WUVERS"                            IN
          "UVAPLLS"."UVERS"%TYPE,

        "WU_LISTNAME"                       IN
          "UVAPLLS"."U_LISTNAME"%TYPE,

        "WU_OBJTYPE"                        IN
          "UVAPLLS"."U_OBJTYPE"%TYPE,

        "WTECHVIEW"                         IN
          "UVAPLLS"."TECHVIEW"%TYPE,

        "WU_OENT"                           IN
          "UVAPLLS"."U_OENT"%TYPE,

        "WU_OFIELD"                         IN
          "UVAPLLS"."U_OFIELD"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER )

  IS

    "DUMMY_FIELD"                       
          NUMBER;

    "NUM_FALSE"                         CONSTANT NUMBER  := 0;
    "NUM_TRUE"                          CONSTANT NUMBER  := 1;

    "SELECT_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 0;
    "SELECT_ROWIDROW_BY_PRIMARY_KEY"    CONSTANT NUMBER  := 1;
    "SELECT_ROW_BY_ROWID"               CONSTANT NUMBER  := 2;
    "CHECK_EXISTENCE_OF_PRIMARY_KEY"    CONSTANT NUMBER  := 3;
    "LOCK_ROW_BY_PRIMARY_KEY"           CONSTANT NUMBER  := 4;
    "LOCK_ROW_BY_ROWID"                 CONSTANT NUMBER  := 5;
    "DELETE_ROW_BY_ROWID"               CONSTANT NUMBER  := 6;
    "DELETE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 7;
    "UPDATE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 9;
    "UPDATE_ROW_BY_ROWID"               CONSTANT NUMBER  := 11;

  BEGIN

    "ONE_ROW_AFFECTED" := "NUM_TRUE";

    IF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "U_APPLNAME",
        "U_LISTNAME",
        "U_OBJTYPE",
        "U_OFIELD",
        "U_OENT",
        "U_OVIEW",
        "UVERS",
        "U_MARKER",
        "TECHVIEW",
        "U_STAT",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XU_APPLNAME",
        "UNIFACE_IO"."XU_LISTNAME",
        "UNIFACE_IO"."XU_OBJTYPE",
        "UNIFACE_IO"."XU_OFIELD",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XU_MARKER",
        "UNIFACE_IO"."XTECHVIEW",
        "UNIFACE_IO"."XU_STAT",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "UVAPLLS"
      WHERE 
        "UVERS" = "UNIFACE_IO"."WUVERS" AND
        "U_LISTNAME" = "UNIFACE_IO"."WU_LISTNAME" AND
        "U_OBJTYPE" = "UNIFACE_IO"."WU_OBJTYPE" AND
        "TECHVIEW" = "UNIFACE_IO"."WTECHVIEW" AND
        "U_OENT" = "UNIFACE_IO"."WU_OENT" AND
        "U_OFIELD" = "UNIFACE_IO"."WU_OFIELD";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROWIDROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "U_APPLNAME",
        "U_LISTNAME",
        "U_OBJTYPE",
        "U_OFIELD",
        "U_OENT",
        "U_OVIEW",
        "UVERS",
        "U_MARKER",
        "TECHVIEW",
        "U_STAT",
        "UTIMESTAMP",
        ROWID
      INTO
        "UNIFACE_IO"."XU_APPLNAME",
        "UNIFACE_IO"."XU_LISTNAME",
        "UNIFACE_IO"."XU_OBJTYPE",
        "UNIFACE_IO"."XU_OFIELD",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XU_MARKER",
        "UNIFACE_IO"."XTECHVIEW",
        "UNIFACE_IO"."XU_STAT",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XROWID"
      FROM "UVAPLLS"
      WHERE 
        "UVERS" = "UNIFACE_IO"."WUVERS" AND
        "U_LISTNAME" = "UNIFACE_IO"."WU_LISTNAME" AND
        "U_OBJTYPE" = "UNIFACE_IO"."WU_OBJTYPE" AND
        "TECHVIEW" = "UNIFACE_IO"."WTECHVIEW" AND
        "U_OENT" = "UNIFACE_IO"."WU_OENT" AND
        "U_OFIELD" = "UNIFACE_IO"."WU_OFIELD";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_ROWID" THEN

      SELECT /*+ FIRST_ROWS */ 
        "U_APPLNAME",
        "U_LISTNAME",
        "U_OBJTYPE",
        "U_OFIELD",
        "U_OENT",
        "U_OVIEW",
        "UVERS",
        "U_MARKER",
        "TECHVIEW",
        "U_STAT",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XU_APPLNAME",
        "UNIFACE_IO"."XU_LISTNAME",
        "UNIFACE_IO"."XU_OBJTYPE",
        "UNIFACE_IO"."XU_OFIELD",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XU_MARKER",
        "UNIFACE_IO"."XTECHVIEW",
        "UNIFACE_IO"."XU_STAT",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "UVAPLLS"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "CHECK_EXISTENCE_OF_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 0
      INTO
        "UNIFACE_IO"."DUMMY_FIELD"
      FROM "UVAPLLS"
      WHERE 
        "UVERS" = "UNIFACE_IO"."WUVERS" AND
        "U_LISTNAME" = "UNIFACE_IO"."WU_LISTNAME" AND
        "U_OBJTYPE" = "UNIFACE_IO"."WU_OBJTYPE" AND
        "TECHVIEW" = "UNIFACE_IO"."WTECHVIEW" AND
        "U_OENT" = "UNIFACE_IO"."WU_OENT" AND
        "U_OFIELD" = "UNIFACE_IO"."WU_OFIELD";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_PRIMARY_KEY" THEN

      SELECT 
        "U_APPLNAME",
        "U_LISTNAME",
        "U_OBJTYPE",
        "U_OFIELD",
        "U_OENT",
        "U_OVIEW",
        "UVERS",
        "U_MARKER",
        "TECHVIEW",
        "U_STAT",
        "UTIMESTAMP",
        ROWID
      INTO
        "UNIFACE_IO"."XU_APPLNAME",
        "UNIFACE_IO"."XU_LISTNAME",
        "UNIFACE_IO"."XU_OBJTYPE",
        "UNIFACE_IO"."XU_OFIELD",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XU_MARKER",
        "UNIFACE_IO"."XTECHVIEW",
        "UNIFACE_IO"."XU_STAT",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XROWID"
      FROM "UVAPLLS"
      WHERE 
        "UVERS" = "UNIFACE_IO"."WUVERS" AND
        "U_LISTNAME" = "UNIFACE_IO"."WU_LISTNAME" AND
        "U_OBJTYPE" = "UNIFACE_IO"."WU_OBJTYPE" AND
        "TECHVIEW" = "UNIFACE_IO"."WTECHVIEW" AND
        "U_OENT" = "UNIFACE_IO"."WU_OENT" AND
        "U_OFIELD" = "UNIFACE_IO"."WU_OFIELD"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_ROWID" THEN

      SELECT 
        "U_APPLNAME",
        "U_LISTNAME",
        "U_OBJTYPE",
        "U_OFIELD",
        "U_OENT",
        "U_OVIEW",
        "UVERS",
        "U_MARKER",
        "TECHVIEW",
        "U_STAT",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XU_APPLNAME",
        "UNIFACE_IO"."XU_LISTNAME",
        "UNIFACE_IO"."XU_OBJTYPE",
        "UNIFACE_IO"."XU_OFIELD",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XU_MARKER",
        "UNIFACE_IO"."XTECHVIEW",
        "UNIFACE_IO"."XU_STAT",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "UVAPLLS"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_ROWID" THEN

      DELETE FROM "UVAPLLS"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_PRIMARY_KEY" THEN

      DELETE FROM "UVAPLLS"
      WHERE 
        "UVERS" = "UNIFACE_IO"."WUVERS" AND
        "U_LISTNAME" = "UNIFACE_IO"."WU_LISTNAME" AND
        "U_OBJTYPE" = "UNIFACE_IO"."WU_OBJTYPE" AND
        "TECHVIEW" = "UNIFACE_IO"."WTECHVIEW" AND
        "U_OENT" = "UNIFACE_IO"."WU_OENT" AND
        "U_OFIELD" = "UNIFACE_IO"."WU_OFIELD";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_PRIMARY_KEY" THEN

      UPDATE "UVAPLLS" SET
        "U_APPLNAME" = "UNIFACE_IO"."XU_APPLNAME",
        "U_OVIEW" = "UNIFACE_IO"."XU_OVIEW",
        "U_MARKER" = "UNIFACE_IO"."XU_MARKER",
        "U_STAT" = "UNIFACE_IO"."XU_STAT",
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        "UVERS" = "UNIFACE_IO"."WUVERS" AND
        "U_LISTNAME" = "UNIFACE_IO"."WU_LISTNAME" AND
        "U_OBJTYPE" = "UNIFACE_IO"."WU_OBJTYPE" AND
        "TECHVIEW" = "UNIFACE_IO"."WTECHVIEW" AND
        "U_OENT" = "UNIFACE_IO"."WU_OENT" AND
        "U_OFIELD" = "UNIFACE_IO"."WU_OFIELD";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_ROWID" THEN

      UPDATE "UVAPLLS" SET
        "U_APPLNAME" = "UNIFACE_IO"."XU_APPLNAME",
        "U_OVIEW" = "UNIFACE_IO"."XU_OVIEW",
        "U_MARKER" = "UNIFACE_IO"."XU_MARKER",
        "U_STAT" = "UNIFACE_IO"."XU_STAT",
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSE

      raise_application_error( -20000, 'Unhandled UNIFACE I/O request' );

    END IF;

  EXCEPTION

    WHEN NO_DATA_FOUND THEN

      "ONE_ROW_AFFECTED" := "NUM_FALSE";

  END "UNIFACE_IO";
END "UVAPLLS$U";
/

CREATE TABLE "UVAPPL"(
        "UTIMESTAMP"                        DATE,
        "UCOMPSTAMP"                        DATE,
        "ULINKSTAMP"                        DATE,
        "ULABEL"                            CHAR(16),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "UKEYBOARD"                         CHAR(16),
        "UDISPLAY"                          CHAR(16),
        "HMAX"                              CHAR(6),
        "VMAX"                              CHAR(6),
        "AIOPRINT"                          NUMBER(3),
        "LIBRAR"                            CHAR(32),
        "UPANEL"                            CHAR(32),
        "SPANEL"                            CHAR(32),
        "POSPANEL"                          CHAR(1),
        "UPULL"                             CHAR(32),
        "ASS"                               LONG,
  CONSTRAINT "UVAPPLP1" PRIMARY KEY(
        "UVERS",
        "ULABEL" ))
/

CREATE TABLE "OUVAPPL"(
        "UVERS"                             CHAR(12),
        "ULABEL"                            CHAR(16),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVAPPLP1" PRIMARY KEY(
        "UVERS",
        "ULABEL",
        "SEGM" ))
/

CREATE TABLE "UVASCI"(
        "UTIMESTAMP"                        DATE,
        "ULABEL"                            CHAR(16),
        "UVERS"                             CHAR(12),
        "UTEXT"                             LONG,
  CONSTRAINT "UVASCIP1" PRIMARY KEY(
        "UVERS",
        "ULABEL" ))
/

CREATE TABLE "OUVASCI"(
        "UVERS"                             CHAR(12),
        "ULABEL"                            CHAR(16),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVASCIP1" PRIMARY KEY(
        "UVERS",
        "ULABEL",
        "SEGM" ))
/

CREATE TABLE "UVCFIEL"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_FLAB"                            CHAR(32),
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "U_FSEQ"                            NUMBER(4),
        "UDESCR"                            CHAR(25),
        "U_LEV"                             CHAR(2),
        "U_DTYP"                            CHAR(2),
        "U_INDB"                            CHAR(1),
        "TPLINTF"                           CHAR(32),
        "U_INTF"                            CHAR(64),
        "TPLSYN"                            CHAR(32),
        "U_SYN"                             CHAR(192),
        "TPLLAY"                            CHAR(32),
        "U_LAY"                             CHAR(128),
        "WIDGETTYPE"                        CHAR(16),
        "TEMPLATENAME"                      CHAR(32),
        "UINHERIT"                          CHAR(1),
        "UDEFWIDTH"                         CHAR(6),
        "UDEFDEPTH"                         CHAR(6),
        "U_DESC"                            LONG,
  CONSTRAINT "UVCFIELP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB",
        "U_TLAB",
        "U_FLAB" ))
/

CREATE TABLE "OUVCFIEL"(
        "UVERS"                             CHAR(12),
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "U_FLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVCFIELP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB",
        "U_TLAB",
        "U_FLAB",
        "SEGM" ))
/

CREATE TABLE "UVCGROU"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_GLAB"                            CHAR(32),
        "U_VLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "U_TLAB"                            CHAR(32),
        "UDESCR"                            CHAR(25),
        "U_BORD"                            CHAR(1),
        "U_INDB"                            CHAR(1),
        "U_DBMS"                            CHAR(3),
        "U_UPD"                             CHAR(1),
        "U_MINL"                            NUMBER(6),
        "U_MAXL"                            NUMBER(6),
        "U_MINR"                            NUMBER(6),
        "U_MAXR"                            NUMBER(6),
        "TPLGINTF"                          CHAR(32),
        "U_INTF"                            CHAR(64),
        "TEMPLATENAME"                      CHAR(32),
        "UINHERIT"                          CHAR(1),
        "TPLACTUAL"                         LONG,
  CONSTRAINT "UVCGROUP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB",
        "U_GLAB" ))
/

CREATE TABLE "OUVCGROU"(
        "UVERS"                             CHAR(12),
        "U_VLAB"                            CHAR(32),
        "U_GLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVCGROUP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB",
        "U_GLAB",
        "SEGM" ))
/

CREATE TABLE "UVCKEY"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "U_KSEQ"                            NUMBER(2),
        "UVERS"                             CHAR(12),
        "U_KTYP"                            CHAR(1),
        "UDESCR"                            CHAR(25),
        "U_DOC"                             LONG,
  CONSTRAINT "UVCKEYP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB",
        "U_TLAB",
        "U_KSEQ" ))
/

CREATE TABLE "OUVCKEY"(
        "UVERS"                             CHAR(12),
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "U_KSEQ"                            NUMBER(2),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVCKEYP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB",
        "U_TLAB",
        "U_KSEQ",
        "SEGM" ))
/

CREATE TABLE "UVCRELS"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_GLAB"                            CHAR(32),
        "U_VLAB"                            CHAR(32),
        "U_RGLAB"                           CHAR(32),
        "UVERS"                             CHAR(12),
        "U_RVLAB"                           CHAR(32),
        "UDESCR"                            CHAR(25),
        "U_DELC"                            CHAR(3),
        "U_UPDC"                            CHAR(3),
        "U_KSEQ"                            NUMBER(2),
        "U_FIDX"                            CHAR(1),
        "U_INTEGRITY"                       CHAR(1),
        "U_PROCEDURE"                       CHAR(32),
        "U_OPTIONAL"                        CHAR(1),
        "U_ARITY"                           NUMBER(2),
        "U_DOC"                             LONG,
  CONSTRAINT "UVCRELSP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB",
        "U_GLAB",
        "U_RGLAB" ))
/

CREATE INDEX "UVCRELSI2" ON "UVCRELS"(
        "UVERS",
        "U_RVLAB" )
/

CREATE TABLE "OUVCRELS"(
        "UVERS"                             CHAR(12),
        "U_VLAB"                            CHAR(32),
        "U_GLAB"                            CHAR(32),
        "U_RGLAB"                           CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVCRELSP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB",
        "U_GLAB",
        "U_RGLAB",
        "SEGM" ))
/

CREATE TABLE "UVCSCH"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_VLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "ICMODEL"                           CHAR(16),
        "ICDEFINED"                         CHAR(1),
        "ICDIRTY"                           CHAR(1),
        "U_DOC"                             LONG,
  CONSTRAINT "UVCSCHP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB" ))
/

CREATE TABLE "OUVCSCH"(
        "UVERS"                             CHAR(12),
        "U_VLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVCSCHP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB",
        "SEGM" ))
/

CREATE TABLE "UVCSDIA"(
        "UTIMESTAMP"                        DATE,
        "U_VLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "UDIAGRAM"                          LONG RAW,
  CONSTRAINT "UVCSDIAP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB" ))
/

CREATE TABLE "OUVCSDIA"(
        "UVERS"                             CHAR(12),
        "U_VLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG RAW,
  CONSTRAINT "OUVCSDIAP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB",
        "SEGM" ))
/

CREATE TABLE "UVCTABL"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_DOC"                             LONG,
  CONSTRAINT "UVCTABLP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB",
        "U_TLAB" ))
/

CREATE TABLE "OUVCTABL"(
        "UVERS"                             CHAR(12),
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVCTABLP1" PRIMARY KEY(
        "UVERS",
        "U_VLAB",
        "U_TLAB",
        "SEGM" ))
/

CREATE TABLE "UVELMLS"(
        "UVLISTNAME"                        CHAR(16),
        "UVVERSION"                         CHAR(9),
        "UVBRANCH"                          CHAR(3),
        "ULABEL"                            CHAR(49),
        "UTYPE"                             CHAR(4),
        "UBRANCH"                           CHAR(3),
        "UVERSION"                          CHAR(9),
        "UTIMESTAMP"                        DATE,
  CONSTRAINT "UVELMLSP1" PRIMARY KEY(
        "UVLISTNAME",
        "UVBRANCH",
        "UVVERSION",
        "UTYPE",
        "ULABEL",
        "UBRANCH" ))
/

CREATE INDEX "UVELMLSI2" ON "UVELMLS"(
        "UTYPE",
        "ULABEL",
        "UBRANCH",
        "UVERSION" )
/

CREATE OR REPLACE PACKAGE "UVELMLS$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER );

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XUVLISTNAME"                       IN OUT
          "UVELMLS"."UVLISTNAME"%TYPE,

        "XUVVERSION"                        IN OUT
          "UVELMLS"."UVVERSION"%TYPE,

        "XUVBRANCH"                         IN OUT
          "UVELMLS"."UVBRANCH"%TYPE,

        "XULABEL"                           IN OUT
          "UVELMLS"."ULABEL"%TYPE,

        "XUTYPE"                            IN OUT
          "UVELMLS"."UTYPE"%TYPE,

        "XUBRANCH"                          IN OUT
          "UVELMLS"."UBRANCH"%TYPE,

        "XUVERSION"                         IN OUT
          "UVELMLS"."UVERSION"%TYPE,

        "XUTIMESTAMP"                       IN OUT
          "UVELMLS"."UTIMESTAMP"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WUVLISTNAME"                       IN
          "UVELMLS"."UVLISTNAME"%TYPE,

        "WUVBRANCH"                         IN
          "UVELMLS"."UVBRANCH"%TYPE,

        "WUVVERSION"                        IN
          "UVELMLS"."UVVERSION"%TYPE,

        "WUTYPE"                            IN
          "UVELMLS"."UTYPE"%TYPE,

        "WULABEL"                           IN
          "UVELMLS"."ULABEL"%TYPE,

        "WUBRANCH"                          IN
          "UVELMLS"."UBRANCH"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER );
END "UVELMLS$U";
/

CREATE OR REPLACE PACKAGE BODY "UVELMLS$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER )

  IS
  BEGIN

    "PACKAGE_VERSION"."MAJOR_VERSION" := 2;
    "PACKAGE_VERSION"."MINOR_VERSION" := 2;

  END "PACKAGE_VERSION";

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XUVLISTNAME"                       IN OUT
          "UVELMLS"."UVLISTNAME"%TYPE,

        "XUVVERSION"                        IN OUT
          "UVELMLS"."UVVERSION"%TYPE,

        "XUVBRANCH"                         IN OUT
          "UVELMLS"."UVBRANCH"%TYPE,

        "XULABEL"                           IN OUT
          "UVELMLS"."ULABEL"%TYPE,

        "XUTYPE"                            IN OUT
          "UVELMLS"."UTYPE"%TYPE,

        "XUBRANCH"                          IN OUT
          "UVELMLS"."UBRANCH"%TYPE,

        "XUVERSION"                         IN OUT
          "UVELMLS"."UVERSION"%TYPE,

        "XUTIMESTAMP"                       IN OUT
          "UVELMLS"."UTIMESTAMP"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WUVLISTNAME"                       IN
          "UVELMLS"."UVLISTNAME"%TYPE,

        "WUVBRANCH"                         IN
          "UVELMLS"."UVBRANCH"%TYPE,

        "WUVVERSION"                        IN
          "UVELMLS"."UVVERSION"%TYPE,

        "WUTYPE"                            IN
          "UVELMLS"."UTYPE"%TYPE,

        "WULABEL"                           IN
          "UVELMLS"."ULABEL"%TYPE,

        "WUBRANCH"                          IN
          "UVELMLS"."UBRANCH"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER )

  IS

    "DUMMY_FIELD"                       
          NUMBER;

    "NUM_FALSE"                         CONSTANT NUMBER  := 0;
    "NUM_TRUE"                          CONSTANT NUMBER  := 1;

    "SELECT_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 0;
    "SELECT_ROWIDROW_BY_PRIMARY_KEY"    CONSTANT NUMBER  := 1;
    "SELECT_ROW_BY_ROWID"               CONSTANT NUMBER  := 2;
    "CHECK_EXISTENCE_OF_PRIMARY_KEY"    CONSTANT NUMBER  := 3;
    "LOCK_ROW_BY_PRIMARY_KEY"           CONSTANT NUMBER  := 4;
    "LOCK_ROW_BY_ROWID"                 CONSTANT NUMBER  := 5;
    "DELETE_ROW_BY_ROWID"               CONSTANT NUMBER  := 6;
    "DELETE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 7;
    "UPDATE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 9;
    "UPDATE_ROW_BY_ROWID"               CONSTANT NUMBER  := 11;

  BEGIN

    "ONE_ROW_AFFECTED" := "NUM_TRUE";

    IF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "UVLISTNAME",
        "UVVERSION",
        "UVBRANCH",
        "ULABEL",
        "UTYPE",
        "UBRANCH",
        "UVERSION",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XUVLISTNAME",
        "UNIFACE_IO"."XUVVERSION",
        "UNIFACE_IO"."XUVBRANCH",
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUTYPE",
        "UNIFACE_IO"."XUBRANCH",
        "UNIFACE_IO"."XUVERSION",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "UVELMLS"
      WHERE 
        "UVLISTNAME" = "UNIFACE_IO"."WUVLISTNAME" AND
        "UVBRANCH" = "UNIFACE_IO"."WUVBRANCH" AND
        "UVVERSION" = "UNIFACE_IO"."WUVVERSION" AND
        "UTYPE" = "UNIFACE_IO"."WUTYPE" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UBRANCH" = "UNIFACE_IO"."WUBRANCH";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROWIDROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "UVLISTNAME",
        "UVVERSION",
        "UVBRANCH",
        "ULABEL",
        "UTYPE",
        "UBRANCH",
        "UVERSION",
        "UTIMESTAMP",
        ROWID
      INTO
        "UNIFACE_IO"."XUVLISTNAME",
        "UNIFACE_IO"."XUVVERSION",
        "UNIFACE_IO"."XUVBRANCH",
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUTYPE",
        "UNIFACE_IO"."XUBRANCH",
        "UNIFACE_IO"."XUVERSION",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XROWID"
      FROM "UVELMLS"
      WHERE 
        "UVLISTNAME" = "UNIFACE_IO"."WUVLISTNAME" AND
        "UVBRANCH" = "UNIFACE_IO"."WUVBRANCH" AND
        "UVVERSION" = "UNIFACE_IO"."WUVVERSION" AND
        "UTYPE" = "UNIFACE_IO"."WUTYPE" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UBRANCH" = "UNIFACE_IO"."WUBRANCH";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_ROWID" THEN

      SELECT /*+ FIRST_ROWS */ 
        "UVLISTNAME",
        "UVVERSION",
        "UVBRANCH",
        "ULABEL",
        "UTYPE",
        "UBRANCH",
        "UVERSION",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XUVLISTNAME",
        "UNIFACE_IO"."XUVVERSION",
        "UNIFACE_IO"."XUVBRANCH",
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUTYPE",
        "UNIFACE_IO"."XUBRANCH",
        "UNIFACE_IO"."XUVERSION",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "UVELMLS"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "CHECK_EXISTENCE_OF_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 0
      INTO
        "UNIFACE_IO"."DUMMY_FIELD"
      FROM "UVELMLS"
      WHERE 
        "UVLISTNAME" = "UNIFACE_IO"."WUVLISTNAME" AND
        "UVBRANCH" = "UNIFACE_IO"."WUVBRANCH" AND
        "UVVERSION" = "UNIFACE_IO"."WUVVERSION" AND
        "UTYPE" = "UNIFACE_IO"."WUTYPE" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UBRANCH" = "UNIFACE_IO"."WUBRANCH";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_PRIMARY_KEY" THEN

      SELECT 
        "UVLISTNAME",
        "UVVERSION",
        "UVBRANCH",
        "ULABEL",
        "UTYPE",
        "UBRANCH",
        "UVERSION",
        "UTIMESTAMP",
        ROWID
      INTO
        "UNIFACE_IO"."XUVLISTNAME",
        "UNIFACE_IO"."XUVVERSION",
        "UNIFACE_IO"."XUVBRANCH",
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUTYPE",
        "UNIFACE_IO"."XUBRANCH",
        "UNIFACE_IO"."XUVERSION",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XROWID"
      FROM "UVELMLS"
      WHERE 
        "UVLISTNAME" = "UNIFACE_IO"."WUVLISTNAME" AND
        "UVBRANCH" = "UNIFACE_IO"."WUVBRANCH" AND
        "UVVERSION" = "UNIFACE_IO"."WUVVERSION" AND
        "UTYPE" = "UNIFACE_IO"."WUTYPE" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UBRANCH" = "UNIFACE_IO"."WUBRANCH"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_ROWID" THEN

      SELECT 
        "UVLISTNAME",
        "UVVERSION",
        "UVBRANCH",
        "ULABEL",
        "UTYPE",
        "UBRANCH",
        "UVERSION",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XUVLISTNAME",
        "UNIFACE_IO"."XUVVERSION",
        "UNIFACE_IO"."XUVBRANCH",
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUTYPE",
        "UNIFACE_IO"."XUBRANCH",
        "UNIFACE_IO"."XUVERSION",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "UVELMLS"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_ROWID" THEN

      DELETE FROM "UVELMLS"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_PRIMARY_KEY" THEN

      DELETE FROM "UVELMLS"
      WHERE 
        "UVLISTNAME" = "UNIFACE_IO"."WUVLISTNAME" AND
        "UVBRANCH" = "UNIFACE_IO"."WUVBRANCH" AND
        "UVVERSION" = "UNIFACE_IO"."WUVVERSION" AND
        "UTYPE" = "UNIFACE_IO"."WUTYPE" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UBRANCH" = "UNIFACE_IO"."WUBRANCH";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_PRIMARY_KEY" THEN

      UPDATE "UVELMLS" SET
        "UVERSION" = "UNIFACE_IO"."XUVERSION",
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        "UVLISTNAME" = "UNIFACE_IO"."WUVLISTNAME" AND
        "UVBRANCH" = "UNIFACE_IO"."WUVBRANCH" AND
        "UVVERSION" = "UNIFACE_IO"."WUVVERSION" AND
        "UTYPE" = "UNIFACE_IO"."WUTYPE" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UBRANCH" = "UNIFACE_IO"."WUBRANCH";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_ROWID" THEN

      UPDATE "UVELMLS" SET
        "UVERSION" = "UNIFACE_IO"."XUVERSION",
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSE

      raise_application_error( -20000, 'Unhandled UNIFACE I/O request' );

    END IF;

  EXCEPTION

    WHEN NO_DATA_FOUND THEN

      "ONE_ROW_AFFECTED" := "NUM_FALSE";

  END "UNIFACE_IO";
END "UVELMLS$U";
/

CREATE TABLE "UVELMT"(
        "ULABEL"                            CHAR(49),
        "UTYPE"                             CHAR(4),
        "UBRANCH"                           CHAR(3),
        "UDESCR"                            CHAR(25),
        "USTATDESCR"                        CHAR(16),
        "USTAT"                             NUMBER(1),
        "UVERSION"                          CHAR(9),
        "UTIMESTAMP"                        DATE,
        "UVERSIONRES"                       CHAR(9),
        "UUSERNAME"                         CHAR(16),
        "UOBSOLETE"                         CHAR(1),
  CONSTRAINT "UVELMTP1" PRIMARY KEY(
        "UTYPE",
        "ULABEL",
        "UBRANCH" ))
/

CREATE OR REPLACE PACKAGE "UVELMT$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER );

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XULABEL"                           IN OUT
          "UVELMT"."ULABEL"%TYPE,

        "XUTYPE"                            IN OUT
          "UVELMT"."UTYPE"%TYPE,

        "XUBRANCH"                          IN OUT
          "UVELMT"."UBRANCH"%TYPE,

        "XUDESCR"                           IN OUT
          "UVELMT"."UDESCR"%TYPE,

        "XUSTATDESCR"                       IN OUT
          "UVELMT"."USTATDESCR"%TYPE,

        "XUSTAT"                            IN OUT
          "UVELMT"."USTAT"%TYPE,

        "XUVERSION"                         IN OUT
          "UVELMT"."UVERSION"%TYPE,

        "XUTIMESTAMP"                       IN OUT
          "UVELMT"."UTIMESTAMP"%TYPE,

        "XUVERSIONRES"                      IN OUT
          "UVELMT"."UVERSIONRES"%TYPE,

        "XUUSERNAME"                        IN OUT
          "UVELMT"."UUSERNAME"%TYPE,

        "XUOBSOLETE"                        IN OUT
          "UVELMT"."UOBSOLETE"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WUTYPE"                            IN
          "UVELMT"."UTYPE"%TYPE,

        "WULABEL"                           IN
          "UVELMT"."ULABEL"%TYPE,

        "WUBRANCH"                          IN
          "UVELMT"."UBRANCH"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER );
END "UVELMT$U";
/

CREATE OR REPLACE PACKAGE BODY "UVELMT$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER )

  IS
  BEGIN

    "PACKAGE_VERSION"."MAJOR_VERSION" := 2;
    "PACKAGE_VERSION"."MINOR_VERSION" := 2;

  END "PACKAGE_VERSION";

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XULABEL"                           IN OUT
          "UVELMT"."ULABEL"%TYPE,

        "XUTYPE"                            IN OUT
          "UVELMT"."UTYPE"%TYPE,

        "XUBRANCH"                          IN OUT
          "UVELMT"."UBRANCH"%TYPE,

        "XUDESCR"                           IN OUT
          "UVELMT"."UDESCR"%TYPE,

        "XUSTATDESCR"                       IN OUT
          "UVELMT"."USTATDESCR"%TYPE,

        "XUSTAT"                            IN OUT
          "UVELMT"."USTAT"%TYPE,

        "XUVERSION"                         IN OUT
          "UVELMT"."UVERSION"%TYPE,

        "XUTIMESTAMP"                       IN OUT
          "UVELMT"."UTIMESTAMP"%TYPE,

        "XUVERSIONRES"                      IN OUT
          "UVELMT"."UVERSIONRES"%TYPE,

        "XUUSERNAME"                        IN OUT
          "UVELMT"."UUSERNAME"%TYPE,

        "XUOBSOLETE"                        IN OUT
          "UVELMT"."UOBSOLETE"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WUTYPE"                            IN
          "UVELMT"."UTYPE"%TYPE,

        "WULABEL"                           IN
          "UVELMT"."ULABEL"%TYPE,

        "WUBRANCH"                          IN
          "UVELMT"."UBRANCH"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER )

  IS

    "DUMMY_FIELD"                       
          NUMBER;

    "NUM_FALSE"                         CONSTANT NUMBER  := 0;
    "NUM_TRUE"                          CONSTANT NUMBER  := 1;

    "SELECT_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 0;
    "SELECT_ROWIDROW_BY_PRIMARY_KEY"    CONSTANT NUMBER  := 1;
    "SELECT_ROW_BY_ROWID"               CONSTANT NUMBER  := 2;
    "CHECK_EXISTENCE_OF_PRIMARY_KEY"    CONSTANT NUMBER  := 3;
    "LOCK_ROW_BY_PRIMARY_KEY"           CONSTANT NUMBER  := 4;
    "LOCK_ROW_BY_ROWID"                 CONSTANT NUMBER  := 5;
    "DELETE_ROW_BY_ROWID"               CONSTANT NUMBER  := 6;
    "DELETE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 7;
    "UPDATE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 9;
    "UPDATE_ROW_BY_ROWID"               CONSTANT NUMBER  := 11;

  BEGIN

    "ONE_ROW_AFFECTED" := "NUM_TRUE";

    IF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "ULABEL",
        "UTYPE",
        "UBRANCH",
        "UDESCR",
        "USTATDESCR",
        "USTAT",
        "UVERSION",
        "UTIMESTAMP",
        "UVERSIONRES",
        "UUSERNAME",
        "UOBSOLETE"
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUTYPE",
        "UNIFACE_IO"."XUBRANCH",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUSTATDESCR",
        "UNIFACE_IO"."XUSTAT",
        "UNIFACE_IO"."XUVERSION",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUVERSIONRES",
        "UNIFACE_IO"."XUUSERNAME",
        "UNIFACE_IO"."XUOBSOLETE"
      FROM "UVELMT"
      WHERE 
        "UTYPE" = "UNIFACE_IO"."WUTYPE" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UBRANCH" = "UNIFACE_IO"."WUBRANCH";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROWIDROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "ULABEL",
        "UTYPE",
        "UBRANCH",
        "UDESCR",
        "USTATDESCR",
        "USTAT",
        "UVERSION",
        "UTIMESTAMP",
        "UVERSIONRES",
        "UUSERNAME",
        "UOBSOLETE",
        ROWID
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUTYPE",
        "UNIFACE_IO"."XUBRANCH",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUSTATDESCR",
        "UNIFACE_IO"."XUSTAT",
        "UNIFACE_IO"."XUVERSION",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUVERSIONRES",
        "UNIFACE_IO"."XUUSERNAME",
        "UNIFACE_IO"."XUOBSOLETE",
        "UNIFACE_IO"."XROWID"
      FROM "UVELMT"
      WHERE 
        "UTYPE" = "UNIFACE_IO"."WUTYPE" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UBRANCH" = "UNIFACE_IO"."WUBRANCH";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_ROWID" THEN

      SELECT /*+ FIRST_ROWS */ 
        "ULABEL",
        "UTYPE",
        "UBRANCH",
        "UDESCR",
        "USTATDESCR",
        "USTAT",
        "UVERSION",
        "UTIMESTAMP",
        "UVERSIONRES",
        "UUSERNAME",
        "UOBSOLETE"
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUTYPE",
        "UNIFACE_IO"."XUBRANCH",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUSTATDESCR",
        "UNIFACE_IO"."XUSTAT",
        "UNIFACE_IO"."XUVERSION",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUVERSIONRES",
        "UNIFACE_IO"."XUUSERNAME",
        "UNIFACE_IO"."XUOBSOLETE"
      FROM "UVELMT"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "CHECK_EXISTENCE_OF_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 0
      INTO
        "UNIFACE_IO"."DUMMY_FIELD"
      FROM "UVELMT"
      WHERE 
        "UTYPE" = "UNIFACE_IO"."WUTYPE" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UBRANCH" = "UNIFACE_IO"."WUBRANCH";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_PRIMARY_KEY" THEN

      SELECT 
        "ULABEL",
        "UTYPE",
        "UBRANCH",
        "UDESCR",
        "USTATDESCR",
        "USTAT",
        "UVERSION",
        "UTIMESTAMP",
        "UVERSIONRES",
        "UUSERNAME",
        "UOBSOLETE",
        ROWID
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUTYPE",
        "UNIFACE_IO"."XUBRANCH",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUSTATDESCR",
        "UNIFACE_IO"."XUSTAT",
        "UNIFACE_IO"."XUVERSION",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUVERSIONRES",
        "UNIFACE_IO"."XUUSERNAME",
        "UNIFACE_IO"."XUOBSOLETE",
        "UNIFACE_IO"."XROWID"
      FROM "UVELMT"
      WHERE 
        "UTYPE" = "UNIFACE_IO"."WUTYPE" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UBRANCH" = "UNIFACE_IO"."WUBRANCH"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_ROWID" THEN

      SELECT 
        "ULABEL",
        "UTYPE",
        "UBRANCH",
        "UDESCR",
        "USTATDESCR",
        "USTAT",
        "UVERSION",
        "UTIMESTAMP",
        "UVERSIONRES",
        "UUSERNAME",
        "UOBSOLETE"
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUTYPE",
        "UNIFACE_IO"."XUBRANCH",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUSTATDESCR",
        "UNIFACE_IO"."XUSTAT",
        "UNIFACE_IO"."XUVERSION",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUVERSIONRES",
        "UNIFACE_IO"."XUUSERNAME",
        "UNIFACE_IO"."XUOBSOLETE"
      FROM "UVELMT"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_ROWID" THEN

      DELETE FROM "UVELMT"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_PRIMARY_KEY" THEN

      DELETE FROM "UVELMT"
      WHERE 
        "UTYPE" = "UNIFACE_IO"."WUTYPE" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UBRANCH" = "UNIFACE_IO"."WUBRANCH";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_PRIMARY_KEY" THEN

      UPDATE "UVELMT" SET
        "UDESCR" = "UNIFACE_IO"."XUDESCR",
        "USTATDESCR" = "UNIFACE_IO"."XUSTATDESCR",
        "USTAT" = "UNIFACE_IO"."XUSTAT",
        "UVERSION" = "UNIFACE_IO"."XUVERSION",
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP",
        "UVERSIONRES" = "UNIFACE_IO"."XUVERSIONRES",
        "UUSERNAME" = "UNIFACE_IO"."XUUSERNAME",
        "UOBSOLETE" = "UNIFACE_IO"."XUOBSOLETE"
      WHERE 
        "UTYPE" = "UNIFACE_IO"."WUTYPE" AND
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UBRANCH" = "UNIFACE_IO"."WUBRANCH";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_ROWID" THEN

      UPDATE "UVELMT" SET
        "UDESCR" = "UNIFACE_IO"."XUDESCR",
        "USTATDESCR" = "UNIFACE_IO"."XUSTATDESCR",
        "USTAT" = "UNIFACE_IO"."XUSTAT",
        "UVERSION" = "UNIFACE_IO"."XUVERSION",
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP",
        "UVERSIONRES" = "UNIFACE_IO"."XUVERSIONRES",
        "UUSERNAME" = "UNIFACE_IO"."XUUSERNAME",
        "UOBSOLETE" = "UNIFACE_IO"."XUOBSOLETE"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSE

      raise_application_error( -20000, 'Unhandled UNIFACE I/O request' );

    END IF;

  EXCEPTION

    WHEN NO_DATA_FOUND THEN

      "ONE_ROW_AFFECTED" := "NUM_FALSE";

  END "UNIFACE_IO";
END "UVELMT$U";
/

CREATE TABLE "UVFORM"(
        "UTIMESTAMP"                        DATE,
        "UCOMPSTAMP"                        DATE,
        "ULABEL"                            CHAR(16),
        "UVERS"                             CHAR(12),
        "FTYP"                              CHAR(4),
        "UDESCR"                            CHAR(25),
        "FHEAD"                             CHAR(6),
        "VMAAT"                             CHAR(6),
        "HMAAT"                             CHAR(6),
        "UCOLOR"                            CHAR(6),
        "WVPOS"                             CHAR(6),
        "WHPOS"                             CHAR(6),
        "WVSIZ"                             CHAR(6),
        "WHSIZ"                             CHAR(6),
        "CLRSCRN"                           CHAR(1),
        "UBORDER"                           CHAR(1),
        "RIBIN"                             CHAR(16),
        "RIBOT"                             CHAR(16),
        "MOVABLE"                           CHAR(1),
        "VIDEOINVERSE"                      CHAR(1),
        "VIDEOBRIGHT"                       CHAR(1),
        "VIDEOUNLINE"                       CHAR(1),
        "VIDEOBLINK"                        CHAR(1),
        "UPANEL"                            CHAR(32),
        "POSPANEL"                          CHAR(1),
        "UPULL"                             CHAR(32),
        "HIDESTACK"                         CHAR(1),
        "TEMPLATENAME"                      CHAR(16),
        "UINHERIT"                          CHAR(1),
        "LIBRAR"                            CHAR(32),
        "UTRANSACT"                         CHAR(8),
        "TPLACTUAL"                         LONG,
  CONSTRAINT "UVFORMP1" PRIMARY KEY(
        "UVERS",
        "ULABEL" ))
/

CREATE TABLE "OUVFORM"(
        "UVERS"                             CHAR(12),
        "ULABEL"                            CHAR(16),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVFORMP1" PRIMARY KEY(
        "UVERS",
        "ULABEL",
        "SEGM" ))
/

CREATE TABLE "UVGFIF"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_MLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "U_MOD"                             CHAR(64),
        "UDESCR"                            CHAR(25),
        "TPLPARS"                           LONG,
  CONSTRAINT "UVGFIFP1" PRIMARY KEY(
        "UVERS",
        "U_MLAB" ))
/

CREATE TABLE "OUVGFIF"(
        "UVERS"                             CHAR(12),
        "U_MLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVGFIFP1" PRIMARY KEY(
        "UVERS",
        "U_MLAB",
        "SEGM" ))
/

CREATE TABLE "UVGFLAY"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_MLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "U_MOD"                             CHAR(128),
        "UDESCR"                            CHAR(25),
        "TPLPARS"                           LONG,
  CONSTRAINT "UVGFLAYP1" PRIMARY KEY(
        "UVERS",
        "U_MLAB" ))
/

CREATE TABLE "OUVGFLAY"(
        "UVERS"                             CHAR(12),
        "U_MLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVGFLAYP1" PRIMARY KEY(
        "UVERS",
        "U_MLAB",
        "SEGM" ))
/

CREATE TABLE "UVGFSYN"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            NUMBER(4),
        "U_MLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "U_MOD"                             CHAR(192),
        "UDESCR"                            CHAR(25),
        "TPLPARS"                           LONG,
  CONSTRAINT "UVGFSYNP1" PRIMARY KEY(
        "UVERS",
        "U_MLAB" ))
/

CREATE TABLE "OUVGFSYN"(
        "UVERS"                             CHAR(12),
        "U_MLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVGFSYNP1" PRIMARY KEY(
        "UVERS",
        "U_MLAB",
        "SEGM" ))
/

CREATE TABLE "UVGGIF"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_MLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "U_MOD"                             CHAR(64),
        "UDESCR"                            CHAR(25),
        "TPLPARS"                           LONG,
  CONSTRAINT "UVGGIFP1" PRIMARY KEY(
        "UVERS",
        "U_MLAB" ))
/

CREATE TABLE "OUVGGIF"(
        "UVERS"                             CHAR(12),
        "U_MLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVGGIFP1" PRIMARY KEY(
        "UVERS",
        "U_MLAB",
        "SEGM" ))
/

CREATE TABLE "UVGLYPH"(
        "UTIMESTAMP"                        DATE,
        "UCVERS"                            CHAR(1),
        "UCSUB"                             CHAR(1),
        "UCLABEL"                           CHAR(16),
        "UCVAR"                             CHAR(16),
        "UCTYPE"                            CHAR(3),
        "UCLASS"                            CHAR(8),
        "UVERS"                             CHAR(12),
        "UCOPTION"                          CHAR(1),
        "UDESCR"                            CHAR(25),
        "UBITMAP"                           LONG RAW,
  CONSTRAINT "UVGLYPHP1" PRIMARY KEY(
        "UVERS",
        "UCSUB",
        "UCVAR",
        "UCTYPE",
        "UCLABEL",
        "UCLASS" ))
/

CREATE INDEX "UVGLYPHI2" ON "UVGLYPH"(
        "UVERS",
        "UCSUB",
        "UCLABEL",
        "UCVAR" )
/

CREATE INDEX "UVGLYPHI3" ON "UVGLYPH"(
        "UVERS",
        "UCSUB",
        "UCTYPE",
        "UCLABEL" )
/

CREATE TABLE "OUVGLYPH"(
        "UVERS"                             CHAR(12),
        "UCSUB"                             CHAR(1),
        "UCVAR"                             CHAR(16),
        "UCTYPE"                            CHAR(3),
        "UCLABEL"                           CHAR(16),
        "UCLASS"                            CHAR(8),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG RAW,
  CONSTRAINT "OUVGLYPHP1" PRIMARY KEY(
        "UVERS",
        "UCSUB",
        "UCVAR",
        "UCTYPE",
        "UCLABEL",
        "UCLASS",
        "SEGM" ))
/

CREATE TABLE "UVGREGS"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_TYPE"                            CHAR(2),
        "U_FORMLIB"                         CHAR(16),
        "U_NAME"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_DTYP"                            CHAR(2),
        "U_LAYOUT"                          CHAR(46),
        "U_DOC"                             LONG,
  CONSTRAINT "UVGREGSP1" PRIMARY KEY(
        "UVERS",
        "U_FORMLIB",
        "U_NAME" ))
/

CREATE INDEX "UVGREGSI2" ON "UVGREGS"(
        "UVERS",
        "U_NAME" )
/

CREATE TABLE "OUVGREGS"(
        "UVERS"                             CHAR(12),
        "U_FORMLIB"                         CHAR(16),
        "U_NAME"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVGREGSP1" PRIMARY KEY(
        "UVERS",
        "U_FORMLIB",
        "U_NAME",
        "SEGM" ))
/

CREATE TABLE "UVSITEM"(
        "UMENU"                             CHAR(16),
        "UVAR"                              CHAR(16),
        "ULAN"                              CHAR(3),
        "UTECHSEQ"                          CHAR(6),
        "UVERS"                             CHAR(12),
        "USEQ"                              NUMBER(2),
        "UTIMESTAMP"                        DATE,
        "UDESCR"                            CHAR(25),
        "UENABLE"                           CHAR(1),
        "UHIDE"                             CHAR(1),
        "UCHECK"                            CHAR(1),
        "REFTYPE"                           CHAR(1),
        "UCASCADE"                          CHAR(16),
        "UCOMMENT"                          LONG,
  CONSTRAINT "UVSITEMP1" PRIMARY KEY(
        "UVERS",
        "UVAR",
        "ULAN",
        "UMENU",
        "UTECHSEQ" ))
/

CREATE INDEX "UVSITEMI2" ON "UVSITEM"(
        "UVERS",
        "UMENU",
        "UVAR" )
/

CREATE INDEX "UVSITEMI3" ON "UVSITEM"(
        "UVERS",
        "ULAN",
        "UMENU" )
/

CREATE TABLE "OUVSITEM"(
        "UVERS"                             CHAR(12),
        "UVAR"                              CHAR(16),
        "ULAN"                              CHAR(3),
        "UMENU"                             CHAR(16),
        "UTECHSEQ"                          CHAR(6),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVSITEMP1" PRIMARY KEY(
        "UVERS",
        "UVAR",
        "ULAN",
        "UMENU",
        "UTECHSEQ",
        "SEGM" ))
/

CREATE TABLE "UVSMENU"(
        "UMENU"                             CHAR(16),
        "UVAR"                              CHAR(16),
        "ULAN"                              CHAR(3),
        "UVERS"                             CHAR(12),
        "MENUTYPE"                          CHAR(1),
        "UTIMESTAMP"                        DATE,
        "UDESCR"                            CHAR(25),
        "AUTHORIZ"                          CHAR(1),
        "UCOMMENT"                          LONG,
  CONSTRAINT "UVSMENUP1" PRIMARY KEY(
        "UVERS",
        "UVAR",
        "ULAN",
        "UMENU" ))
/

CREATE INDEX "UVSMENUI2" ON "UVSMENU"(
        "UVERS",
        "UMENU",
        "UVAR" )
/

CREATE INDEX "UVSMENUI3" ON "UVSMENU"(
        "UVERS",
        "ULAN",
        "UMENU" )
/

CREATE TABLE "OUVSMENU"(
        "UVERS"                             CHAR(12),
        "UVAR"                              CHAR(16),
        "ULAN"                              CHAR(3),
        "UMENU"                             CHAR(16),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVSMENUP1" PRIMARY KEY(
        "UVERS",
        "UVAR",
        "ULAN",
        "UMENU",
        "SEGM" ))
/

CREATE TABLE "UVSOURC"(
        "UTIMESTAMP"                        DATE,
        "UCOMPSTAMP"                        DATE,
        "USTAT"                             CHAR(1),
        "ULABEL"                            CHAR(16),
        "UVAR"                              CHAR(16),
        "ULAN"                              CHAR(3),
        "USUB"                              CHAR(1),
        "UVERS"                             CHAR(12),
        "MSGTYPE"                           CHAR(1),
        "UDESCR"                            CHAR(25),
        "UVPOS"                             CHAR(6),
        "UHPOS"                             CHAR(6),
        "UVSIZ"                             CHAR(6),
        "UHSIZ"                             CHAR(6),
        "AUTHORIZ"                          CHAR(1),
        "UCLASS"                            CHAR(1),
        "LOCREF"                            CHAR(1),
        "UCONFIRM"                          CHAR(1),
        "UAUDIO"                            NUMBER(5),
        "HELPID"                            CHAR(32),
        "UCOMMENT"                          LONG,
  CONSTRAINT "UVSOURCP1" PRIMARY KEY(
        "UVERS",
        "USUB",
        "UVAR",
        "ULAN",
        "ULABEL" ))
/

CREATE INDEX "UVSOURCI2" ON "UVSOURC"(
        "UVERS",
        "USUB",
        "ULABEL",
        "UVAR" )
/

CREATE INDEX "UVSOURCI3" ON "UVSOURC"(
        "UVERS",
        "USUB",
        "ULAN",
        "ULABEL" )
/

CREATE TABLE "OUVSOURC"(
        "UVERS"                             CHAR(12),
        "USUB"                              CHAR(1),
        "UVAR"                              CHAR(16),
        "ULAN"                              CHAR(3),
        "ULABEL"                            CHAR(16),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVSOURCP1" PRIMARY KEY(
        "UVERS",
        "USUB",
        "UVAR",
        "ULAN",
        "ULABEL",
        "SEGM" ))
/

CREATE TABLE "UVSYSLS"(
        "UVLISTNAME"                        CHAR(16),
        "UVVERSION"                         CHAR(9),
        "UVBRANCH"                          CHAR(3),
        "UDESCR"                            CHAR(25),
        "USTAT"                             CHAR(1),
        "UTIMESTAMP"                        DATE,
        "UCMT"                              LONG,
  CONSTRAINT "UVSYSLSP1" PRIMARY KEY(
        "UVLISTNAME",
        "UVBRANCH",
        "UVVERSION" ))
/

CREATE TABLE "OUVSYSLS"(
        "UVLISTNAME"                        CHAR(16),
        "UVBRANCH"                          CHAR(3),
        "UVVERSION"                         CHAR(9),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVSYSLSP1" PRIMARY KEY(
        "UVLISTNAME",
        "UVBRANCH",
        "UVVERSION",
        "SEGM" ))
/

CREATE TABLE "UVTPLFL"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "TEMPLATENAME"                      CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_LEV"                             CHAR(2),
        "U_DTYP"                            CHAR(2),
        "U_INDB"                            CHAR(1),
        "TPLINTF"                           CHAR(32),
        "U_INTF"                            CHAR(64),
        "TPLSYN"                            CHAR(32),
        "U_SYN"                             CHAR(192),
        "TPLLAY"                            CHAR(32),
        "U_LAY"                             CHAR(128),
        "WIDGETTYPE"                        CHAR(16),
        "TPLPARS"                           LONG,
  CONSTRAINT "UVTPLFLP1" PRIMARY KEY(
        "UVERS",
        "TEMPLATENAME" ))
/

CREATE TABLE "OUVTPLFL"(
        "UVERS"                             CHAR(12),
        "TEMPLATENAME"                      CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVTPLFLP1" PRIMARY KEY(
        "UVERS",
        "TEMPLATENAME",
        "SEGM" ))
/

CREATE TABLE "UVVERS"(
        "UTIMESTAMP"                        DATE,
        "ULABEL"                            CHAR(49),
        "UTYPE"                             CHAR(4),
        "UBRANCH"                           CHAR(3),
        "UVERSION"                          CHAR(9),
        "UUSERNAME"                         CHAR(16),
        "USTATUS"                           CHAR(4),
        "UCMT"                              LONG,
  CONSTRAINT "UVVERSP1" PRIMARY KEY(
        "UTYPE",
        "ULABEL",
        "UBRANCH",
        "UVERSION" ))
/

CREATE TABLE "OUVVERS"(
        "UTYPE"                             CHAR(4),
        "ULABEL"                            CHAR(49),
        "UBRANCH"                           CHAR(3),
        "UVERSION"                          CHAR(9),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVVERSP1" PRIMARY KEY(
        "UTYPE",
        "ULABEL",
        "UBRANCH",
        "UVERSION",
        "SEGM" ))
/

CREATE TABLE "UVXFIEL"(
        "UTIMESTAMP"                        DATE,
        "ULABEL"                            CHAR(32),
        "GRP"                               CHAR(32),
        "TECHBASE"                          CHAR(16),
        "UFORM"                             CHAR(16),
        "UVERS"                             CHAR(12),
        "UBASE"                             CHAR(32) NOT NULL,
        "U_TLAB"                            CHAR(32),
        "UDESCR"                            CHAR(25),
        "U_DTYP"                            CHAR(2),
        "U_INDB"                            CHAR(1),
        "TPLLAY"                            CHAR(32),
        "LAYOUTMOD"                         CHAR(128),
        "TPLSYN"                            CHAR(32),
        "SYNTAXMOD"                         CHAR(192),
        "TPLINTF"                           CHAR(32),
        "INTERFACEMOD"                      CHAR(64),
        "TABSTOP"                           NUMBER(7),
        "WIDGETTYPE"                        CHAR(16),
        "TEMPLATENAME"                      CHAR(32),
        "UINHERIT"                          CHAR(1),
        "STARTMOD"                          LONG,
  CONSTRAINT "UVXFIELP1" PRIMARY KEY(
        "UVERS",
        "UFORM",
        "TECHBASE",
        "GRP",
        "ULABEL" ))
/

CREATE TABLE "OUVXFIEL"(
        "UVERS"                             CHAR(12),
        "UFORM"                             CHAR(16),
        "TECHBASE"                          CHAR(16),
        "GRP"                               CHAR(32),
        "ULABEL"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVXFIELP1" PRIMARY KEY(
        "UVERS",
        "UFORM",
        "TECHBASE",
        "GRP",
        "ULABEL",
        "SEGM" ))
/

CREATE TABLE "UVXGROU"(
        "UTIMESTAMP"                        DATE,
        "ULABEL"                            CHAR(32),
        "UBASE"                             CHAR(32),
        "UFORM"                             CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_BORD"                            CHAR(1),
        "U_INDB"                            CHAR(1),
        "U_DBMS"                            CHAR(3),
        "U_UPD"                             CHAR(1),
        "U_MINL"                            NUMBER(6),
        "U_MAXL"                            NUMBER(6),
        "U_MINR"                            NUMBER(6),
        "U_MAXR"                            NUMBER(6),
        "TPLGINTF"                          CHAR(32),
        "U_INTF"                            CHAR(64),
        "TEMPLATENAME"                      CHAR(32),
        "UINHERIT"                          CHAR(1),
        "TPLACTUAL"                         LONG,
  CONSTRAINT "UVXGROUP1" PRIMARY KEY(
        "UVERS",
        "UFORM",
        "UBASE",
        "ULABEL" ))
/

CREATE TABLE "OUVXGROU"(
        "UVERS"                             CHAR(12),
        "UFORM"                             CHAR(32),
        "UBASE"                             CHAR(32),
        "ULABEL"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVXGROUP1" PRIMARY KEY(
        "UVERS",
        "UFORM",
        "UBASE",
        "ULABEL",
        "SEGM" ))
/

CREATE TABLE "UVXREGS"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_TYPE"                            CHAR(2),
        "U_FORMLIB"                         CHAR(16),
        "U_NAME"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_DTYP"                            CHAR(2),
        "U_LAYOUT"                          CHAR(46),
        "U_DOC"                             LONG,
  CONSTRAINT "UVXREGSP1" PRIMARY KEY(
        "UVERS",
        "U_FORMLIB",
        "U_NAME" ))
/

CREATE TABLE "OUVXREGS"(
        "UVERS"                             CHAR(12),
        "U_FORMLIB"                         CHAR(16),
        "U_NAME"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVXREGSP1" PRIMARY KEY(
        "UVERS",
        "U_FORMLIB",
        "U_NAME",
        "SEGM" ))
/

CREATE TABLE "UVSUBS"(
        "UTIMESTAMP"                        DATE,
        "USUBSYSTEM"                        CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "UPARENT"                           CHAR(16),
        "UCOMMENT"                          LONG,
  CONSTRAINT "UVSUBSP1" PRIMARY KEY(
        "USUBSYSTEM" ))
/

CREATE TABLE "OUVSUBS"(
        "USUBSYSTEM"                        CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUVSUBSP1" PRIMARY KEY(
        "USUBSYSTEM",
        "SEGM" ))
/

