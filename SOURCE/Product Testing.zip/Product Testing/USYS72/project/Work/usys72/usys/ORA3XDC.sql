Rem
Rem   Description
Rem   -----------
Rem   Action                    : Create DBMS referential integrity
Rem   Application Model         : DICT
Rem   DBMS Version              : Oracle 7.3
Rem   Uniface Driver Version    : U3.3
Rem   Uniface Version           : UNIFACE 7.2 and above
Rem   Required User Option      : DF
Rem   File Version              : %U%
Rem   File Name                 : ora3xdc.sql
Rem
Rem   Application model DICT
Rem   ----------------------
Rem   The entities of the application model DICT contain the source definitions
Rem   for applications. Applications which access the entities of DICT,
Rem   primarily the Application Development System, locate the associated
Rem   tables or files on the path $IDF.
Rem
Rem   The Application Development System is responsible for maintaining the
Rem   information stored in the entities of DICT. It uses this information to
Rem   compile definitions.
Rem
Rem   Copyright (c) 1995, Uniface B.V.
Rem

ALTER TABLE "UAPLFRM"
  ADD ( CONSTRAINT "U_UAPPL_UAPLFRM_DICT" FOREIGN KEY (
        "ULABEL" )
  REFERENCES "UAPPL" ( 
        "ULABEL" )
  ON DELETE CASCADE )
  ADD ( CONSTRAINT "U_UFORM_UAPLFRM_DICT" FOREIGN KEY (
        "UFORM" )
  REFERENCES "UFORM" ( 
        "ULABEL" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUAPPL"
  ADD ( CONSTRAINT "OUAPPL" FOREIGN KEY (
        "ULABEL" )
  REFERENCES "UAPPL" ( 
        "ULABEL" )
  ON DELETE CASCADE )
/

ALTER TABLE "UCFIELD"
  ADD ( CONSTRAINT "U_UCTABLE_UCFIELD_DICT" FOREIGN KEY (
        "U_VLAB",
        "U_TLAB" )
  REFERENCES "UCTABLE" ( 
        "U_VLAB",
        "U_TLAB" )
  ON DELETE CASCADE )
  ADD ( CONSTRAINT "U_UGFIF_UCFIELD_DICT" FOREIGN KEY (
        "TPLINTF" )
  REFERENCES "UGFIF" ( 
        "U_MLAB" ) )
  ADD ( CONSTRAINT "U_UGFLAY_UCFIELD_DICT" FOREIGN KEY (
        "TPLLAY" )
  REFERENCES "UGFLAY" ( 
        "U_MLAB" ) )
  ADD ( CONSTRAINT "U_UGFSYN_UCFIELD_DICT" FOREIGN KEY (
        "TPLSYN" )
  REFERENCES "UGFSYN" ( 
        "U_MLAB" ) )
  ADD ( CONSTRAINT "U_UTPLFLD_UCFIELD_DICT" FOREIGN KEY (
        "TEMPLATENAME" )
  REFERENCES "UTPLFLD" ( 
        "TEMPLATENAME" ) )
/

ALTER TABLE "OUCFIELD"
  ADD ( CONSTRAINT "OUCFIELD" FOREIGN KEY (
        "U_FLAB",
        "U_VLAB",
        "U_TLAB" )
  REFERENCES "UCFIELD" ( 
        "U_FLAB",
        "U_VLAB",
        "U_TLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "UCGROUP"
  ADD ( CONSTRAINT "U_UCSCH_UCGROUP_DICT" FOREIGN KEY (
        "U_VLAB" )
  REFERENCES "UCSCH" ( 
        "U_VLAB" )
  ON DELETE CASCADE )
  ADD ( CONSTRAINT "U_UCTABLE_UCGROUP_DICT" FOREIGN KEY (
        "U_VLAB",
        "U_TLAB" )
  REFERENCES "UCTABLE" ( 
        "U_VLAB",
        "U_TLAB" )
  ON DELETE CASCADE )
  ADD ( CONSTRAINT "U_UGGIF_UCGROUP_DICT" FOREIGN KEY (
        "TPLGINTF" )
  REFERENCES "UGGIF" ( 
        "U_MLAB" ) )
  ADD ( CONSTRAINT "U_UTPLGRP_UCGROUP_DICT" FOREIGN KEY (
        "TEMPLATENAME" )
  REFERENCES "UTPLGRP" ( 
        "TEMPLATENAME" ) )
/

ALTER TABLE "OUCGROUP"
  ADD ( CONSTRAINT "OUCGROUP" FOREIGN KEY (
        "U_GLAB",
        "U_VLAB" )
  REFERENCES "UCGROUP" ( 
        "U_GLAB",
        "U_VLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "UCKEY"
  ADD ( CONSTRAINT "U_UCTABLE_UCKEY_DICT" FOREIGN KEY (
        "U_VLAB",
        "U_TLAB" )
  REFERENCES "UCTABLE" ( 
        "U_VLAB",
        "U_TLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUCKEY"
  ADD ( CONSTRAINT "OUCKEY" FOREIGN KEY (
        "U_VLAB",
        "U_TLAB",
        "U_KSEQ" )
  REFERENCES "UCKEY" ( 
        "U_VLAB",
        "U_TLAB",
        "U_KSEQ" )
  ON DELETE CASCADE )
/

ALTER TABLE "UCRELSH"
  ADD ( CONSTRAINT "U_UCGRP_1_UCRELSH_DICT" FOREIGN KEY (
        "U_GLAB",
        "U_VLAB" )
  REFERENCES "UCGROUP" ( 
        "U_GLAB",
        "U_VLAB" ) )
  ADD ( CONSTRAINT "U_UCGRP_M_UCRELSH_DICT" FOREIGN KEY (
        "U_RGLAB",
        "U_RVLAB" )
  REFERENCES "UCGROUP" ( 
        "U_GLAB",
        "U_VLAB" ) )
/

ALTER TABLE "OUCRELSH"
  ADD ( CONSTRAINT "OUCRELSH" FOREIGN KEY (
        "U_GLAB",
        "U_VLAB",
        "U_RGLAB" )
  REFERENCES "UCRELSH" ( 
        "U_GLAB",
        "U_VLAB",
        "U_RGLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUCSCH"
  ADD ( CONSTRAINT "OUCSCH" FOREIGN KEY (
        "U_VLAB" )
  REFERENCES "UCSCH" ( 
        "U_VLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "UCSDIA"
  ADD ( CONSTRAINT "U_UCSCH_UCSDIA_DICT" FOREIGN KEY (
        "U_VLAB" )
  REFERENCES "UCSCH" ( 
        "U_VLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUCSDIA"
  ADD ( CONSTRAINT "OUCSDIA" FOREIGN KEY (
        "U_VLAB" )
  REFERENCES "UCSDIA" ( 
        "U_VLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "UCTABLE"
  ADD ( CONSTRAINT "U_UCSCH_UCTABLE_DICT" FOREIGN KEY (
        "U_VLAB" )
  REFERENCES "UCSCH" ( 
        "U_VLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUCTABLE"
  ADD ( CONSTRAINT "OUCTABLE" FOREIGN KEY (
        "U_VLAB",
        "U_TLAB" )
  REFERENCES "UCTABLE" ( 
        "U_VLAB",
        "U_TLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUFORM"
  ADD ( CONSTRAINT "OUFORM" FOREIGN KEY (
        "ULABEL" )
  REFERENCES "UFORM" ( 
        "ULABEL" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUGFIF"
  ADD ( CONSTRAINT "OUGFIF" FOREIGN KEY (
        "U_MLAB" )
  REFERENCES "UGFIF" ( 
        "U_MLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUGFLAY"
  ADD ( CONSTRAINT "OUGFLAY" FOREIGN KEY (
        "U_MLAB" )
  REFERENCES "UGFLAY" ( 
        "U_MLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUGFSYN"
  ADD ( CONSTRAINT "OUGFSYN" FOREIGN KEY (
        "U_MLAB" )
  REFERENCES "UGFSYN" ( 
        "U_MLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUGGIF"
  ADD ( CONSTRAINT "OUGGIF" FOREIGN KEY (
        "U_MLAB" )
  REFERENCES "UGGIF" ( 
        "U_MLAB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUGLYPH"
  ADD ( CONSTRAINT "OUGLYPH" FOREIGN KEY (
        "UCSUB",
        "UCLABEL",
        "UCVAR",
        "UCTYPE",
        "UCLASS" )
  REFERENCES "UGLYPH" ( 
        "UCSUB",
        "UCLABEL",
        "UCVAR",
        "UCTYPE",
        "UCLASS" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUGREGS"
  ADD ( CONSTRAINT "OUGREGS" FOREIGN KEY (
        "U_FORMLIB",
        "U_NAME" )
  REFERENCES "UGREGS" ( 
        "U_FORMLIB",
        "U_NAME" )
  ON DELETE CASCADE )
/

ALTER TABLE "OULANA"
  ADD ( CONSTRAINT "OULANA" FOREIGN KEY (
        "U_VLAB",
        "U_GLAB",
        "U_VAR" )
  REFERENCES "ULANA" ( 
        "U_VLAB",
        "U_GLAB",
        "U_VAR" )
  ON DELETE CASCADE )
/

ALTER TABLE "USITEM"
  ADD ( CONSTRAINT "U_USMENU_USITEM_DICT" FOREIGN KEY (
        "UMENU",
        "UVAR",
        "ULAN" )
  REFERENCES "USMENU" ( 
        "UMENU",
        "UVAR",
        "ULAN" ) )
  ADD ( CONSTRAINT "U_USM_CAS_USITEM_DICT" FOREIGN KEY (
        "UCASCADE",
        "UVAR",
        "ULAN" )
  REFERENCES "USMENU" ( 
        "UMENU",
        "UVAR",
        "ULAN" ) )
/

ALTER TABLE "OUSITEM"
  ADD ( CONSTRAINT "OUSITEM" FOREIGN KEY (
        "UMENU",
        "UVAR",
        "ULAN",
        "UTECHSEQ" )
  REFERENCES "USITEM" ( 
        "UMENU",
        "UVAR",
        "ULAN",
        "UTECHSEQ" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSMENU"
  ADD ( CONSTRAINT "OUSMENU" FOREIGN KEY (
        "UMENU",
        "UVAR",
        "ULAN" )
  REFERENCES "USMENU" ( 
        "UMENU",
        "UVAR",
        "ULAN" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSOURCE"
  ADD ( CONSTRAINT "OUSOURCE" FOREIGN KEY (
        "USUB",
        "UVAR",
        "ULABEL",
        "ULAN" )
  REFERENCES "USOURCE" ( 
        "USUB",
        "UVAR",
        "ULABEL",
        "ULAN" )
  ON DELETE CASCADE )
/

ALTER TABLE "UTPLFLD"
  ADD ( CONSTRAINT "U_UGFIF_UTPLFLD_DICT" FOREIGN KEY (
        "TPLINTF" )
  REFERENCES "UGFIF" ( 
        "U_MLAB" ) )
  ADD ( CONSTRAINT "U_UGFLAY_UTPLFLD_DICT" FOREIGN KEY (
        "TPLLAY" )
  REFERENCES "UGFLAY" ( 
        "U_MLAB" ) )
  ADD ( CONSTRAINT "U_UGFSYN_UTPLFLD_DICT" FOREIGN KEY (
        "TPLSYN" )
  REFERENCES "UGFSYN" ( 
        "U_MLAB" ) )
/

ALTER TABLE "OUTPLFLD"
  ADD ( CONSTRAINT "OUTPLFLD" FOREIGN KEY (
        "TEMPLATENAME" )
  REFERENCES "UTPLFLD" ( 
        "TEMPLATENAME" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUTPLFRM"
  ADD ( CONSTRAINT "OUTPLFRM" FOREIGN KEY (
        "TEMPLATENAME" )
  REFERENCES "UTPLFRM" ( 
        "TEMPLATENAME" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUTPLGRP"
  ADD ( CONSTRAINT "OUTPLGRP" FOREIGN KEY (
        "TEMPLATENAME" )
  REFERENCES "UTPLGRP" ( 
        "TEMPLATENAME" )
  ON DELETE CASCADE )
/

ALTER TABLE "UXFIELD"
  ADD ( CONSTRAINT "U_UGFIF_UXFIELD_DICT" FOREIGN KEY (
        "TPLINTF" )
  REFERENCES "UGFIF" ( 
        "U_MLAB" ) )
  ADD ( CONSTRAINT "U_UGFLAY_UXFIELD_DICT" FOREIGN KEY (
        "TPLLAY" )
  REFERENCES "UGFLAY" ( 
        "U_MLAB" ) )
  ADD ( CONSTRAINT "U_UGFSYN_UXFIELD_DICT" FOREIGN KEY (
        "TPLSYN" )
  REFERENCES "UGFSYN" ( 
        "U_MLAB" ) )
/

ALTER TABLE "OUXFIELD"
  ADD ( CONSTRAINT "OUXFIELD" FOREIGN KEY (
        "ULABEL",
        "GRP",
        "UBASE",
        "UFORM" )
  REFERENCES "UXFIELD" ( 
        "ULABEL",
        "GRP",
        "UBASE",
        "UFORM" )
  ON DELETE CASCADE )
/

ALTER TABLE "UXGROUP"
  ADD ( CONSTRAINT "U_UGGIF_UXGROUP_DICT" FOREIGN KEY (
        "TPLGINTF" )
  REFERENCES "UGGIF" ( 
        "U_MLAB" ) )
/

ALTER TABLE "OUXGROUP"
  ADD ( CONSTRAINT "OUXGROUP" FOREIGN KEY (
        "ULABEL",
        "UBASE",
        "UFORM" )
  REFERENCES "UXGROUP" ( 
        "ULABEL",
        "UBASE",
        "UFORM" )
  ON DELETE CASCADE )
/

ALTER TABLE "UXREGS"
  ADD ( CONSTRAINT "U_UFORM_UXREGS_DICT" FOREIGN KEY (
        "U_FORMLIB" )
  REFERENCES "UFORM" ( 
        "ULABEL" ) )
/

ALTER TABLE "OUXREGS"
  ADD ( CONSTRAINT "OUXREGS" FOREIGN KEY (
        "U_FORMLIB",
        "U_NAME" )
  REFERENCES "UXREGS" ( 
        "U_FORMLIB",
        "U_NAME" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSOPER"
  ADD ( CONSTRAINT "OUSOPER" FOREIGN KEY (
        "USPECNAM",
        "UOPERNAM" )
  REFERENCES "USOPER" ( 
        "USPECNAM",
        "UOPERNAM" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSIOPER"
  ADD ( CONSTRAINT "OUSIOPER" FOREIGN KEY (
        "UPATH",
        "UIMPLNAM",
        "UOPERNAM" )
  REFERENCES "USIOPER" ( 
        "UPATH",
        "UIMPLNAM",
        "UOPERNAM" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSPARM"
  ADD ( CONSTRAINT "OUSPARM" FOREIGN KEY (
        "USPECNAM",
        "UOPERNAM",
        "UPARMNAM" )
  REFERENCES "USPARM" ( 
        "USPECNAM",
        "UOPERNAM",
        "UPARMNAM" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSUBS"
  ADD ( CONSTRAINT "OUSUBS" FOREIGN KEY (
        "USUBSYSTEM" )
  REFERENCES "USUBS" ( 
        "USUBSYSTEM" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSICPLB"
  ADD ( CONSTRAINT "OUSICPLB" FOREIGN KEY (
        "UTLBNAM" )
  REFERENCES "USICPLB" ( 
        "UTLBNAM" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSILBCP"
  ADD ( CONSTRAINT "OUSILBCP" FOREIGN KEY (
        "UTLBNAM",
        "USPECNAM" )
  REFERENCES "USILBCP" ( 
        "UTLBNAM",
        "USPECNAM" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSSPEC"
  ADD ( CONSTRAINT "OUSSPEC" FOREIGN KEY (
        "USPECNAM" )
  REFERENCES "USSPEC" ( 
        "USPECNAM" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSIMPL"
  ADD ( CONSTRAINT "OUSIMPL" FOREIGN KEY (
        "UIMPLNAM",
        "UPATH" )
  REFERENCES "USIMPL" ( 
        "UIMPLNAM",
        "UPATH" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSTMP"
  ADD ( CONSTRAINT "OUSTMP" FOREIGN KEY (
        "UIMPLNAMCAL",
        "UCALTYPE",
        "UCALLIB" )
  REFERENCES "USTMP" ( 
        "UIMPLNAMCAL",
        "UCALTYPE",
        "UCALLIB" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSILBSS"
  ADD ( CONSTRAINT "OUSILBSS" FOREIGN KEY (
        "UTLBNAM",
        "USUBSYSTEM" )
  REFERENCES "USILBSS" ( 
        "UTLBNAM",
        "USUBSYSTEM" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSIPARM"
  ADD ( CONSTRAINT "OUSIPARM" FOREIGN KEY (
        "UPATH",
        "UIMPLNAM",
        "UOPERNAM",
        "UPARMNAM" )
  REFERENCES "USIPARM" ( 
        "UPATH",
        "UIMPLNAM",
        "UOPERNAM",
        "UPARMNAM" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSLINK"
  ADD ( CONSTRAINT "OUSLINK" FOREIGN KEY (
        "USPECNAMCAL",
        "USPECNAMDES",
        "UOPERNAMDES" )
  REFERENCES "USLINK" ( 
        "USPECNAMCAL",
        "USPECNAMDES",
        "UOPERNAMDES" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSILINK"
  ADD ( CONSTRAINT "OUSILINK" FOREIGN KEY (
        "UIMPLNAMCAL",
        "UUPATHCAL",
        "USPECNAMDES",
        "UOPERNAMDES",
        "UCALSEQ" )
  REFERENCES "USILINK" ( 
        "UIMPLNAMCAL",
        "UUPATHCAL",
        "USPECNAMDES",
        "UOPERNAMDES",
        "UCALSEQ" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSKEYWD"
  ADD ( CONSTRAINT "OUSKEYWD" FOREIGN KEY (
        "UKWDSEQ" )
  REFERENCES "USKEYWD" ( 
        "UKWDSEQ" )
  ON DELETE CASCADE )
/

