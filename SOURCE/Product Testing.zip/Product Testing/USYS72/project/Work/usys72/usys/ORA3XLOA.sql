rem @(#)CONT_ID %fv: % %dc: % (#)@
Rem    Description
Rem    -----------
Rem    Application Model	:  
Rem    DBMS Version		: Oracle V7.0 or 7.1
Rem    Uniface Database Driver  : Oracle U3.0 or U3.1
Rem    Uniface Version        	: UNIFACE 6.1.c6 and above
Rem    File Version    		: 5-1-1995
Rem
Rem    Load Definitions sql script
Rem    ---------------------------
Rem    Creates or upgrades the UNIFACE_TABLES view in ORACLE for the 
Rem    implementation of Load Definitions.
Rem
Rem    Copyright (c) 1995, Uniface B.V.
 

CREATE OR REPLACE VIEW UNIFACE_TABLES AS
SELECT USER_TABLES.TABLE_NAME,
	USER_TABLES.TABLESPACE_NAME,
	USER_TABLES.CLUSTER_NAME,
	USER_TABLES.PCT_FREE,
	USER_TABLES.PCT_USED,
	USER_TABLES.INI_TRANS,
	USER_TABLES.MAX_TRANS,
	USER_TABLES.INITIAL_EXTENT,
	USER_TABLES.NEXT_EXTENT,
	USER_TABLES.MIN_EXTENTS,
	USER_TABLES.MAX_EXTENTS,
	USER_TABLES.PCT_INCREASE,
	USER_TABLES.BACKED_UP
FROM USER_TABLES
UNION
SELECT USER_VIEWS.VIEW_NAME,
	'VIEW',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	'F'
	FROM USER_VIEWS;

GRANT SELECT ON UNIFACE_TABLES TO PUBLIC;
