Rem
Rem   Description
Rem   -----------
Rem   Action                    : Verify foreign keys.
Rem   Application Model         : UVCS
Rem   DBMS Version              : Oracle 7.3
Rem   Uniface Driver Version    : U3.3
Rem   Uniface Version           : UNIFACE 7.2 and above
Rem   Required User Option      : DF
Rem   File Version              : %U%
Rem   File Name                 : ora3xuv.sql
Rem
Rem   Application model UVCS
Rem   ----------------------
Rem   The entities of the application model UVCS contain information needed for
Rem   version control of applications. The Application Development System
Rem   maintains the information stored in the entities of UVCS. It locates the
Rem   associated tables or files on the path $IDF.
Rem
Rem   Copyright (c) 1996, Compuware Europe B.V.
Rem
Rem   The Oracle driver does not need a separate check script.
Rem   The constraints in the ora3xuc.sql file take care of that.
Rem

