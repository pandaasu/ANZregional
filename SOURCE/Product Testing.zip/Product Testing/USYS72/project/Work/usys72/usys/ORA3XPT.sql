rem @(#)CONT_ID %fv: % %dc: % (#)@
Rem
Rem    Description
Rem    -----------
Rem    Application Model        : PRINTER
Rem    DBMS Version             : Oracle 7.1 or 7.2
Rem    Uniface Driver Version   : U3.1
Rem    Uniface Version          : UNIFACE 7.1 and above
Rem    File Version             : 5-1-1995
Rem
Rem    Application model PRINTER
Rem    -------------------------
Rem    The application model PRINTER contains the single entity, PRATT. All
Rem    applications, except those which never print, access the table or file
Rem    associated with PRATT.PRINTER on the path $SYS.
Rem
Rem    Copyright (c) 1995, Uniface B.V.

CREATE TABLE "PRATT"(
	"LAYOUT"                            CHAR(16),
	"PRINTER"                           CHAR(16),
	"DEVICE"                            CHAR(16),
	"PAGEL"                             CHAR(8),
	"PAGEW"                             CHAR(8),
	"LEFTM"                             CHAR(8),
	"RIGHTM"                            CHAR(8),
	"TOP"                               CHAR(8),
	"BOTTOM"                            CHAR(8),
	"PITCH"                             CHAR(8),
	"LINESP"                            CHAR(8),
	"OPTIONS"                           LONG RAW,
  CONSTRAINT "PRATTP1" PRIMARY KEY(
	"LAYOUT" ))
/

CREATE TABLE "OPRATT"(
	"LAYOUT"                            CHAR(16),
	"SEGM"                              CHAR(4),
	"DATA"                              LONG RAW,
  CONSTRAINT "OPRATTP1" PRIMARY KEY(
	"LAYOUT",
	"SEGM" ))
/

