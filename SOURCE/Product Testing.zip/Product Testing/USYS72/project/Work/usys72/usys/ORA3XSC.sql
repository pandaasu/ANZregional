rem @(#)CONT_ID %fv: ora3xsc.sql-2 % %dc: Thu Jun 19 15:12:57 1997 % (#)@
Rem
Rem   Description
Rem   -----------
Rem   Action                    : Create DBMS referential integrity controls.
Rem   Application Model         : SYSENV
Rem   DBMS Version              : Oracle 7.1 or 7.2
Rem   Uniface Driver Version    : U3.1
Rem   Uniface Version           : UNIFACE 7.1 and above
Rem   Required User Option      : DF
Rem   File Version              : %U%
Rem   File Name                 : ora3xsc.sql
Rem
Rem   Application model SYSENV
Rem   ------------------------
Rem   The entities of the application model SYSENV contain permissions and
Rem   preferences for use of the Application Development System that have been
Rem   established at an individual site. The Application Development System
Rem   locates the tables or files associated with these entities on the
Rem   path $SYS.
Rem
Rem   Copyright (c) 1995, Uniface B.V.
Rem

ALTER TABLE "UMEMBER"
  ADD ( CONSTRAINT "U_USBJGRP_UMEMBER_SYSENV" FOREIGN KEY (
	"UGROUPNAME",
	"UGROUPTYPE" )
  REFERENCES "USUBJ" (
	"SUBJNAME",
	"SUBJTYPE" )
  ON DELETE CASCADE )
  ADD ( CONSTRAINT "U_USBJUSR_UMEMBER_SYSENV" FOREIGN KEY (
	"UUSERNAME",
	"UUSERTYPE" )
  REFERENCES "USUBJ" (
	"SUBJNAME",
	"SUBJTYPE" )
  ON DELETE CASCADE )
/

ALTER TABLE "UPERMIT"
  ADD ( CONSTRAINT "U_USBJGRP_UPERMIT_SYSENV" FOREIGN KEY (
	"UGROUPNAME",
	"UGROUPTYPE" )
  REFERENCES "USUBJ" (
	"SUBJNAME",
	"SUBJTYPE" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSUBJ"
  ADD ( CONSTRAINT "OUSUBJ" FOREIGN KEY (
	"SUBJNAME",
	"SUBJTYPE" )
  REFERENCES "USUBJ" (
	"SUBJNAME",
	"SUBJTYPE" )
  ON DELETE CASCADE )
/

ALTER TABLE "UUSRPRF"
  ADD ( CONSTRAINT "U_USBJUSR_UUSRPRF_SYSENV" FOREIGN KEY (
	"UUSERNAME",
	"UUSERTYPE" )
  REFERENCES "USUBJ" (
	"SUBJNAME",
	"SUBJTYPE" )
  ON DELETE CASCADE )
/

ALTER TABLE "OUSCUT"
  ADD ( CONSTRAINT "OUSCUT" FOREIGN KEY (
	"UTIMESTAMP",
	"UUSERNAME",
	"UUSERTYPE",
	"UMODULE" )
  REFERENCES "USCUT" (
	"UTIMESTAMP",
	"UUSERNAME",
	"UUSERTYPE",
	"UMODULE" )
  ON DELETE CASCADE )
/

