rem @(#)CONT_ID %fv: % %dc: % (#)@
Rem
Rem   Description
Rem   -----------
Rem   Action                    : Verify foreign keys.
Rem   Application Model         : TEXT
Rem   DBMS Version              : Oracle 7.1 or 7.2
Rem   Uniface Driver Version    : U3.1
Rem   Uniface Version           : UNIFACE 7.1 and above
Rem   Required User Option      : DF
Rem   File Version              : %U%
Rem   File Name                 : ora3xtv.sql
Rem
Rem   Application model TEXT
Rem   ----------------------
Rem   The entities of the application model TEXT contain information which is
Rem   accessed at run-time by all UNIFACE applications. These entities are
Rem   located on the path $UUU.
Rem
Rem   The Application Development System is responsible for maintaining the
Rem   information stored in the entities of the application model TEXT.
Rem
Rem   Copyright (c) 1995, Uniface B.V.
Rem
Rem   The Oracle driver does not need a separate check script.
Rem   The constraints in the ora3xtc.sql file take care of that.
Rem
