Rem
Rem    Description
Rem    -----------
Rem    Application Model         : DICT
Rem    DBMS Version              : Oracle 7.3
Rem    Uniface Driver Version    : U3.3
Rem    Uniface Version           : UNIFACE 7.2 and above
Rem    File Version              : 5-1-1995
Rem
Rem    Application model DICT
Rem    ----------------------
Rem    The entities of the application model DICT contain the source definitions
Rem    for applications. Applications which access the entities of DICT,
Rem    primarily the Application Development System, locate the associated
Rem    tables or files on the path $IDF.
Rem
Rem    The Application Development System is responsible for maintaining the
Rem    information stored in the entities of DICT. It uses this information to
Rem    compile definitions.

Rem    Copyright (c) 1995, Uniface B.V.

CREATE TABLE "UAPLFRM"(
        "ULABEL"                            CHAR(16),
        "UFORM"                             CHAR(16),
        "UVERS"                             CHAR(12),
  CONSTRAINT "UAPLFRMP1" PRIMARY KEY(
        "ULABEL",
        "UFORM" ))
/

CREATE INDEX "UAPLFRMI2" ON "UAPLFRM"(
        "ULABEL" )
/

CREATE INDEX "UAPLFRMI3" ON "UAPLFRM"(
        "UFORM" )
/

CREATE OR REPLACE PACKAGE "UAPLFRM$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER );

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XULABEL"                           IN OUT
          "UAPLFRM"."ULABEL"%TYPE,

        "XUFORM"                            IN OUT
          "UAPLFRM"."UFORM"%TYPE,

        "XUVERS"                            IN OUT
          "UAPLFRM"."UVERS"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WULABEL"                           IN
          "UAPLFRM"."ULABEL"%TYPE,

        "WUFORM"                            IN
          "UAPLFRM"."UFORM"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER );
END "UAPLFRM$U";
/

CREATE OR REPLACE PACKAGE BODY "UAPLFRM$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER )

  IS
  BEGIN

    "PACKAGE_VERSION"."MAJOR_VERSION" := 2;
    "PACKAGE_VERSION"."MINOR_VERSION" := 2;

  END "PACKAGE_VERSION";

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XULABEL"                           IN OUT
          "UAPLFRM"."ULABEL"%TYPE,

        "XUFORM"                            IN OUT
          "UAPLFRM"."UFORM"%TYPE,

        "XUVERS"                            IN OUT
          "UAPLFRM"."UVERS"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WULABEL"                           IN
          "UAPLFRM"."ULABEL"%TYPE,

        "WUFORM"                            IN
          "UAPLFRM"."UFORM"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER )

  IS

    "DUMMY_FIELD"                       
          NUMBER;

    "NUM_FALSE"                         CONSTANT NUMBER  := 0;
    "NUM_TRUE"                          CONSTANT NUMBER  := 1;

    "SELECT_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 0;
    "SELECT_ROWIDROW_BY_PRIMARY_KEY"    CONSTANT NUMBER  := 1;
    "SELECT_ROW_BY_ROWID"               CONSTANT NUMBER  := 2;
    "CHECK_EXISTENCE_OF_PRIMARY_KEY"    CONSTANT NUMBER  := 3;
    "LOCK_ROW_BY_PRIMARY_KEY"           CONSTANT NUMBER  := 4;
    "LOCK_ROW_BY_ROWID"                 CONSTANT NUMBER  := 5;
    "DELETE_ROW_BY_ROWID"               CONSTANT NUMBER  := 6;
    "DELETE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 7;
    "UPDATE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 9;
    "UPDATE_ROW_BY_ROWID"               CONSTANT NUMBER  := 11;

  BEGIN

    "ONE_ROW_AFFECTED" := "NUM_TRUE";

    IF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "ULABEL",
        "UFORM",
        "UVERS"
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUFORM",
        "UNIFACE_IO"."XUVERS"
      FROM "UAPLFRM"
      WHERE 
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UFORM" = "UNIFACE_IO"."WUFORM";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROWIDROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "ULABEL",
        "UFORM",
        "UVERS",
        ROWID
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUFORM",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XROWID"
      FROM "UAPLFRM"
      WHERE 
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UFORM" = "UNIFACE_IO"."WUFORM";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_ROWID" THEN

      SELECT /*+ FIRST_ROWS */ 
        "ULABEL",
        "UFORM",
        "UVERS"
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUFORM",
        "UNIFACE_IO"."XUVERS"
      FROM "UAPLFRM"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "CHECK_EXISTENCE_OF_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 0
      INTO
        "UNIFACE_IO"."DUMMY_FIELD"
      FROM "UAPLFRM"
      WHERE 
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UFORM" = "UNIFACE_IO"."WUFORM";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_PRIMARY_KEY" THEN

      SELECT 
        "ULABEL",
        "UFORM",
        "UVERS",
        ROWID
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUFORM",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XROWID"
      FROM "UAPLFRM"
      WHERE 
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UFORM" = "UNIFACE_IO"."WUFORM"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_ROWID" THEN

      SELECT 
        "ULABEL",
        "UFORM",
        "UVERS"
      INTO
        "UNIFACE_IO"."XULABEL",
        "UNIFACE_IO"."XUFORM",
        "UNIFACE_IO"."XUVERS"
      FROM "UAPLFRM"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_ROWID" THEN

      DELETE FROM "UAPLFRM"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_PRIMARY_KEY" THEN

      DELETE FROM "UAPLFRM"
      WHERE 
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UFORM" = "UNIFACE_IO"."WUFORM";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_PRIMARY_KEY" THEN

      UPDATE "UAPLFRM" SET
        "UVERS" = "UNIFACE_IO"."XUVERS"
      WHERE 
        "ULABEL" = "UNIFACE_IO"."WULABEL" AND
        "UFORM" = "UNIFACE_IO"."WUFORM";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_ROWID" THEN

      UPDATE "UAPLFRM" SET
        "UVERS" = "UNIFACE_IO"."XUVERS"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSE

      raise_application_error( -20000, 'Unhandled UNIFACE I/O request' );

    END IF;

  EXCEPTION

    WHEN NO_DATA_FOUND THEN

      "ONE_ROW_AFFECTED" := "NUM_FALSE";

  END "UNIFACE_IO";
END "UAPLFRM$U";
/

CREATE TABLE "UAPLLST"(
        "U_APPLNAME"                        CHAR(16),
        "U_LISTNAME"                        CHAR(16),
        "U_OBJTYPE"                         CHAR(2),
        "U_OFIELD"                          CHAR(34),
        "U_OENT"                            CHAR(32),
        "U_OVIEW"                           CHAR(32),
        "UVERS"                             CHAR(12),
        "U_MARKER"                          CHAR(1),
        "U_STAT"                            CHAR(4),
        "UTIMESTAMP"                        DATE,
  CONSTRAINT "UAPLLSTP1" PRIMARY KEY(
        "U_LISTNAME",
        "U_OBJTYPE",
        "U_OFIELD",
        "U_OENT",
        "U_OVIEW" ))
/

CREATE INDEX "UAPLLSTI2" ON "UAPLLST"(
        "U_LISTNAME",
        "U_OBJTYPE" )
/

CREATE INDEX "UAPLLSTI3" ON "UAPLLST"(
        "U_LISTNAME" )
/

CREATE OR REPLACE PACKAGE "UAPLLST$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER );

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XU_APPLNAME"                       IN OUT
          "UAPLLST"."U_APPLNAME"%TYPE,

        "XU_LISTNAME"                       IN OUT
          "UAPLLST"."U_LISTNAME"%TYPE,

        "XU_OBJTYPE"                        IN OUT
          "UAPLLST"."U_OBJTYPE"%TYPE,

        "XU_OFIELD"                         IN OUT
          "UAPLLST"."U_OFIELD"%TYPE,

        "XU_OENT"                           IN OUT
          "UAPLLST"."U_OENT"%TYPE,

        "XU_OVIEW"                          IN OUT
          "UAPLLST"."U_OVIEW"%TYPE,

        "XUVERS"                            IN OUT
          "UAPLLST"."UVERS"%TYPE,

        "XU_MARKER"                         IN OUT
          "UAPLLST"."U_MARKER"%TYPE,

        "XU_STAT"                           IN OUT
          "UAPLLST"."U_STAT"%TYPE,

        "XUTIMESTAMP"                       IN OUT
          "UAPLLST"."UTIMESTAMP"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WU_LISTNAME"                       IN
          "UAPLLST"."U_LISTNAME"%TYPE,

        "WU_OBJTYPE"                        IN
          "UAPLLST"."U_OBJTYPE"%TYPE,

        "WU_OFIELD"                         IN
          "UAPLLST"."U_OFIELD"%TYPE,

        "WU_OENT"                           IN
          "UAPLLST"."U_OENT"%TYPE,

        "WU_OVIEW"                          IN
          "UAPLLST"."U_OVIEW"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER );
END "UAPLLST$U";
/

CREATE OR REPLACE PACKAGE BODY "UAPLLST$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER )

  IS
  BEGIN

    "PACKAGE_VERSION"."MAJOR_VERSION" := 2;
    "PACKAGE_VERSION"."MINOR_VERSION" := 2;

  END "PACKAGE_VERSION";

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XU_APPLNAME"                       IN OUT
          "UAPLLST"."U_APPLNAME"%TYPE,

        "XU_LISTNAME"                       IN OUT
          "UAPLLST"."U_LISTNAME"%TYPE,

        "XU_OBJTYPE"                        IN OUT
          "UAPLLST"."U_OBJTYPE"%TYPE,

        "XU_OFIELD"                         IN OUT
          "UAPLLST"."U_OFIELD"%TYPE,

        "XU_OENT"                           IN OUT
          "UAPLLST"."U_OENT"%TYPE,

        "XU_OVIEW"                          IN OUT
          "UAPLLST"."U_OVIEW"%TYPE,

        "XUVERS"                            IN OUT
          "UAPLLST"."UVERS"%TYPE,

        "XU_MARKER"                         IN OUT
          "UAPLLST"."U_MARKER"%TYPE,

        "XU_STAT"                           IN OUT
          "UAPLLST"."U_STAT"%TYPE,

        "XUTIMESTAMP"                       IN OUT
          "UAPLLST"."UTIMESTAMP"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WU_LISTNAME"                       IN
          "UAPLLST"."U_LISTNAME"%TYPE,

        "WU_OBJTYPE"                        IN
          "UAPLLST"."U_OBJTYPE"%TYPE,

        "WU_OFIELD"                         IN
          "UAPLLST"."U_OFIELD"%TYPE,

        "WU_OENT"                           IN
          "UAPLLST"."U_OENT"%TYPE,

        "WU_OVIEW"                          IN
          "UAPLLST"."U_OVIEW"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER )

  IS

    "DUMMY_FIELD"                       
          NUMBER;

    "NUM_FALSE"                         CONSTANT NUMBER  := 0;
    "NUM_TRUE"                          CONSTANT NUMBER  := 1;

    "SELECT_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 0;
    "SELECT_ROWIDROW_BY_PRIMARY_KEY"    CONSTANT NUMBER  := 1;
    "SELECT_ROW_BY_ROWID"               CONSTANT NUMBER  := 2;
    "CHECK_EXISTENCE_OF_PRIMARY_KEY"    CONSTANT NUMBER  := 3;
    "LOCK_ROW_BY_PRIMARY_KEY"           CONSTANT NUMBER  := 4;
    "LOCK_ROW_BY_ROWID"                 CONSTANT NUMBER  := 5;
    "DELETE_ROW_BY_ROWID"               CONSTANT NUMBER  := 6;
    "DELETE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 7;
    "UPDATE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 9;
    "UPDATE_ROW_BY_ROWID"               CONSTANT NUMBER  := 11;

  BEGIN

    "ONE_ROW_AFFECTED" := "NUM_TRUE";

    IF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "U_APPLNAME",
        "U_LISTNAME",
        "U_OBJTYPE",
        "U_OFIELD",
        "U_OENT",
        "U_OVIEW",
        "UVERS",
        "U_MARKER",
        "U_STAT",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XU_APPLNAME",
        "UNIFACE_IO"."XU_LISTNAME",
        "UNIFACE_IO"."XU_OBJTYPE",
        "UNIFACE_IO"."XU_OFIELD",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XU_MARKER",
        "UNIFACE_IO"."XU_STAT",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "UAPLLST"
      WHERE 
        "U_LISTNAME" = "UNIFACE_IO"."WU_LISTNAME" AND
        "U_OBJTYPE" = "UNIFACE_IO"."WU_OBJTYPE" AND
        "U_OFIELD" = "UNIFACE_IO"."WU_OFIELD" AND
        "U_OENT" = "UNIFACE_IO"."WU_OENT" AND
        "U_OVIEW" = "UNIFACE_IO"."WU_OVIEW";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROWIDROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "U_APPLNAME",
        "U_LISTNAME",
        "U_OBJTYPE",
        "U_OFIELD",
        "U_OENT",
        "U_OVIEW",
        "UVERS",
        "U_MARKER",
        "U_STAT",
        "UTIMESTAMP",
        ROWID
      INTO
        "UNIFACE_IO"."XU_APPLNAME",
        "UNIFACE_IO"."XU_LISTNAME",
        "UNIFACE_IO"."XU_OBJTYPE",
        "UNIFACE_IO"."XU_OFIELD",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XU_MARKER",
        "UNIFACE_IO"."XU_STAT",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XROWID"
      FROM "UAPLLST"
      WHERE 
        "U_LISTNAME" = "UNIFACE_IO"."WU_LISTNAME" AND
        "U_OBJTYPE" = "UNIFACE_IO"."WU_OBJTYPE" AND
        "U_OFIELD" = "UNIFACE_IO"."WU_OFIELD" AND
        "U_OENT" = "UNIFACE_IO"."WU_OENT" AND
        "U_OVIEW" = "UNIFACE_IO"."WU_OVIEW";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_ROWID" THEN

      SELECT /*+ FIRST_ROWS */ 
        "U_APPLNAME",
        "U_LISTNAME",
        "U_OBJTYPE",
        "U_OFIELD",
        "U_OENT",
        "U_OVIEW",
        "UVERS",
        "U_MARKER",
        "U_STAT",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XU_APPLNAME",
        "UNIFACE_IO"."XU_LISTNAME",
        "UNIFACE_IO"."XU_OBJTYPE",
        "UNIFACE_IO"."XU_OFIELD",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XU_MARKER",
        "UNIFACE_IO"."XU_STAT",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "UAPLLST"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "CHECK_EXISTENCE_OF_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 0
      INTO
        "UNIFACE_IO"."DUMMY_FIELD"
      FROM "UAPLLST"
      WHERE 
        "U_LISTNAME" = "UNIFACE_IO"."WU_LISTNAME" AND
        "U_OBJTYPE" = "UNIFACE_IO"."WU_OBJTYPE" AND
        "U_OFIELD" = "UNIFACE_IO"."WU_OFIELD" AND
        "U_OENT" = "UNIFACE_IO"."WU_OENT" AND
        "U_OVIEW" = "UNIFACE_IO"."WU_OVIEW";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_PRIMARY_KEY" THEN

      SELECT 
        "U_APPLNAME",
        "U_LISTNAME",
        "U_OBJTYPE",
        "U_OFIELD",
        "U_OENT",
        "U_OVIEW",
        "UVERS",
        "U_MARKER",
        "U_STAT",
        "UTIMESTAMP",
        ROWID
      INTO
        "UNIFACE_IO"."XU_APPLNAME",
        "UNIFACE_IO"."XU_LISTNAME",
        "UNIFACE_IO"."XU_OBJTYPE",
        "UNIFACE_IO"."XU_OFIELD",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XU_MARKER",
        "UNIFACE_IO"."XU_STAT",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XROWID"
      FROM "UAPLLST"
      WHERE 
        "U_LISTNAME" = "UNIFACE_IO"."WU_LISTNAME" AND
        "U_OBJTYPE" = "UNIFACE_IO"."WU_OBJTYPE" AND
        "U_OFIELD" = "UNIFACE_IO"."WU_OFIELD" AND
        "U_OENT" = "UNIFACE_IO"."WU_OENT" AND
        "U_OVIEW" = "UNIFACE_IO"."WU_OVIEW"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_ROWID" THEN

      SELECT 
        "U_APPLNAME",
        "U_LISTNAME",
        "U_OBJTYPE",
        "U_OFIELD",
        "U_OENT",
        "U_OVIEW",
        "UVERS",
        "U_MARKER",
        "U_STAT",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XU_APPLNAME",
        "UNIFACE_IO"."XU_LISTNAME",
        "UNIFACE_IO"."XU_OBJTYPE",
        "UNIFACE_IO"."XU_OFIELD",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XUVERS",
        "UNIFACE_IO"."XU_MARKER",
        "UNIFACE_IO"."XU_STAT",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "UAPLLST"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_ROWID" THEN

      DELETE FROM "UAPLLST"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_PRIMARY_KEY" THEN

      DELETE FROM "UAPLLST"
      WHERE 
        "U_LISTNAME" = "UNIFACE_IO"."WU_LISTNAME" AND
        "U_OBJTYPE" = "UNIFACE_IO"."WU_OBJTYPE" AND
        "U_OFIELD" = "UNIFACE_IO"."WU_OFIELD" AND
        "U_OENT" = "UNIFACE_IO"."WU_OENT" AND
        "U_OVIEW" = "UNIFACE_IO"."WU_OVIEW";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_PRIMARY_KEY" THEN

      UPDATE "UAPLLST" SET
        "U_APPLNAME" = "UNIFACE_IO"."XU_APPLNAME",
        "UVERS" = "UNIFACE_IO"."XUVERS",
        "U_MARKER" = "UNIFACE_IO"."XU_MARKER",
        "U_STAT" = "UNIFACE_IO"."XU_STAT",
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        "U_LISTNAME" = "UNIFACE_IO"."WU_LISTNAME" AND
        "U_OBJTYPE" = "UNIFACE_IO"."WU_OBJTYPE" AND
        "U_OFIELD" = "UNIFACE_IO"."WU_OFIELD" AND
        "U_OENT" = "UNIFACE_IO"."WU_OENT" AND
        "U_OVIEW" = "UNIFACE_IO"."WU_OVIEW";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_ROWID" THEN

      UPDATE "UAPLLST" SET
        "U_APPLNAME" = "UNIFACE_IO"."XU_APPLNAME",
        "UVERS" = "UNIFACE_IO"."XUVERS",
        "U_MARKER" = "UNIFACE_IO"."XU_MARKER",
        "U_STAT" = "UNIFACE_IO"."XU_STAT",
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSE

      raise_application_error( -20000, 'Unhandled UNIFACE I/O request' );

    END IF;

  EXCEPTION

    WHEN NO_DATA_FOUND THEN

      "ONE_ROW_AFFECTED" := "NUM_FALSE";

  END "UNIFACE_IO";
END "UAPLLST$U";
/

CREATE TABLE "UAPPL"(
        "UTIMESTAMP"                        DATE,
        "UCOMPSTAMP"                        DATE,
        "ULINKSTAMP"                        DATE,
        "ULABEL"                            CHAR(16),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "UKEYBOARD"                         CHAR(16),
        "UDISPLAY"                          CHAR(16),
        "HMAX"                              CHAR(6),
        "VMAX"                              CHAR(6),
        "AIOPRINT"                          NUMBER(3),
        "LIBRAR"                            CHAR(16),
        "UPANEL"                            CHAR(16),
        "SPANEL"                            CHAR(16),
        "POSPANEL"                          CHAR(1),
        "UPULL"                             CHAR(16),
        "ASS"                               LONG,
  CONSTRAINT "UAPPLP1" PRIMARY KEY(
        "ULABEL" ))
/

CREATE TABLE "OUAPPL"(
        "ULABEL"                            CHAR(16),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUAPPLP1" PRIMARY KEY(
        "ULABEL",
        "SEGM" ))
/

CREATE TABLE "UCFIELD"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_FLAB"                            CHAR(32),
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "U_FSEQ"                            NUMBER(4),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_LEV"                             CHAR(2),
        "U_DTYP"                            CHAR(2),
        "U_INDB"                            CHAR(1),
        "TPLINTF"                           CHAR(32),
        "U_INTF"                            CHAR(64),
        "TPLSYN"                            CHAR(32),
        "U_SYN"                             CHAR(192),
        "TPLLAY"                            CHAR(32),
        "U_LAY"                             CHAR(128),
        "WIDGETTYPE"                        CHAR(16),
        "TEMPLATENAME"                      CHAR(32),
        "UINHERIT"                          CHAR(1),
        "UDEFWIDTH"                         CHAR(6),
        "UDEFDEPTH"                         CHAR(6),
        "U_DESC"                            LONG,
  CONSTRAINT "UCFIELDP1" PRIMARY KEY(
        "U_FLAB",
        "U_VLAB",
        "U_TLAB" ))
/

CREATE INDEX "UCFIELDI2" ON "UCFIELD"(
        "U_FLAB",
        "U_VLAB" )
/

CREATE INDEX "UCFIELDI3" ON "UCFIELD"(
        "U_VLAB",
        "U_TLAB",
        "U_FSEQ" )
/

CREATE INDEX "UCFIELDI4" ON "UCFIELD"(
        "U_VLAB",
        "U_TLAB" )
/

CREATE INDEX "UCFIELDI5" ON "UCFIELD"(
        "TEMPLATENAME" )
/

CREATE TABLE "OUCFIELD"(
        "U_FLAB"                            CHAR(32),
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUCFIELDP1" PRIMARY KEY(
        "U_FLAB",
        "U_VLAB",
        "U_TLAB",
        "SEGM" ))
/

CREATE TABLE "UCGROUP"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_GLAB"                            CHAR(32),
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_BORD"                            CHAR(1),
        "U_INDB"                            CHAR(1),
        "U_DBMS"                            CHAR(3),
        "U_UPD"                             CHAR(1),
        "U_MINL"                            NUMBER(6),
        "U_MAXL"                            NUMBER(6),
        "U_MINR"                            NUMBER(6),
        "U_MAXR"                            NUMBER(6),
        "TPLGINTF"                          CHAR(32),
        "U_INTF"                            CHAR(64),
        "TEMPLATENAME"                      CHAR(32),
        "UINHERIT"                          CHAR(1),
        "TPLACTUAL"                         LONG,
  CONSTRAINT "UCGROUPP1" PRIMARY KEY(
        "U_GLAB",
        "U_VLAB" ))
/

CREATE INDEX "UCGROUPI2" ON "UCGROUP"(
        "U_VLAB",
        "U_TLAB" )
/

CREATE INDEX "UCGROUPI3" ON "UCGROUP"(
        "U_VLAB" )
/

CREATE INDEX "UCGROUPI4" ON "UCGROUP"(
        "TEMPLATENAME" )
/

CREATE TABLE "OUCGROUP"(
        "U_GLAB"                            CHAR(32),
        "U_VLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUCGROUPP1" PRIMARY KEY(
        "U_GLAB",
        "U_VLAB",
        "SEGM" ))
/

CREATE TABLE "UCKEY"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "U_KSEQ"                            NUMBER(2),
        "U_KTYP"                            CHAR(1),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_DOC"                             LONG,
  CONSTRAINT "UCKEYP1" PRIMARY KEY(
        "U_VLAB",
        "U_TLAB",
        "U_KSEQ" ))
/

CREATE INDEX "UCKEYI2" ON "UCKEY"(
        "U_VLAB",
        "U_TLAB" )
/

CREATE TABLE "OUCKEY"(
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "U_KSEQ"                            NUMBER(2),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUCKEYP1" PRIMARY KEY(
        "U_VLAB",
        "U_TLAB",
        "U_KSEQ",
        "SEGM" ))
/

CREATE TABLE "UCRELSH"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_GLAB"                            CHAR(32),
        "U_VLAB"                            CHAR(32),
        "U_RGLAB"                           CHAR(32),
        "U_RVLAB"                           CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_DELC"                            CHAR(3),
        "U_UPDC"                            CHAR(3),
        "U_KSEQ"                            NUMBER(2),
        "U_FIDX"                            CHAR(1),
        "U_INTEGRITY"                       CHAR(1),
        "U_PROCEDURE"                       CHAR(32),
        "U_OPTIONAL"                        CHAR(1),
        "U_ARITY"                           NUMBER(2),
        "U_DOC"                             LONG,
  CONSTRAINT "UCRELSHP1" PRIMARY KEY(
        "U_GLAB",
        "U_VLAB",
        "U_RGLAB" ))
/

CREATE INDEX "UCRELSHI2" ON "UCRELSH"(
        "U_GLAB",
        "U_VLAB" )
/

CREATE INDEX "UCRELSHI3" ON "UCRELSH"(
        "U_RGLAB",
        "U_RVLAB" )
/

CREATE TABLE "OUCRELSH"(
        "U_GLAB"                            CHAR(32),
        "U_VLAB"                            CHAR(32),
        "U_RGLAB"                           CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUCRELSHP1" PRIMARY KEY(
        "U_GLAB",
        "U_VLAB",
        "U_RGLAB",
        "SEGM" ))
/

CREATE TABLE "UCSCH"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_VLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "ICMODEL"                           CHAR(16),
        "ICDEFINED"                         CHAR(1),
        "ICDIRTY"                           CHAR(1),
        "U_DOC"                             LONG,
  CONSTRAINT "UCSCHP1" PRIMARY KEY(
        "U_VLAB" ))
/

CREATE TABLE "OUCSCH"(
        "U_VLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUCSCHP1" PRIMARY KEY(
        "U_VLAB",
        "SEGM" ))
/

CREATE TABLE "UCSDIA"(
        "UTIMESTAMP"                        DATE,
        "U_VLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "UDIAGRAM"                          LONG RAW,
  CONSTRAINT "UCSDIAP1" PRIMARY KEY(
        "U_VLAB" ))
/

CREATE TABLE "OUCSDIA"(
        "U_VLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG RAW,
  CONSTRAINT "OUCSDIAP1" PRIMARY KEY(
        "U_VLAB",
        "SEGM" ))
/

CREATE TABLE "UCTABLE"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_DOC"                             LONG,
  CONSTRAINT "UCTABLEP1" PRIMARY KEY(
        "U_VLAB",
        "U_TLAB" ))
/

CREATE INDEX "UCTABLEI2" ON "UCTABLE"(
        "U_VLAB" )
/

CREATE TABLE "OUCTABLE"(
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUCTABLEP1" PRIMARY KEY(
        "U_VLAB",
        "U_TLAB",
        "SEGM" ))
/

CREATE TABLE "UDICVER"(
        "VERSNAME"                          CHAR(16),
        "VERSTYPE"                          CHAR(1),
        "UDESCR"                            CHAR(25),
        "UTIMESTAMP"                        DATE,
  CONSTRAINT "UDICVERP1" PRIMARY KEY(
        "VERSNAME",
        "VERSTYPE" ))
/

CREATE OR REPLACE PACKAGE "UDICVER$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER );

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XVERSNAME"                         IN OUT
          "UDICVER"."VERSNAME"%TYPE,

        "XVERSTYPE"                         IN OUT
          "UDICVER"."VERSTYPE"%TYPE,

        "XUDESCR"                           IN OUT
          "UDICVER"."UDESCR"%TYPE,

        "XUTIMESTAMP"                       IN OUT
          "UDICVER"."UTIMESTAMP"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WVERSNAME"                         IN
          "UDICVER"."VERSNAME"%TYPE,

        "WVERSTYPE"                         IN
          "UDICVER"."VERSTYPE"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER );
END "UDICVER$U";
/

CREATE OR REPLACE PACKAGE BODY "UDICVER$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER )

  IS
  BEGIN

    "PACKAGE_VERSION"."MAJOR_VERSION" := 2;
    "PACKAGE_VERSION"."MINOR_VERSION" := 2;

  END "PACKAGE_VERSION";

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XVERSNAME"                         IN OUT
          "UDICVER"."VERSNAME"%TYPE,

        "XVERSTYPE"                         IN OUT
          "UDICVER"."VERSTYPE"%TYPE,

        "XUDESCR"                           IN OUT
          "UDICVER"."UDESCR"%TYPE,

        "XUTIMESTAMP"                       IN OUT
          "UDICVER"."UTIMESTAMP"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WVERSNAME"                         IN
          "UDICVER"."VERSNAME"%TYPE,

        "WVERSTYPE"                         IN
          "UDICVER"."VERSTYPE"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER )

  IS

    "DUMMY_FIELD"                       
          NUMBER;

    "NUM_FALSE"                         CONSTANT NUMBER  := 0;
    "NUM_TRUE"                          CONSTANT NUMBER  := 1;

    "SELECT_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 0;
    "SELECT_ROWIDROW_BY_PRIMARY_KEY"    CONSTANT NUMBER  := 1;
    "SELECT_ROW_BY_ROWID"               CONSTANT NUMBER  := 2;
    "CHECK_EXISTENCE_OF_PRIMARY_KEY"    CONSTANT NUMBER  := 3;
    "LOCK_ROW_BY_PRIMARY_KEY"           CONSTANT NUMBER  := 4;
    "LOCK_ROW_BY_ROWID"                 CONSTANT NUMBER  := 5;
    "DELETE_ROW_BY_ROWID"               CONSTANT NUMBER  := 6;
    "DELETE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 7;
    "UPDATE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 9;
    "UPDATE_ROW_BY_ROWID"               CONSTANT NUMBER  := 11;

  BEGIN

    "ONE_ROW_AFFECTED" := "NUM_TRUE";

    IF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "VERSNAME",
        "VERSTYPE",
        "UDESCR",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XVERSNAME",
        "UNIFACE_IO"."XVERSTYPE",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "UDICVER"
      WHERE 
        "VERSNAME" = "UNIFACE_IO"."WVERSNAME" AND
        "VERSTYPE" = "UNIFACE_IO"."WVERSTYPE";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROWIDROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "VERSNAME",
        "VERSTYPE",
        "UDESCR",
        "UTIMESTAMP",
        ROWID
      INTO
        "UNIFACE_IO"."XVERSNAME",
        "UNIFACE_IO"."XVERSTYPE",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XROWID"
      FROM "UDICVER"
      WHERE 
        "VERSNAME" = "UNIFACE_IO"."WVERSNAME" AND
        "VERSTYPE" = "UNIFACE_IO"."WVERSTYPE";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_ROWID" THEN

      SELECT /*+ FIRST_ROWS */ 
        "VERSNAME",
        "VERSTYPE",
        "UDESCR",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XVERSNAME",
        "UNIFACE_IO"."XVERSTYPE",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "UDICVER"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "CHECK_EXISTENCE_OF_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 0
      INTO
        "UNIFACE_IO"."DUMMY_FIELD"
      FROM "UDICVER"
      WHERE 
        "VERSNAME" = "UNIFACE_IO"."WVERSNAME" AND
        "VERSTYPE" = "UNIFACE_IO"."WVERSTYPE";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_PRIMARY_KEY" THEN

      SELECT 
        "VERSNAME",
        "VERSTYPE",
        "UDESCR",
        "UTIMESTAMP",
        ROWID
      INTO
        "UNIFACE_IO"."XVERSNAME",
        "UNIFACE_IO"."XVERSTYPE",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XROWID"
      FROM "UDICVER"
      WHERE 
        "VERSNAME" = "UNIFACE_IO"."WVERSNAME" AND
        "VERSTYPE" = "UNIFACE_IO"."WVERSTYPE"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_ROWID" THEN

      SELECT 
        "VERSNAME",
        "VERSTYPE",
        "UDESCR",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XVERSNAME",
        "UNIFACE_IO"."XVERSTYPE",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "UDICVER"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_ROWID" THEN

      DELETE FROM "UDICVER"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_PRIMARY_KEY" THEN

      DELETE FROM "UDICVER"
      WHERE 
        "VERSNAME" = "UNIFACE_IO"."WVERSNAME" AND
        "VERSTYPE" = "UNIFACE_IO"."WVERSTYPE";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_PRIMARY_KEY" THEN

      UPDATE "UDICVER" SET
        "UDESCR" = "UNIFACE_IO"."XUDESCR",
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        "VERSNAME" = "UNIFACE_IO"."WVERSNAME" AND
        "VERSTYPE" = "UNIFACE_IO"."WVERSTYPE";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_ROWID" THEN

      UPDATE "UDICVER" SET
        "UDESCR" = "UNIFACE_IO"."XUDESCR",
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSE

      raise_application_error( -20000, 'Unhandled UNIFACE I/O request' );

    END IF;

  EXCEPTION

    WHEN NO_DATA_FOUND THEN

      "ONE_ROW_AFFECTED" := "NUM_FALSE";

  END "UNIFACE_IO";
END "UDICVER$U";
/

CREATE TABLE "UFORM"(
        "UTIMESTAMP"                        DATE,
        "UCOMPSTAMP"                        DATE,
        "ULABEL"                            CHAR(16),
        "FTYP"                              CHAR(4),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "FHEAD"                             CHAR(6),
        "VMAAT"                             CHAR(6),
        "HMAAT"                             CHAR(6),
        "UCOLOR"                            CHAR(6),
        "WVPOS"                             CHAR(6),
        "WHPOS"                             CHAR(6),
        "WVSIZ"                             CHAR(6),
        "WHSIZ"                             CHAR(6),
        "CLRSCRN"                           CHAR(1),
        "UBORDER"                           CHAR(1),
        "RIBIN"                             CHAR(16),
        "RIBOT"                             CHAR(16),
        "MOVABLE"                           CHAR(1),
        "VIDEOINVERSE"                      CHAR(1),
        "VIDEOBRIGHT"                       CHAR(1),
        "VIDEOUNLINE"                       CHAR(1),
        "VIDEOBLINK"                        CHAR(1),
        "UPANEL"                            CHAR(16),
        "POSPANEL"                          CHAR(1),
        "UPULL"                             CHAR(16),
        "HIDESTACK"                         CHAR(1),
        "TEMPLATENAME"                      CHAR(16),
        "UINHERIT"                          CHAR(1),
        "LIBRAR"                            CHAR(16),
        "UTRANSACT"                         CHAR(8),
        "TPLACTUAL"                         LONG,
  CONSTRAINT "UFORMP1" PRIMARY KEY(
        "ULABEL" ))
/

CREATE INDEX "UFORMI2" ON "UFORM"(
        "TEMPLATENAME" )
/

CREATE TABLE "OUFORM"(
        "ULABEL"                            CHAR(16),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUFORMP1" PRIMARY KEY(
        "ULABEL",
        "SEGM" ))
/

CREATE TABLE "UGCROSS"(
        "U_REFNAME"                         CHAR(16),
        "U_TYPE"                            CHAR(1),
        "U_SEQNUM"                          CHAR(5),
        "U_VIEW"                            CHAR(32),
        "U_ENT"                             CHAR(32),
        "U_FIELD"                           CHAR(32),
        "U_TRIGGER"                         CHAR(4),
        "U_EXTCEN"                          CHAR(2),
        "U_OBJECT"                          CHAR(2),
        "U_OVIEW"                           CHAR(32),
        "U_OENT"                            CHAR(32),
        "U_OFIELD"                          CHAR(34),
  CONSTRAINT "UGCROSSP1" PRIMARY KEY(
        "U_REFNAME",
        "U_TYPE",
        "U_SEQNUM" ))
/

CREATE INDEX "UGCROSSI2" ON "UGCROSS"(
        "U_OFIELD" )
/

CREATE INDEX "UGCROSSI3" ON "UGCROSS"(
        "U_OBJECT" )
/

CREATE OR REPLACE PACKAGE "UGCROSS$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER );

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XU_REFNAME"                        IN OUT
          "UGCROSS"."U_REFNAME"%TYPE,

        "XU_TYPE"                           IN OUT
          "UGCROSS"."U_TYPE"%TYPE,

        "XU_SEQNUM"                         IN OUT
          "UGCROSS"."U_SEQNUM"%TYPE,

        "XU_VIEW"                           IN OUT
          "UGCROSS"."U_VIEW"%TYPE,

        "XU_ENT"                            IN OUT
          "UGCROSS"."U_ENT"%TYPE,

        "XU_FIELD"                          IN OUT
          "UGCROSS"."U_FIELD"%TYPE,

        "XU_TRIGGER"                        IN OUT
          "UGCROSS"."U_TRIGGER"%TYPE,

        "XU_EXTCEN"                         IN OUT
          "UGCROSS"."U_EXTCEN"%TYPE,

        "XU_OBJECT"                         IN OUT
          "UGCROSS"."U_OBJECT"%TYPE,

        "XU_OVIEW"                          IN OUT
          "UGCROSS"."U_OVIEW"%TYPE,

        "XU_OENT"                           IN OUT
          "UGCROSS"."U_OENT"%TYPE,

        "XU_OFIELD"                         IN OUT
          "UGCROSS"."U_OFIELD"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WU_REFNAME"                        IN
          "UGCROSS"."U_REFNAME"%TYPE,

        "WU_TYPE"                           IN
          "UGCROSS"."U_TYPE"%TYPE,

        "WU_SEQNUM"                         IN
          "UGCROSS"."U_SEQNUM"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER );
END "UGCROSS$U";
/

CREATE OR REPLACE PACKAGE BODY "UGCROSS$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER )

  IS
  BEGIN

    "PACKAGE_VERSION"."MAJOR_VERSION" := 2;
    "PACKAGE_VERSION"."MINOR_VERSION" := 2;

  END "PACKAGE_VERSION";

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XU_REFNAME"                        IN OUT
          "UGCROSS"."U_REFNAME"%TYPE,

        "XU_TYPE"                           IN OUT
          "UGCROSS"."U_TYPE"%TYPE,

        "XU_SEQNUM"                         IN OUT
          "UGCROSS"."U_SEQNUM"%TYPE,

        "XU_VIEW"                           IN OUT
          "UGCROSS"."U_VIEW"%TYPE,

        "XU_ENT"                            IN OUT
          "UGCROSS"."U_ENT"%TYPE,

        "XU_FIELD"                          IN OUT
          "UGCROSS"."U_FIELD"%TYPE,

        "XU_TRIGGER"                        IN OUT
          "UGCROSS"."U_TRIGGER"%TYPE,

        "XU_EXTCEN"                         IN OUT
          "UGCROSS"."U_EXTCEN"%TYPE,

        "XU_OBJECT"                         IN OUT
          "UGCROSS"."U_OBJECT"%TYPE,

        "XU_OVIEW"                          IN OUT
          "UGCROSS"."U_OVIEW"%TYPE,

        "XU_OENT"                           IN OUT
          "UGCROSS"."U_OENT"%TYPE,

        "XU_OFIELD"                         IN OUT
          "UGCROSS"."U_OFIELD"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WU_REFNAME"                        IN
          "UGCROSS"."U_REFNAME"%TYPE,

        "WU_TYPE"                           IN
          "UGCROSS"."U_TYPE"%TYPE,

        "WU_SEQNUM"                         IN
          "UGCROSS"."U_SEQNUM"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER )

  IS

    "DUMMY_FIELD"                       
          NUMBER;

    "NUM_FALSE"                         CONSTANT NUMBER  := 0;
    "NUM_TRUE"                          CONSTANT NUMBER  := 1;

    "SELECT_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 0;
    "SELECT_ROWIDROW_BY_PRIMARY_KEY"    CONSTANT NUMBER  := 1;
    "SELECT_ROW_BY_ROWID"               CONSTANT NUMBER  := 2;
    "CHECK_EXISTENCE_OF_PRIMARY_KEY"    CONSTANT NUMBER  := 3;
    "LOCK_ROW_BY_PRIMARY_KEY"           CONSTANT NUMBER  := 4;
    "LOCK_ROW_BY_ROWID"                 CONSTANT NUMBER  := 5;
    "DELETE_ROW_BY_ROWID"               CONSTANT NUMBER  := 6;
    "DELETE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 7;
    "UPDATE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 9;
    "UPDATE_ROW_BY_ROWID"               CONSTANT NUMBER  := 11;

  BEGIN

    "ONE_ROW_AFFECTED" := "NUM_TRUE";

    IF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "U_REFNAME",
        "U_TYPE",
        "U_SEQNUM",
        "U_VIEW",
        "U_ENT",
        "U_FIELD",
        "U_TRIGGER",
        "U_EXTCEN",
        "U_OBJECT",
        "U_OVIEW",
        "U_OENT",
        "U_OFIELD"
      INTO
        "UNIFACE_IO"."XU_REFNAME",
        "UNIFACE_IO"."XU_TYPE",
        "UNIFACE_IO"."XU_SEQNUM",
        "UNIFACE_IO"."XU_VIEW",
        "UNIFACE_IO"."XU_ENT",
        "UNIFACE_IO"."XU_FIELD",
        "UNIFACE_IO"."XU_TRIGGER",
        "UNIFACE_IO"."XU_EXTCEN",
        "UNIFACE_IO"."XU_OBJECT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OFIELD"
      FROM "UGCROSS"
      WHERE 
        "U_REFNAME" = "UNIFACE_IO"."WU_REFNAME" AND
        "U_TYPE" = "UNIFACE_IO"."WU_TYPE" AND
        "U_SEQNUM" = "UNIFACE_IO"."WU_SEQNUM";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROWIDROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "U_REFNAME",
        "U_TYPE",
        "U_SEQNUM",
        "U_VIEW",
        "U_ENT",
        "U_FIELD",
        "U_TRIGGER",
        "U_EXTCEN",
        "U_OBJECT",
        "U_OVIEW",
        "U_OENT",
        "U_OFIELD",
        ROWID
      INTO
        "UNIFACE_IO"."XU_REFNAME",
        "UNIFACE_IO"."XU_TYPE",
        "UNIFACE_IO"."XU_SEQNUM",
        "UNIFACE_IO"."XU_VIEW",
        "UNIFACE_IO"."XU_ENT",
        "UNIFACE_IO"."XU_FIELD",
        "UNIFACE_IO"."XU_TRIGGER",
        "UNIFACE_IO"."XU_EXTCEN",
        "UNIFACE_IO"."XU_OBJECT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OFIELD",
        "UNIFACE_IO"."XROWID"
      FROM "UGCROSS"
      WHERE 
        "U_REFNAME" = "UNIFACE_IO"."WU_REFNAME" AND
        "U_TYPE" = "UNIFACE_IO"."WU_TYPE" AND
        "U_SEQNUM" = "UNIFACE_IO"."WU_SEQNUM";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_ROWID" THEN

      SELECT /*+ FIRST_ROWS */ 
        "U_REFNAME",
        "U_TYPE",
        "U_SEQNUM",
        "U_VIEW",
        "U_ENT",
        "U_FIELD",
        "U_TRIGGER",
        "U_EXTCEN",
        "U_OBJECT",
        "U_OVIEW",
        "U_OENT",
        "U_OFIELD"
      INTO
        "UNIFACE_IO"."XU_REFNAME",
        "UNIFACE_IO"."XU_TYPE",
        "UNIFACE_IO"."XU_SEQNUM",
        "UNIFACE_IO"."XU_VIEW",
        "UNIFACE_IO"."XU_ENT",
        "UNIFACE_IO"."XU_FIELD",
        "UNIFACE_IO"."XU_TRIGGER",
        "UNIFACE_IO"."XU_EXTCEN",
        "UNIFACE_IO"."XU_OBJECT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OFIELD"
      FROM "UGCROSS"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "CHECK_EXISTENCE_OF_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 0
      INTO
        "UNIFACE_IO"."DUMMY_FIELD"
      FROM "UGCROSS"
      WHERE 
        "U_REFNAME" = "UNIFACE_IO"."WU_REFNAME" AND
        "U_TYPE" = "UNIFACE_IO"."WU_TYPE" AND
        "U_SEQNUM" = "UNIFACE_IO"."WU_SEQNUM";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_PRIMARY_KEY" THEN

      SELECT 
        "U_REFNAME",
        "U_TYPE",
        "U_SEQNUM",
        "U_VIEW",
        "U_ENT",
        "U_FIELD",
        "U_TRIGGER",
        "U_EXTCEN",
        "U_OBJECT",
        "U_OVIEW",
        "U_OENT",
        "U_OFIELD",
        ROWID
      INTO
        "UNIFACE_IO"."XU_REFNAME",
        "UNIFACE_IO"."XU_TYPE",
        "UNIFACE_IO"."XU_SEQNUM",
        "UNIFACE_IO"."XU_VIEW",
        "UNIFACE_IO"."XU_ENT",
        "UNIFACE_IO"."XU_FIELD",
        "UNIFACE_IO"."XU_TRIGGER",
        "UNIFACE_IO"."XU_EXTCEN",
        "UNIFACE_IO"."XU_OBJECT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OFIELD",
        "UNIFACE_IO"."XROWID"
      FROM "UGCROSS"
      WHERE 
        "U_REFNAME" = "UNIFACE_IO"."WU_REFNAME" AND
        "U_TYPE" = "UNIFACE_IO"."WU_TYPE" AND
        "U_SEQNUM" = "UNIFACE_IO"."WU_SEQNUM"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_ROWID" THEN

      SELECT 
        "U_REFNAME",
        "U_TYPE",
        "U_SEQNUM",
        "U_VIEW",
        "U_ENT",
        "U_FIELD",
        "U_TRIGGER",
        "U_EXTCEN",
        "U_OBJECT",
        "U_OVIEW",
        "U_OENT",
        "U_OFIELD"
      INTO
        "UNIFACE_IO"."XU_REFNAME",
        "UNIFACE_IO"."XU_TYPE",
        "UNIFACE_IO"."XU_SEQNUM",
        "UNIFACE_IO"."XU_VIEW",
        "UNIFACE_IO"."XU_ENT",
        "UNIFACE_IO"."XU_FIELD",
        "UNIFACE_IO"."XU_TRIGGER",
        "UNIFACE_IO"."XU_EXTCEN",
        "UNIFACE_IO"."XU_OBJECT",
        "UNIFACE_IO"."XU_OVIEW",
        "UNIFACE_IO"."XU_OENT",
        "UNIFACE_IO"."XU_OFIELD"
      FROM "UGCROSS"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_ROWID" THEN

      DELETE FROM "UGCROSS"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_PRIMARY_KEY" THEN

      DELETE FROM "UGCROSS"
      WHERE 
        "U_REFNAME" = "UNIFACE_IO"."WU_REFNAME" AND
        "U_TYPE" = "UNIFACE_IO"."WU_TYPE" AND
        "U_SEQNUM" = "UNIFACE_IO"."WU_SEQNUM";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_PRIMARY_KEY" THEN

      UPDATE "UGCROSS" SET
        "U_VIEW" = "UNIFACE_IO"."XU_VIEW",
        "U_ENT" = "UNIFACE_IO"."XU_ENT",
        "U_FIELD" = "UNIFACE_IO"."XU_FIELD",
        "U_TRIGGER" = "UNIFACE_IO"."XU_TRIGGER",
        "U_EXTCEN" = "UNIFACE_IO"."XU_EXTCEN",
        "U_OBJECT" = "UNIFACE_IO"."XU_OBJECT",
        "U_OVIEW" = "UNIFACE_IO"."XU_OVIEW",
        "U_OENT" = "UNIFACE_IO"."XU_OENT",
        "U_OFIELD" = "UNIFACE_IO"."XU_OFIELD"
      WHERE 
        "U_REFNAME" = "UNIFACE_IO"."WU_REFNAME" AND
        "U_TYPE" = "UNIFACE_IO"."WU_TYPE" AND
        "U_SEQNUM" = "UNIFACE_IO"."WU_SEQNUM";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_ROWID" THEN

      UPDATE "UGCROSS" SET
        "U_VIEW" = "UNIFACE_IO"."XU_VIEW",
        "U_ENT" = "UNIFACE_IO"."XU_ENT",
        "U_FIELD" = "UNIFACE_IO"."XU_FIELD",
        "U_TRIGGER" = "UNIFACE_IO"."XU_TRIGGER",
        "U_EXTCEN" = "UNIFACE_IO"."XU_EXTCEN",
        "U_OBJECT" = "UNIFACE_IO"."XU_OBJECT",
        "U_OVIEW" = "UNIFACE_IO"."XU_OVIEW",
        "U_OENT" = "UNIFACE_IO"."XU_OENT",
        "U_OFIELD" = "UNIFACE_IO"."XU_OFIELD"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSE

      raise_application_error( -20000, 'Unhandled UNIFACE I/O request' );

    END IF;

  EXCEPTION

    WHEN NO_DATA_FOUND THEN

      "ONE_ROW_AFFECTED" := "NUM_FALSE";

  END "UNIFACE_IO";
END "UGCROSS$U";
/

CREATE TABLE "UGFIF"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_MLAB"                            CHAR(32),
        "U_MOD"                             CHAR(64),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "TPLPARS"                           LONG,
  CONSTRAINT "UGFIFP1" PRIMARY KEY(
        "U_MLAB" ))
/

CREATE TABLE "OUGFIF"(
        "U_MLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUGFIFP1" PRIMARY KEY(
        "U_MLAB",
        "SEGM" ))
/

CREATE TABLE "UGFLAY"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_MLAB"                            CHAR(32),
        "U_MOD"                             CHAR(128),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "TPLPARS"                           LONG,
  CONSTRAINT "UGFLAYP1" PRIMARY KEY(
        "U_MLAB" ))
/

CREATE TABLE "OUGFLAY"(
        "U_MLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUGFLAYP1" PRIMARY KEY(
        "U_MLAB",
        "SEGM" ))
/

CREATE TABLE "UGFSYN"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            NUMBER(4),
        "U_MLAB"                            CHAR(32),
        "U_MOD"                             CHAR(192),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "TPLPARS"                           LONG,
  CONSTRAINT "UGFSYNP1" PRIMARY KEY(
        "U_MLAB" ))
/

CREATE TABLE "OUGFSYN"(
        "U_MLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUGFSYNP1" PRIMARY KEY(
        "U_MLAB",
        "SEGM" ))
/

CREATE TABLE "UGGIF"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_MLAB"                            CHAR(32),
        "U_MOD"                             CHAR(64),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "TPLPARS"                           LONG,
  CONSTRAINT "UGGIFP1" PRIMARY KEY(
        "U_MLAB" ))
/

CREATE TABLE "OUGGIF"(
        "U_MLAB"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUGGIFP1" PRIMARY KEY(
        "U_MLAB",
        "SEGM" ))
/

CREATE TABLE "UGLYPH"(
        "UTIMESTAMP"                        DATE,
        "UCVERS"                            CHAR(1),
        "UCSUB"                             CHAR(1),
        "UCLABEL"                           CHAR(16),
        "UCVAR"                             CHAR(16),
        "UCTYPE"                            CHAR(3),
        "UCLASS"                            CHAR(8),
        "UCOPTION"                          CHAR(1),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "UBITMAP"                           LONG RAW,
  CONSTRAINT "UGLYPHP1" PRIMARY KEY(
        "UCSUB",
        "UCLABEL",
        "UCVAR",
        "UCTYPE",
        "UCLASS" ))
/

CREATE TABLE "OUGLYPH"(
        "UCSUB"                             CHAR(1),
        "UCLABEL"                           CHAR(16),
        "UCVAR"                             CHAR(16),
        "UCTYPE"                            CHAR(3),
        "UCLASS"                            CHAR(8),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG RAW,
  CONSTRAINT "OUGLYPHP1" PRIMARY KEY(
        "UCSUB",
        "UCLABEL",
        "UCVAR",
        "UCTYPE",
        "UCLASS",
        "SEGM" ))
/

CREATE TABLE "UGREGS"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_TYPE"                            CHAR(2),
        "U_FORMLIB"                         CHAR(16),
        "U_NAME"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_DTYP"                            CHAR(2),
        "U_LAYOUT"                          CHAR(46),
        "U_DOC"                             LONG,
  CONSTRAINT "UGREGSP1" PRIMARY KEY(
        "U_FORMLIB",
        "U_NAME" ))
/

CREATE INDEX "UGREGSI2" ON "UGREGS"(
        "U_NAME" )
/

CREATE TABLE "OUGREGS"(
        "U_FORMLIB"                         CHAR(16),
        "U_NAME"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUGREGSP1" PRIMARY KEY(
        "U_FORMLIB",
        "U_NAME",
        "SEGM" ))
/

CREATE TABLE "ULANA"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_VLAB"                            CHAR(32),
        "U_GLAB"                            CHAR(32),
        "U_VAR"                             CHAR(32),
        "U_ANA"                             LONG,
  CONSTRAINT "ULANAP1" PRIMARY KEY(
        "U_VLAB",
        "U_GLAB",
        "U_VAR" ))
/

CREATE TABLE "OULANA"(
        "U_VLAB"                            CHAR(32),
        "U_GLAB"                            CHAR(32),
        "U_VAR"                             CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OULANAP1" PRIMARY KEY(
        "U_VLAB",
        "U_GLAB",
        "U_VAR",
        "SEGM" ))
/

CREATE TABLE "ULIBR"(
        "ULIBRARY"                          CHAR(16),
        "UDESCR"                            CHAR(25),
        "UTIMESTAMP"                        DATE,
  CONSTRAINT "ULIBRP1" PRIMARY KEY(
        "ULIBRARY" ))
/

CREATE OR REPLACE PACKAGE "ULIBR$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER );

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XULIBRARY"                         IN OUT
          "ULIBR"."ULIBRARY"%TYPE,

        "XUDESCR"                           IN OUT
          "ULIBR"."UDESCR"%TYPE,

        "XUTIMESTAMP"                       IN OUT
          "ULIBR"."UTIMESTAMP"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WULIBRARY"                         IN
          "ULIBR"."ULIBRARY"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER );
END "ULIBR$U";
/

CREATE OR REPLACE PACKAGE BODY "ULIBR$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER )

  IS
  BEGIN

    "PACKAGE_VERSION"."MAJOR_VERSION" := 2;
    "PACKAGE_VERSION"."MINOR_VERSION" := 2;

  END "PACKAGE_VERSION";

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XULIBRARY"                         IN OUT
          "ULIBR"."ULIBRARY"%TYPE,

        "XUDESCR"                           IN OUT
          "ULIBR"."UDESCR"%TYPE,

        "XUTIMESTAMP"                       IN OUT
          "ULIBR"."UTIMESTAMP"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WULIBRARY"                         IN
          "ULIBR"."ULIBRARY"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER )

  IS

    "DUMMY_FIELD"                       
          NUMBER;

    "NUM_FALSE"                         CONSTANT NUMBER  := 0;
    "NUM_TRUE"                          CONSTANT NUMBER  := 1;

    "SELECT_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 0;
    "SELECT_ROWIDROW_BY_PRIMARY_KEY"    CONSTANT NUMBER  := 1;
    "SELECT_ROW_BY_ROWID"               CONSTANT NUMBER  := 2;
    "CHECK_EXISTENCE_OF_PRIMARY_KEY"    CONSTANT NUMBER  := 3;
    "LOCK_ROW_BY_PRIMARY_KEY"           CONSTANT NUMBER  := 4;
    "LOCK_ROW_BY_ROWID"                 CONSTANT NUMBER  := 5;
    "DELETE_ROW_BY_ROWID"               CONSTANT NUMBER  := 6;
    "DELETE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 7;
    "UPDATE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 9;
    "UPDATE_ROW_BY_ROWID"               CONSTANT NUMBER  := 11;

  BEGIN

    "ONE_ROW_AFFECTED" := "NUM_TRUE";

    IF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "ULIBRARY",
        "UDESCR",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XULIBRARY",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "ULIBR"
      WHERE 
        "ULIBRARY" = "UNIFACE_IO"."WULIBRARY";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROWIDROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "ULIBRARY",
        "UDESCR",
        "UTIMESTAMP",
        ROWID
      INTO
        "UNIFACE_IO"."XULIBRARY",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XROWID"
      FROM "ULIBR"
      WHERE 
        "ULIBRARY" = "UNIFACE_IO"."WULIBRARY";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_ROWID" THEN

      SELECT /*+ FIRST_ROWS */ 
        "ULIBRARY",
        "UDESCR",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XULIBRARY",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "ULIBR"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "CHECK_EXISTENCE_OF_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 0
      INTO
        "UNIFACE_IO"."DUMMY_FIELD"
      FROM "ULIBR"
      WHERE 
        "ULIBRARY" = "UNIFACE_IO"."WULIBRARY";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_PRIMARY_KEY" THEN

      SELECT 
        "ULIBRARY",
        "UDESCR",
        "UTIMESTAMP",
        ROWID
      INTO
        "UNIFACE_IO"."XULIBRARY",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XROWID"
      FROM "ULIBR"
      WHERE 
        "ULIBRARY" = "UNIFACE_IO"."WULIBRARY"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_ROWID" THEN

      SELECT 
        "ULIBRARY",
        "UDESCR",
        "UTIMESTAMP"
      INTO
        "UNIFACE_IO"."XULIBRARY",
        "UNIFACE_IO"."XUDESCR",
        "UNIFACE_IO"."XUTIMESTAMP"
      FROM "ULIBR"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_ROWID" THEN

      DELETE FROM "ULIBR"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_PRIMARY_KEY" THEN

      DELETE FROM "ULIBR"
      WHERE 
        "ULIBRARY" = "UNIFACE_IO"."WULIBRARY";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_PRIMARY_KEY" THEN

      UPDATE "ULIBR" SET
        "UDESCR" = "UNIFACE_IO"."XUDESCR",
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        "ULIBRARY" = "UNIFACE_IO"."WULIBRARY";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_ROWID" THEN

      UPDATE "ULIBR" SET
        "UDESCR" = "UNIFACE_IO"."XUDESCR",
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSE

      raise_application_error( -20000, 'Unhandled UNIFACE I/O request' );

    END IF;

  EXCEPTION

    WHEN NO_DATA_FOUND THEN

      "ONE_ROW_AFFECTED" := "NUM_FALSE";

  END "UNIFACE_IO";
END "ULIBR$U";
/

CREATE TABLE "USITEM"(
        "UMENU"                             CHAR(16),
        "UVAR"                              CHAR(16),
        "ULAN"                              CHAR(3),
        "UTECHSEQ"                          CHAR(6),
        "USEQ"                              NUMBER(2),
        "UTIMESTAMP"                        DATE,
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "UENABLE"                           CHAR(1),
        "UHIDE"                             CHAR(1),
        "UCHECK"                            CHAR(1),
        "REFTYPE"                           CHAR(1),
        "UCASCADE"                          CHAR(16),
        "UCOMMENT"                          LONG,
  CONSTRAINT "USITEMP1" PRIMARY KEY(
        "UMENU",
        "UVAR",
        "ULAN",
        "UTECHSEQ" ))
/

CREATE INDEX "USITEMI2" ON "USITEM"(
        "UMENU",
        "UVAR",
        "ULAN",
        "USEQ" )
/

CREATE INDEX "USITEMI3" ON "USITEM"(
        "UMENU",
        "UVAR",
        "ULAN" )
/

CREATE INDEX "USITEMI4" ON "USITEM"(
        "UCASCADE",
        "UVAR",
        "ULAN" )
/

CREATE TABLE "OUSITEM"(
        "UMENU"                             CHAR(16),
        "UVAR"                              CHAR(16),
        "ULAN"                              CHAR(3),
        "UTECHSEQ"                          CHAR(6),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSITEMP1" PRIMARY KEY(
        "UMENU",
        "UVAR",
        "ULAN",
        "UTECHSEQ",
        "SEGM" ))
/

CREATE TABLE "USMENU"(
        "UMENU"                             CHAR(16),
        "UVAR"                              CHAR(16),
        "ULAN"                              CHAR(3),
        "MENUTYPE"                          CHAR(1),
        "UTIMESTAMP"                        DATE,
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "AUTHORIZ"                          CHAR(1),
        "UCOMMENT"                          LONG,
  CONSTRAINT "USMENUP1" PRIMARY KEY(
        "UMENU",
        "UVAR",
        "ULAN" ))
/

CREATE TABLE "OUSMENU"(
        "UMENU"                             CHAR(16),
        "UVAR"                              CHAR(16),
        "ULAN"                              CHAR(3),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSMENUP1" PRIMARY KEY(
        "UMENU",
        "UVAR",
        "ULAN",
        "SEGM" ))
/

CREATE TABLE "USOURCE"(
        "UTIMESTAMP"                        DATE,
        "UCOMPSTAMP"                        DATE,
        "USTAT"                             CHAR(1),
        "USUB"                              CHAR(1),
        "UVAR"                              CHAR(16),
        "ULABEL"                            CHAR(16),
        "ULAN"                              CHAR(3),
        "MSGTYPE"                           CHAR(1),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "UVPOS"                             CHAR(6),
        "UHPOS"                             CHAR(6),
        "UVSIZ"                             CHAR(6),
        "UHSIZ"                             CHAR(6),
        "AUTHORIZ"                          CHAR(1),
        "UCLASS"                            CHAR(1),
        "LOCREF"                            CHAR(1),
        "UCONFIRM"                          CHAR(1),
        "UAUDIO"                            NUMBER(5),
        "UCOMMENT"                          LONG,
  CONSTRAINT "USOURCEP1" PRIMARY KEY(
        "USUB",
        "UVAR",
        "ULABEL",
        "ULAN" ))
/

CREATE INDEX "USOURCEI2" ON "USOURCE"(
        "USUB",
        "UVAR" )
/

CREATE TABLE "OUSOURCE"(
        "USUB"                              CHAR(1),
        "UVAR"                              CHAR(16),
        "ULABEL"                            CHAR(16),
        "ULAN"                              CHAR(3),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSOURCEP1" PRIMARY KEY(
        "USUB",
        "UVAR",
        "ULABEL",
        "ULAN",
        "SEGM" ))
/

CREATE TABLE "UTPLFLD"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "TEMPLATENAME"                      CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_LEV"                             CHAR(2),
        "U_DTYP"                            CHAR(2),
        "U_INDB"                            CHAR(1),
        "TPLINTF"                           CHAR(32),
        "U_INTF"                            CHAR(64),
        "TPLSYN"                            CHAR(32),
        "U_SYN"                             CHAR(192),
        "TPLLAY"                            CHAR(32),
        "U_LAY"                             CHAR(128),
        "WIDGETTYPE"                        CHAR(16),
        "TPLPARS"                           LONG,
  CONSTRAINT "UTPLFLDP1" PRIMARY KEY(
        "TEMPLATENAME" ))
/

CREATE TABLE "OUTPLFLD"(
        "TEMPLATENAME"                      CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUTPLFLDP1" PRIMARY KEY(
        "TEMPLATENAME",
        "SEGM" ))
/

CREATE TABLE "UTPLFRM"(
        "UTIMESTAMP"                        DATE,
        "TEMPLATENAME"                      CHAR(16),
        "FTYP"                              CHAR(4),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "FHEAD"                             CHAR(6),
        "VMAAT"                             CHAR(6),
        "HMAAT"                             CHAR(6),
        "UCOLOR"                            CHAR(6),
        "WVPOS"                             CHAR(6),
        "WHPOS"                             CHAR(6),
        "WVSIZ"                             CHAR(6),
        "WHSIZ"                             CHAR(6),
        "CLRSCRN"                           CHAR(1),
        "UBORDER"                           CHAR(1),
        "RIBIN"                             CHAR(16),
        "RIBOT"                             CHAR(16),
        "MOVABLE"                           CHAR(1),
        "VIDEOINVERSE"                      CHAR(1),
        "VIDEOBRIGHT"                       CHAR(1),
        "VIDEOUNLINE"                       CHAR(1),
        "VIDEOBLINK"                        CHAR(1),
        "UPANEL"                            CHAR(32),
        "POSPANEL"                          CHAR(1),
        "UPULL"                             CHAR(32),
        "HIDESTACK"                         CHAR(1),
        "TPLPARS"                           LONG,
  CONSTRAINT "UTPLFRMP1" PRIMARY KEY(
        "TEMPLATENAME" ))
/

CREATE TABLE "OUTPLFRM"(
        "TEMPLATENAME"                      CHAR(16),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUTPLFRMP1" PRIMARY KEY(
        "TEMPLATENAME",
        "SEGM" ))
/

CREATE TABLE "UTPLGRP"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "TEMPLATENAME"                      CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_BORD"                            CHAR(1),
        "U_INDB"                            CHAR(1),
        "U_DBMS"                            CHAR(3),
        "U_UPD"                             CHAR(1),
        "U_MINL"                            NUMBER(6),
        "U_MAXL"                            NUMBER(6),
        "U_MINR"                            NUMBER(6),
        "U_MAXR"                            NUMBER(6),
        "TPLGINTF"                          CHAR(32),
        "U_INTF"                            CHAR(64),
        "TPLPARS"                           LONG,
  CONSTRAINT "UTPLGRPP1" PRIMARY KEY(
        "TEMPLATENAME" ))
/

CREATE TABLE "OUTPLGRP"(
        "TEMPLATENAME"                      CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUTPLGRPP1" PRIMARY KEY(
        "TEMPLATENAME",
        "SEGM" ))
/

CREATE TABLE "UXFIELD"(
        "UTIMESTAMP"                        DATE,
        "ULABEL"                            CHAR(32),
        "GRP"                               CHAR(32),
        "UBASE"                             CHAR(32),
        "UFORM"                             CHAR(16),
        "U_TLAB"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_DTYP"                            CHAR(2),
        "U_INDB"                            CHAR(1),
        "TPLLAY"                            CHAR(32),
        "LAYOUTMOD"                         CHAR(128),
        "TPLSYN"                            CHAR(32),
        "SYNTAXMOD"                         CHAR(192),
        "TPLINTF"                           CHAR(32),
        "INTERFACEMOD"                      CHAR(64),
        "TABSTOP"                           NUMBER(7),
        "WIDGETTYPE"                        CHAR(16),
        "TEMPLATENAME"                      CHAR(32),
        "UINHERIT"                          CHAR(1),
        "STARTMOD"                          LONG,
  CONSTRAINT "UXFIELDP1" PRIMARY KEY(
        "ULABEL",
        "GRP",
        "UBASE",
        "UFORM" ))
/

CREATE INDEX "UXFIELDI2" ON "UXFIELD"(
        "GRP",
        "UBASE",
        "UFORM" )
/

CREATE INDEX "UXFIELDI3" ON "UXFIELD"(
        "UFORM" )
/

CREATE TABLE "OUXFIELD"(
        "ULABEL"                            CHAR(32),
        "GRP"                               CHAR(32),
        "UBASE"                             CHAR(32),
        "UFORM"                             CHAR(16),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUXFIELDP1" PRIMARY KEY(
        "ULABEL",
        "GRP",
        "UBASE",
        "UFORM",
        "SEGM" ))
/

CREATE TABLE "UXGROUP"(
        "UTIMESTAMP"                        DATE,
        "ULABEL"                            CHAR(32),
        "UBASE"                             CHAR(32),
        "UFORM"                             CHAR(16),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_BORD"                            CHAR(1),
        "U_INDB"                            CHAR(1),
        "U_DBMS"                            CHAR(3),
        "U_UPD"                             CHAR(1),
        "U_MINL"                            NUMBER(6),
        "U_MAXL"                            NUMBER(6),
        "U_MINR"                            NUMBER(6),
        "U_MAXR"                            NUMBER(6),
        "TPLGINTF"                          CHAR(32),
        "U_INTF"                            CHAR(64),
        "TEMPLATENAME"                      CHAR(32),
        "UINHERIT"                          CHAR(1),
        "TPLACTUAL"                         LONG,
  CONSTRAINT "UXGROUPP1" PRIMARY KEY(
        "ULABEL",
        "UBASE",
        "UFORM" ))
/

CREATE INDEX "UXGROUPI2" ON "UXGROUP"(
        "UFORM" )
/

CREATE TABLE "OUXGROUP"(
        "ULABEL"                            CHAR(32),
        "UBASE"                             CHAR(32),
        "UFORM"                             CHAR(16),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUXGROUPP1" PRIMARY KEY(
        "ULABEL",
        "UBASE",
        "UFORM",
        "SEGM" ))
/

CREATE TABLE "UXREGS"(
        "UTIMESTAMP"                        DATE,
        "U_STAT"                            CHAR(4),
        "U_TYPE"                            CHAR(2),
        "U_FORMLIB"                         CHAR(16),
        "U_NAME"                            CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_DTYP"                            CHAR(2),
        "U_LAYOUT"                          CHAR(46),
        "U_DOC"                             LONG,
  CONSTRAINT "UXREGSP1" PRIMARY KEY(
        "U_FORMLIB",
        "U_NAME" ))
/

CREATE INDEX "UXREGSI2" ON "UXREGS"(
        "U_NAME" )
/

CREATE INDEX "UXREGSI3" ON "UXREGS"(
        "U_FORMLIB" )
/

CREATE TABLE "OUXREGS"(
        "U_FORMLIB"                         CHAR(16),
        "U_NAME"                            CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUXREGSP1" PRIMARY KEY(
        "U_FORMLIB",
        "U_NAME",
        "SEGM" ))
/

CREATE TABLE "USOPER"(
        "UTIMESTAMP"                        DATE,
        "USPECNAM"                          CHAR(32),
        "UOPERNAM"                          CHAR(32),
        "UDESCR"                            CHAR(25),
        "UVERS"                             CHAR(12),
        "USCOPE"                            CHAR(3),
        "USELFCONT"                         CHAR(1),
        "UEXECTYP"                          CHAR(1),
        "UNOSTATE"                          CHAR(1),
        "UPRE"                              LONG,
  CONSTRAINT "USOPERP1" PRIMARY KEY(
        "USPECNAM",
        "UOPERNAM" ))
/

CREATE INDEX "USOPERI2" ON "USOPER"(
        "USPECNAM" )
/

CREATE TABLE "OUSOPER"(
        "USPECNAM"                          CHAR(32),
        "UOPERNAM"                          CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSOPERP1" PRIMARY KEY(
        "USPECNAM",
        "UOPERNAM",
        "SEGM" ))
/

CREATE TABLE "USIOPER"(
        "UTIMESTAMP"                        DATE,
        "USPECNAM"                          CHAR(32) NOT NULL,
        "UIMPLNAM"                          CHAR(32),
        "UPATH"                             CHAR(3),
        "UOPERNAM"                          CHAR(32),
        "UDESCR"                            CHAR(25),
        "UVERS"                             CHAR(12),
        "ULITOPERNAM"                       CHAR(64),
        "URETVAL"                           NUMBER(2),
        "UCNTXT"                            NUMBER(2),
        "UIMPLEMENTED"                      CHAR(1),
        "UBODY"                             LONG,
  CONSTRAINT "USIOPERP1" PRIMARY KEY(
        "UPATH",
        "UIMPLNAM",
        "UOPERNAM" ))
/

CREATE INDEX "USIOPERI2" ON "USIOPER"(
        "USPECNAM",
        "UOPERNAM" )
/

CREATE TABLE "OUSIOPER"(
        "UPATH"                             CHAR(3),
        "UIMPLNAM"                          CHAR(32),
        "UOPERNAM"                          CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSIOPERP1" PRIMARY KEY(
        "UPATH",
        "UIMPLNAM",
        "UOPERNAM",
        "SEGM" ))
/

CREATE TABLE "USPARM"(
        "UTIMESTAMP"                        DATE,
        "USPECNAM"                          CHAR(32),
        "UOPERNAM"                          CHAR(32),
        "UPARMNAM"                          CHAR(32),
        "UDESCR"                            CHAR(25),
        "UVERS"                             CHAR(12),
        "UPSEQ"                             NUMBER(4),
        "U_PTYP"                            CHAR(1),
        "UDIREC"                            CHAR(1),
        "U_DTYP"                            CHAR(2),
        "U_VLAB"                            CHAR(32),
        "U_TLAB"                            CHAR(32),
        "UCOMMENT"                          LONG,
  CONSTRAINT "USPARMP1" PRIMARY KEY(
        "USPECNAM",
        "UOPERNAM",
        "UPARMNAM" ))
/

CREATE TABLE "OUSPARM"(
        "USPECNAM"                          CHAR(32),
        "UOPERNAM"                          CHAR(32),
        "UPARMNAM"                          CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSPARMP1" PRIMARY KEY(
        "USPECNAM",
        "UOPERNAM",
        "UPARMNAM",
        "SEGM" ))
/

CREATE TABLE "USUBS"(
        "UTIMESTAMP"                        DATE,
        "USUBSYSTEM"                        CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "UPARENT"                           CHAR(16),
        "UCOMMENT"                          LONG,
  CONSTRAINT "USUBSP1" PRIMARY KEY(
        "USUBSYSTEM" ))
/

CREATE INDEX "USUBSI2" ON "USUBS"(
        "UPARENT" )
/

CREATE TABLE "OUSUBS"(
        "USUBSYSTEM"                        CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSUBSP1" PRIMARY KEY(
        "USUBSYSTEM",
        "SEGM" ))
/

CREATE TABLE "USICPLB"(
        "UTIMESTAMP"                        DATE,
        "UTLBNAM"                           CHAR(32),
        "UDESCR"                            CHAR(25),
        "UVERS"                             CHAR(12),
        "UTLBVERS"                          CHAR(12),
        "ULIBID"                            CHAR(64),
        "UCONFID"                           CHAR(64),
        "ULIBVERS"                          CHAR(16),
        "UINSTALLID"                        CHAR(32),
        "UTLBSTRUCTURE"                     LONG,
  CONSTRAINT "USICPLBP1" PRIMARY KEY(
        "UTLBNAM" ))
/

CREATE TABLE "OUSICPLB"(
        "UTLBNAM"                           CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSICPLBP1" PRIMARY KEY(
        "UTLBNAM",
        "SEGM" ))
/

CREATE TABLE "USILBCP"(
        "UTIMESTAMP"                        DATE,
        "UTLBNAM"                           CHAR(32),
        "USPECNAM"                          CHAR(32),
        "USUBSYSTEM"                        CHAR(16),
        "UDESCR"                            CHAR(25),
        "UVERS"                             CHAR(12),
        "UCOMPID"                           CHAR(64),
        "UOPERID"                           CHAR(64),
        "UEVNTID"                           CHAR(64),
        "UCONTENTS"                         LONG,
  CONSTRAINT "USILBCPP1" PRIMARY KEY(
        "UTLBNAM",
        "USPECNAM" ))
/

CREATE INDEX "USILBCPI2" ON "USILBCP"(
        "UTLBNAM" )
/

CREATE INDEX "USILBCPI3" ON "USILBCP"(
        "UTLBNAM",
        "USUBSYSTEM" )
/

CREATE TABLE "OUSILBCP"(
        "UTLBNAM"                           CHAR(32),
        "USPECNAM"                          CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSILBCPP1" PRIMARY KEY(
        "UTLBNAM",
        "USPECNAM",
        "SEGM" ))
/

CREATE TABLE "USSPEC"(
        "UTIMESTAMP"                        DATE,
        "USPECNAM"                          CHAR(32),
        "UDESCR"                            CHAR(25),
        "UVERS"                             CHAR(12),
        "UVAR"                              CHAR(16),
        "USPECID"                           CHAR(64),
        "USUBSYSTEM"                        CHAR(16),
        "UDEFIMPLNAM"                       CHAR(32),
        "UDEFPATH"                          CHAR(3),
        "USYNCALLOWED"                      CHAR(1),
        "USCOPE"                            CHAR(3),
        "UEXECDEF"                          CHAR(1),
        "USELFCONT"                         CHAR(1),
        "UNOSTATE"                          CHAR(1),
        "UTRANS"                            CHAR(1),
        "UTRANSATTR"                        LONG,
  CONSTRAINT "USSPECP1" PRIMARY KEY(
        "USPECNAM" ))
/

CREATE TABLE "OUSSPEC"(
        "USPECNAM"                          CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSSPECP1" PRIMARY KEY(
        "USPECNAM",
        "SEGM" ))
/

CREATE TABLE "USIMPL"(
        "UTIMESTAMP"                        DATE,
        "USPECNAM"                          CHAR(32) NOT NULL,
        "UIMPLNAM"                          CHAR(32),
        "UPATH"                             CHAR(3),
        "UDESCR"                            CHAR(25),
        "UVERS"                             CHAR(12),
        "UIMPLID"                           CHAR(64),
        "UIMPLSUB"                          CHAR(3),
        "UCNTXT"                            CHAR(1),
        "USET"                              CHAR(64),
        "UVERSCHECKING"                     LONG,
  CONSTRAINT "USIMPLP1" PRIMARY KEY(
        "UIMPLNAM",
        "UPATH" ))
/

CREATE INDEX "USIMPLI2" ON "USIMPL"(
        "USPECNAM" )
/

CREATE TABLE "OUSIMPL"(
        "UIMPLNAM"                          CHAR(32),
        "UPATH"                             CHAR(3),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSIMPLP1" PRIMARY KEY(
        "UIMPLNAM",
        "UPATH",
        "SEGM" ))
/

CREATE TABLE "USTMP"(
        "UTIMESTAMP"                        DATE,
        "UIMPLNAMCAL"                       CHAR(32),
        "UCALTYPE"                          CHAR(1),
        "UCALLIB"                           CHAR(16),
        "UXREF"                             LONG,
  CONSTRAINT "USTMPP1" PRIMARY KEY(
        "UIMPLNAMCAL",
        "UCALTYPE",
        "UCALLIB" ))
/

CREATE TABLE "OUSTMP"(
        "UIMPLNAMCAL"                       CHAR(32),
        "UCALTYPE"                          CHAR(1),
        "UCALLIB"                           CHAR(16),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSTMPP1" PRIMARY KEY(
        "UIMPLNAMCAL",
        "UCALTYPE",
        "UCALLIB",
        "SEGM" ))
/

CREATE TABLE "USILBSS"(
        "UTIMESTAMP"                        DATE,
        "UTLBNAM"                           CHAR(32),
        "USUBSYSTEM"                        CHAR(16),
        "USCOPE"                            CHAR(1),
        "UDESCR"                            CHAR(25),
        "UVERS"                             CHAR(12),
        "UCONTENTS"                         LONG,
  CONSTRAINT "USILBSSP1" PRIMARY KEY(
        "UTLBNAM",
        "USUBSYSTEM" ))
/

CREATE INDEX "USILBSSI2" ON "USILBSS"(
        "UTLBNAM" )
/

CREATE TABLE "OUSILBSS"(
        "UTLBNAM"                           CHAR(32),
        "USUBSYSTEM"                        CHAR(16),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSILBSSP1" PRIMARY KEY(
        "UTLBNAM",
        "USUBSYSTEM",
        "SEGM" ))
/

CREATE TABLE "USIPARM"(
        "UTIMESTAMP"                        DATE,
        "USPECNAM"                          CHAR(32) NOT NULL,
        "UIMPLNAM"                          CHAR(32),
        "UPATH"                             CHAR(3),
        "UOPERNAM"                          CHAR(32),
        "UPARMNAM"                          CHAR(32),
        "UVERS"                             CHAR(12),
        "UDESCR"                            CHAR(25),
        "U_INTF"                            CHAR(64),
        "UARRAYSIZ"                         NUMBER(12),
        "TPLINTF"                           CHAR(32),
        "UCTYP"                             CHAR(3),
        "ULITPARMNAM"                       CHAR(32),
        "U_GLAB"                            CHAR(32),
        "UIPATTR"                           LONG,
  CONSTRAINT "USIPARMP1" PRIMARY KEY(
        "UPATH",
        "UIMPLNAM",
        "UOPERNAM",
        "UPARMNAM" ))
/

CREATE TABLE "OUSIPARM"(
        "UPATH"                             CHAR(3),
        "UIMPLNAM"                          CHAR(32),
        "UOPERNAM"                          CHAR(32),
        "UPARMNAM"                          CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSIPARMP1" PRIMARY KEY(
        "UPATH",
        "UIMPLNAM",
        "UOPERNAM",
        "UPARMNAM",
        "SEGM" ))
/

CREATE TABLE "USLINK"(
        "UTIMESTAMP"                        DATE,
        "USPECNAMCAL"                       CHAR(32),
        "USPECNAMDES"                       CHAR(32),
        "UDESCR"                            CHAR(25),
        "UVERS"                             CHAR(12),
        "UOPERNAMDES"                       CHAR(32),
        "UOWNER"                            CHAR(1),
        "UCOMMENT"                          LONG,
  CONSTRAINT "USLINKP1" PRIMARY KEY(
        "USPECNAMCAL",
        "USPECNAMDES",
        "UOPERNAMDES" ))
/

CREATE TABLE "OUSLINK"(
        "USPECNAMCAL"                       CHAR(32),
        "USPECNAMDES"                       CHAR(32),
        "UOPERNAMDES"                       CHAR(32),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSLINKP1" PRIMARY KEY(
        "USPECNAMCAL",
        "USPECNAMDES",
        "UOPERNAMDES",
        "SEGM" ))
/

CREATE TABLE "USILINK"(
        "UTIMESTAMP"                        DATE,
        "UIMPLNAMCAL"                       CHAR(32),
        "UUPATHCAL"                         CHAR(3),
        "USPECNAMDES"                       CHAR(32),
        "UOPERNAMDES"                       CHAR(32),
        "UCALSEQ"                           NUMBER(4),
        "UDESCR"                            CHAR(25),
        "UVERS"                             CHAR(12),
        "USPECNAMCAL"                       CHAR(32) NOT NULL,
        "UTYPE"                             CHAR(1),
        "UCALMOD"                           CHAR(32),
        "UCALENT"                           CHAR(32),
        "UCALFLD"                           CHAR(32),
        "UCALTRG"                           CHAR(4),
        "UCALLINE"                          NUMBER(6),
        "UCALSTAT"                          NUMBER(4),
        "UDESTYPE"                          CHAR(3),
        "UCALENTY"                          CHAR(16),
        "UCALINST"                          CHAR(32),
        "UCALLIB"                           CHAR(16),
        "UDESINST"                          CHAR(32),
        "UDESLIB"                           CHAR(16),
        "UCALPROC"                          LONG,
  CONSTRAINT "USILINKP1" PRIMARY KEY(
        "UIMPLNAMCAL",
        "UUPATHCAL",
        "USPECNAMDES",
        "UOPERNAMDES",
        "UCALSEQ" ))
/

CREATE TABLE "OUSILINK"(
        "UIMPLNAMCAL"                       CHAR(32),
        "UUPATHCAL"                         CHAR(3),
        "USPECNAMDES"                       CHAR(32),
        "UOPERNAMDES"                       CHAR(32),
        "UCALSEQ"                           NUMBER(4),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSILINKP1" PRIMARY KEY(
        "UIMPLNAMCAL",
        "UUPATHCAL",
        "USPECNAMDES",
        "UOPERNAMDES",
        "UCALSEQ",
        "SEGM" ))
/

CREATE TABLE "USIMPKW"(
        "UTIMESTAMP"                        DATE,
        "UKWDSEQ"                           NUMBER(4),
        "UIMPLNAM"                          CHAR(32),
        "UPATH"                             CHAR(3),
  CONSTRAINT "USIMPKWP1" PRIMARY KEY(
        "UKWDSEQ",
        "UIMPLNAM",
        "UPATH" ))
/

CREATE OR REPLACE PACKAGE "USIMPKW$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER );

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XUTIMESTAMP"                       IN OUT
          "USIMPKW"."UTIMESTAMP"%TYPE,

        "XUKWDSEQ"                          IN OUT
          "USIMPKW"."UKWDSEQ"%TYPE,

        "XUIMPLNAM"                         IN OUT
          "USIMPKW"."UIMPLNAM"%TYPE,

        "XUPATH"                            IN OUT
          "USIMPKW"."UPATH"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WUKWDSEQ"                          IN
          "USIMPKW"."UKWDSEQ"%TYPE,

        "WUIMPLNAM"                         IN
          "USIMPKW"."UIMPLNAM"%TYPE,

        "WUPATH"                            IN
          "USIMPKW"."UPATH"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER );
END "USIMPKW$U";
/

CREATE OR REPLACE PACKAGE BODY "USIMPKW$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER )

  IS
  BEGIN

    "PACKAGE_VERSION"."MAJOR_VERSION" := 2;
    "PACKAGE_VERSION"."MINOR_VERSION" := 2;

  END "PACKAGE_VERSION";

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XUTIMESTAMP"                       IN OUT
          "USIMPKW"."UTIMESTAMP"%TYPE,

        "XUKWDSEQ"                          IN OUT
          "USIMPKW"."UKWDSEQ"%TYPE,

        "XUIMPLNAM"                         IN OUT
          "USIMPKW"."UIMPLNAM"%TYPE,

        "XUPATH"                            IN OUT
          "USIMPKW"."UPATH"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WUKWDSEQ"                          IN
          "USIMPKW"."UKWDSEQ"%TYPE,

        "WUIMPLNAM"                         IN
          "USIMPKW"."UIMPLNAM"%TYPE,

        "WUPATH"                            IN
          "USIMPKW"."UPATH"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER )

  IS

    "DUMMY_FIELD"                       
          NUMBER;

    "NUM_FALSE"                         CONSTANT NUMBER  := 0;
    "NUM_TRUE"                          CONSTANT NUMBER  := 1;

    "SELECT_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 0;
    "SELECT_ROWIDROW_BY_PRIMARY_KEY"    CONSTANT NUMBER  := 1;
    "SELECT_ROW_BY_ROWID"               CONSTANT NUMBER  := 2;
    "CHECK_EXISTENCE_OF_PRIMARY_KEY"    CONSTANT NUMBER  := 3;
    "LOCK_ROW_BY_PRIMARY_KEY"           CONSTANT NUMBER  := 4;
    "LOCK_ROW_BY_ROWID"                 CONSTANT NUMBER  := 5;
    "DELETE_ROW_BY_ROWID"               CONSTANT NUMBER  := 6;
    "DELETE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 7;
    "UPDATE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 9;
    "UPDATE_ROW_BY_ROWID"               CONSTANT NUMBER  := 11;

  BEGIN

    "ONE_ROW_AFFECTED" := "NUM_TRUE";

    IF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "UTIMESTAMP",
        "UKWDSEQ",
        "UIMPLNAM",
        "UPATH"
      INTO
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUKWDSEQ",
        "UNIFACE_IO"."XUIMPLNAM",
        "UNIFACE_IO"."XUPATH"
      FROM "USIMPKW"
      WHERE 
        "UKWDSEQ" = "UNIFACE_IO"."WUKWDSEQ" AND
        "UIMPLNAM" = "UNIFACE_IO"."WUIMPLNAM" AND
        "UPATH" = "UNIFACE_IO"."WUPATH";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROWIDROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "UTIMESTAMP",
        "UKWDSEQ",
        "UIMPLNAM",
        "UPATH",
        ROWID
      INTO
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUKWDSEQ",
        "UNIFACE_IO"."XUIMPLNAM",
        "UNIFACE_IO"."XUPATH",
        "UNIFACE_IO"."XROWID"
      FROM "USIMPKW"
      WHERE 
        "UKWDSEQ" = "UNIFACE_IO"."WUKWDSEQ" AND
        "UIMPLNAM" = "UNIFACE_IO"."WUIMPLNAM" AND
        "UPATH" = "UNIFACE_IO"."WUPATH";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_ROWID" THEN

      SELECT /*+ FIRST_ROWS */ 
        "UTIMESTAMP",
        "UKWDSEQ",
        "UIMPLNAM",
        "UPATH"
      INTO
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUKWDSEQ",
        "UNIFACE_IO"."XUIMPLNAM",
        "UNIFACE_IO"."XUPATH"
      FROM "USIMPKW"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "CHECK_EXISTENCE_OF_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 0
      INTO
        "UNIFACE_IO"."DUMMY_FIELD"
      FROM "USIMPKW"
      WHERE 
        "UKWDSEQ" = "UNIFACE_IO"."WUKWDSEQ" AND
        "UIMPLNAM" = "UNIFACE_IO"."WUIMPLNAM" AND
        "UPATH" = "UNIFACE_IO"."WUPATH";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_PRIMARY_KEY" THEN

      SELECT 
        "UTIMESTAMP",
        "UKWDSEQ",
        "UIMPLNAM",
        "UPATH",
        ROWID
      INTO
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUKWDSEQ",
        "UNIFACE_IO"."XUIMPLNAM",
        "UNIFACE_IO"."XUPATH",
        "UNIFACE_IO"."XROWID"
      FROM "USIMPKW"
      WHERE 
        "UKWDSEQ" = "UNIFACE_IO"."WUKWDSEQ" AND
        "UIMPLNAM" = "UNIFACE_IO"."WUIMPLNAM" AND
        "UPATH" = "UNIFACE_IO"."WUPATH"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_ROWID" THEN

      SELECT 
        "UTIMESTAMP",
        "UKWDSEQ",
        "UIMPLNAM",
        "UPATH"
      INTO
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUKWDSEQ",
        "UNIFACE_IO"."XUIMPLNAM",
        "UNIFACE_IO"."XUPATH"
      FROM "USIMPKW"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_ROWID" THEN

      DELETE FROM "USIMPKW"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_PRIMARY_KEY" THEN

      DELETE FROM "USIMPKW"
      WHERE 
        "UKWDSEQ" = "UNIFACE_IO"."WUKWDSEQ" AND
        "UIMPLNAM" = "UNIFACE_IO"."WUIMPLNAM" AND
        "UPATH" = "UNIFACE_IO"."WUPATH";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_PRIMARY_KEY" THEN

      UPDATE "USIMPKW" SET
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        "UKWDSEQ" = "UNIFACE_IO"."WUKWDSEQ" AND
        "UIMPLNAM" = "UNIFACE_IO"."WUIMPLNAM" AND
        "UPATH" = "UNIFACE_IO"."WUPATH";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_ROWID" THEN

      UPDATE "USIMPKW" SET
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSE

      raise_application_error( -20000, 'Unhandled UNIFACE I/O request' );

    END IF;

  EXCEPTION

    WHEN NO_DATA_FOUND THEN

      "ONE_ROW_AFFECTED" := "NUM_FALSE";

  END "UNIFACE_IO";
END "USIMPKW$U";
/

CREATE TABLE "USKEYWD"(
        "UTIMESTAMP"                        DATE,
        "UKWDSEQ"                           NUMBER(4),
        "ULITKWDNAM"                        CHAR(32) NOT NULL,
        "UDESCR"                            CHAR(25),
        "UCATEGORY"                         CHAR(16),
        "UVERS"                             CHAR(12),
        "UCOMMENT"                          LONG,
  CONSTRAINT "USKEYWDP1" PRIMARY KEY(
        "UKWDSEQ" ))
/

CREATE INDEX "USKEYWDI2" ON "USKEYWD"(
        "ULITKWDNAM" )
/

CREATE TABLE "OUSKEYWD"(
        "UKWDSEQ"                           NUMBER(4),
        "SEGM"                              CHAR(4),
        "DATA"                              LONG,
  CONSTRAINT "OUSKEYWDP1" PRIMARY KEY(
        "UKWDSEQ",
        "SEGM" ))
/

CREATE TABLE "USSPCKW"(
        "UTIMESTAMP"                        DATE,
        "UKWDSEQ"                           NUMBER(4),
        "USPECNAM"                          CHAR(32),
  CONSTRAINT "USSPCKWP1" PRIMARY KEY(
        "UKWDSEQ",
        "USPECNAM" ))
/

CREATE OR REPLACE PACKAGE "USSPCKW$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER );

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XUTIMESTAMP"                       IN OUT
          "USSPCKW"."UTIMESTAMP"%TYPE,

        "XUKWDSEQ"                          IN OUT
          "USSPCKW"."UKWDSEQ"%TYPE,

        "XUSPECNAM"                         IN OUT
          "USSPCKW"."USPECNAM"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WUKWDSEQ"                          IN
          "USSPCKW"."UKWDSEQ"%TYPE,

        "WUSPECNAM"                         IN
          "USSPCKW"."USPECNAM"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER );
END "USSPCKW$U";
/

CREATE OR REPLACE PACKAGE BODY "USSPCKW$U" IS

  PROCEDURE "PACKAGE_VERSION"(

        "MAJOR_VERSION"                     OUT
          NUMBER,

        "MINOR_VERSION"                     OUT
          NUMBER )

  IS
  BEGIN

    "PACKAGE_VERSION"."MAJOR_VERSION" := 2;
    "PACKAGE_VERSION"."MINOR_VERSION" := 2;

  END "PACKAGE_VERSION";

  PROCEDURE "UNIFACE_IO"(

        "UNIFACE_IO_REQUEST"                IN
          NUMBER,

        "XUTIMESTAMP"                       IN OUT
          "USSPCKW"."UTIMESTAMP"%TYPE,

        "XUKWDSEQ"                          IN OUT
          "USSPCKW"."UKWDSEQ"%TYPE,

        "XUSPECNAM"                         IN OUT
          "USSPCKW"."USPECNAM"%TYPE,

        "XROWID"                            IN OUT
          ROWID,

        "WUKWDSEQ"                          IN
          "USSPCKW"."UKWDSEQ"%TYPE,

        "WUSPECNAM"                         IN
          "USSPCKW"."USPECNAM"%TYPE,

        "ONE_ROW_AFFECTED"                  OUT
          NUMBER )

  IS

    "DUMMY_FIELD"                       
          NUMBER;

    "NUM_FALSE"                         CONSTANT NUMBER  := 0;
    "NUM_TRUE"                          CONSTANT NUMBER  := 1;

    "SELECT_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 0;
    "SELECT_ROWIDROW_BY_PRIMARY_KEY"    CONSTANT NUMBER  := 1;
    "SELECT_ROW_BY_ROWID"               CONSTANT NUMBER  := 2;
    "CHECK_EXISTENCE_OF_PRIMARY_KEY"    CONSTANT NUMBER  := 3;
    "LOCK_ROW_BY_PRIMARY_KEY"           CONSTANT NUMBER  := 4;
    "LOCK_ROW_BY_ROWID"                 CONSTANT NUMBER  := 5;
    "DELETE_ROW_BY_ROWID"               CONSTANT NUMBER  := 6;
    "DELETE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 7;
    "UPDATE_ROW_BY_PRIMARY_KEY"         CONSTANT NUMBER  := 9;
    "UPDATE_ROW_BY_ROWID"               CONSTANT NUMBER  := 11;

  BEGIN

    "ONE_ROW_AFFECTED" := "NUM_TRUE";

    IF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "UTIMESTAMP",
        "UKWDSEQ",
        "USPECNAM"
      INTO
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUKWDSEQ",
        "UNIFACE_IO"."XUSPECNAM"
      FROM "USSPCKW"
      WHERE 
        "UKWDSEQ" = "UNIFACE_IO"."WUKWDSEQ" AND
        "USPECNAM" = "UNIFACE_IO"."WUSPECNAM";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROWIDROW_BY_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 
        "UTIMESTAMP",
        "UKWDSEQ",
        "USPECNAM",
        ROWID
      INTO
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUKWDSEQ",
        "UNIFACE_IO"."XUSPECNAM",
        "UNIFACE_IO"."XROWID"
      FROM "USSPCKW"
      WHERE 
        "UKWDSEQ" = "UNIFACE_IO"."WUKWDSEQ" AND
        "USPECNAM" = "UNIFACE_IO"."WUSPECNAM";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "SELECT_ROW_BY_ROWID" THEN

      SELECT /*+ FIRST_ROWS */ 
        "UTIMESTAMP",
        "UKWDSEQ",
        "USPECNAM"
      INTO
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUKWDSEQ",
        "UNIFACE_IO"."XUSPECNAM"
      FROM "USSPCKW"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "CHECK_EXISTENCE_OF_PRIMARY_KEY" THEN

      SELECT /*+ FIRST_ROWS */ 0
      INTO
        "UNIFACE_IO"."DUMMY_FIELD"
      FROM "USSPCKW"
      WHERE 
        "UKWDSEQ" = "UNIFACE_IO"."WUKWDSEQ" AND
        "USPECNAM" = "UNIFACE_IO"."WUSPECNAM";

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_PRIMARY_KEY" THEN

      SELECT 
        "UTIMESTAMP",
        "UKWDSEQ",
        "USPECNAM",
        ROWID
      INTO
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUKWDSEQ",
        "UNIFACE_IO"."XUSPECNAM",
        "UNIFACE_IO"."XROWID"
      FROM "USSPCKW"
      WHERE 
        "UKWDSEQ" = "UNIFACE_IO"."WUKWDSEQ" AND
        "USPECNAM" = "UNIFACE_IO"."WUSPECNAM"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "LOCK_ROW_BY_ROWID" THEN

      SELECT 
        "UTIMESTAMP",
        "UKWDSEQ",
        "USPECNAM"
      INTO
        "UNIFACE_IO"."XUTIMESTAMP",
        "UNIFACE_IO"."XUKWDSEQ",
        "UNIFACE_IO"."XUSPECNAM"
      FROM "USSPCKW"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID"
      FOR UPDATE NOWAIT;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_ROWID" THEN

      DELETE FROM "USSPCKW"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "DELETE_ROW_BY_PRIMARY_KEY" THEN

      DELETE FROM "USSPCKW"
      WHERE 
        "UKWDSEQ" = "UNIFACE_IO"."WUKWDSEQ" AND
        "USPECNAM" = "UNIFACE_IO"."WUSPECNAM";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_PRIMARY_KEY" THEN

      UPDATE "USSPCKW" SET
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        "UKWDSEQ" = "UNIFACE_IO"."WUKWDSEQ" AND
        "USPECNAM" = "UNIFACE_IO"."WUSPECNAM";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSIF "UNIFACE_IO"."UNIFACE_IO_REQUEST" =
        "UPDATE_ROW_BY_ROWID" THEN

      UPDATE "USSPCKW" SET
        "UTIMESTAMP" = "UNIFACE_IO"."XUTIMESTAMP"
      WHERE 
        ROWID = "UNIFACE_IO"."XROWID";

      IF SQL%ROWCOUNT <> 1 THEN
        "ONE_ROW_AFFECTED" := "NUM_FALSE";
      END IF;

    ELSE

      raise_application_error( -20000, 'Unhandled UNIFACE I/O request' );

    END IF;

  EXCEPTION

    WHEN NO_DATA_FOUND THEN

      "ONE_ROW_AFFECTED" := "NUM_FALSE";

  END "UNIFACE_IO";
END "USSPCKW$U";
/

