Rem
Rem   Description
Rem   -----------
Rem   Action                    : Verify foreign keys.
Rem   Application Model         : DICT
Rem   DBMS Version              : Oracle 7.3
Rem   Uniface Driver Version    : U3.3
Rem   Uniface Version           : UNIFACE 7.2 and above
Rem   Required User Option      : DF
Rem   File Version              : %U%
Rem   File Name                 : ora3xdv.sql
Rem
Rem   Application model DICT
Rem   ----------------------
Rem   The entities of the application model DICT contain the source definitions
Rem   for applications. Applications which access the entities of DICT,
Rem   primarily the Application Development System, locate the associated
Rem   tables or files on the path $IDF.
Rem
Rem   The Application Development System is responsible for maintaining the
Rem   information stored in the entities of DICT. It uses this information to
Rem   compile definitions.
Rem
Rem   Copyright (c) 1995, Uniface B.V.
Rem
Rem   The Oracle driver does not need a separate check SQL script.
Rem   The constraints in the ora30dc.sql file take care of that.
Rem

