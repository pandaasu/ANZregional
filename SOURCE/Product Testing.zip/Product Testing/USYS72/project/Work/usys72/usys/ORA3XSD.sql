rem @(#)CONT_ID %fv: % %dc: % (#)@
Rem
Rem   Description
Rem   -----------
Rem   Action                    : Drop DBMS referential integrity controls.
Rem   Application Model         : SYSENV
Rem   DBMS Version              : Oracle 7.1 or 7.2
Rem   Uniface Driver Version    : U3.1
Rem   Uniface Version           : UNIFACE 7.1 and above
Rem   Required User Option      : DF
Rem   File Version              : %U%
Rem   File Name                 : ora3xsd.sql
Rem
Rem   Application model SYSENV
Rem   ------------------------
Rem   The entities of the application model SYSENV contain permissions and
Rem   preferences for use of the Application Development System that have been
Rem   established at an individual site. The Application Development System
Rem   locates the tables or files associated with these entities on the
Rem   path $SYS.
Rem
Rem   Copyright (c) 1995, Uniface B.V.
Rem

ALTER TABLE "UMEMBER"
  DROP CONSTRAINT "U_USBJGRP_UMEMBER_SYSENV"
  DROP CONSTRAINT "U_USBJUSR_UMEMBER_SYSENV"
/

ALTER TABLE "UPERMIT"
  DROP CONSTRAINT "U_USBJGRP_UPERMIT_SYSENV"
/

ALTER TABLE "OUSUBJ"
  DROP CONSTRAINT "OUSUBJ"
/

ALTER TABLE "UUSRPRF"
  DROP CONSTRAINT "U_USBJUSR_UUSRPRF_SYSENV"
/

ALTER TABLE "OUSCUT"
  DROP CONSTRAINT "OUSCUT"
/

