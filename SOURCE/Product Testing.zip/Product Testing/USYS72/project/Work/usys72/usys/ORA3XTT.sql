rem @(#)CONT_ID %fv: % %dc: % (#)@
Rem    Description
Rem    -----------
Rem    Application Model        : TEXT
Rem   DBMS Version              : Oracle 7.1 or 7.2
Rem   Uniface Driver Version    : U3.1
Rem   Uniface Version           : UNIFACE 7.1 and above
Rem    File Version             : 5-1-1995
Rem
Rem    Application model TEXT
Rem    ----------------------
Rem    The entities of the application model TEXT contain information which is
Rem    accessed at run-time by all UNIFACE applications. These entities are
Rem    located on the path $UUU.
Rem
Rem    The Application Development System is responsible for maintaining the
Rem    information stored in the entities of the application model TEXT.
Rem
Rem    Copyright (c) 1995, Uniface B.V.

CREATE TABLE "UOBJ"(
	"UTIMESTAMP"                        DATE,
	"UCVERS"                            CHAR(1),
	"UCSUB"                             CHAR(1),
	"UCLABEL"                           CHAR(16),
	"UCVAR"                             CHAR(16),
	"UCTYPE"                            CHAR(3),
	"UCLASS"                            CHAR(8),
	"UCOBJECT"                          LONG RAW,
  CONSTRAINT "UOBJP1" PRIMARY KEY(
	"UCSUB",
	"UCLABEL",
	"UCVAR",
	"UCTYPE",
	"UCLASS" ))
/

CREATE TABLE "OUOBJ"(
	"UCSUB"                             CHAR(1),
	"UCLABEL"                           CHAR(16),
	"UCVAR"                             CHAR(16),
	"UCTYPE"                            CHAR(3),
	"UCLASS"                            CHAR(8),
	"SEGM"                              CHAR(4),
	"DATA"                              LONG RAW,
  CONSTRAINT "OUOBJP1" PRIMARY KEY(
	"UCSUB",
	"UCLABEL",
	"UCVAR",
	"UCTYPE",
	"UCLASS",
	"SEGM" ))
/

CREATE TABLE "USYSANA"(
	"U_DATE"                            DATE,
	"U_TIME"                            DATE,
	"U_STAT"                            CHAR(4),
	"U_VLAB"                            CHAR(32),
	"U_GLAB"                            CHAR(32),
	"U_VAR"                             CHAR(32),
	"U_ANA"                             LONG,
  CONSTRAINT "USYSANAP1" PRIMARY KEY(
	"U_VLAB",
	"U_GLAB",
	"U_VAR" ))
/

CREATE TABLE "OUSYSANA"(
	"U_VLAB"                            CHAR(32),
	"U_GLAB"                            CHAR(32),
	"U_VAR"                             CHAR(32),
	"SEGM"                              CHAR(4),
	"DATA"                              LONG,
  CONSTRAINT "OUSYSANAP1" PRIMARY KEY(
	"U_VLAB",
	"U_GLAB",
	"U_VAR",
	"SEGM" ))
/

