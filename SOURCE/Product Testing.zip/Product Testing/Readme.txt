PRODUCT TESTING DATABASE.

1. Login to the Windows 95 machine as the User of the product testing database.

2. Copy the entire Usys72 directory onto the C:\ of the machine.

3. Copy the VBRUN300.dll into C:\WINDOWS\SYSTEM\

NOTE: The VBRUN300.dll is required to run the Results Entry form, which is generated at run time.

4. Recreate the shortcuts for the user.

5. Add the user to the A-Oracle group in Novell NetWare.